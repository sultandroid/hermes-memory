---
name: outlook-email
description: Search Microsoft Outlook emails via SQLite database on macOS and extract attachments using AppleScript.
tags:
  - outlook
  - email
  - sqlite
  - applescript
  - attachments
  - macos
---

# Outlook Email Management on macOS

Search, filter, and extract attachments from Microsoft Outlook on macOS using its local SQLite database and AppleScript automation.

## Trigger

User asks to find emails from a specific sender, search for project-related emails, or extract attachments from Outlook.

## Database Location

```
~/Library/Group Containers/UBF8T346G9.Office/Outlook/Outlook 15 Profiles/Main Profile/Data/Outlook.sqlite
```

Only one account (sultan@samayainvest.com) — no account filtering needed.

## Key Tables & Columns

### Folders table

| Column | Type | Description |
|--------|------|-------------|
| `Record_RecordID` | INTEGER | Folder ID (referenced by Mail.Record_FolderID) |
| `Folder_Name` | TEXT | Folder display name (Inbox, Sent Items, Asher Regional Museum, etc.) |
| `Folder_ParentID` | INTEGER | Parent folder ID for nested folders |
| `Folder_FolderType` | INTEGER | 1=Inbox, 3=Contacts, 4=Calendar, 5=Notes, 6=Tasks, 8=Sent, 9=Deleted, 10=Drafts, 12=Junk, 15=Archive, 99=root container |
| `Folder_SpecialFolderType` | INTEGER | Non-zero for special folders (e.g. 111=Birthdays/Calendar) |

**Pitfall: Mail table spans ALL folders.** Querying `Mail` without joining `folders` on `Record_FolderID` returns emails from Inbox, Sent Items, Archive, project sub-folders, etc. — everything mixed together. **Always JOIN with folders** so the user knows where each message lives.

### Mail table

| Column | Type | Description |
|--------|------|-------------|
| `Record_RecordID` | INTEGER | Unique email ID (use with AppleScript `message id`) |
| `Message_SenderList` | TEXT | Display name of sender |
| `Message_SenderAddressList` | TEXT | Email address of sender |
| `Message_NormalizedSubject` | TEXT | Email subject line |
| `Message_TimeReceived` | INTEGER | Unix timestamp (use `datetime(col, 'unixepoch')`) |
| `Message_HasAttachment` | BOOLEAN | 1 = has attachments, 0 = no attachments |
| `PathToDataFile` | TEXT | Relative path to `.olk15Message` file (proprietary — use AppleScript instead) |

### Quick Read Email (canonical first query)

When you need to read an email, start with this — gets preview, folder context, and attachment status in one shot:

```sql
SELECT m.Record_RecordID as id,
       datetime(m.Message_TimeReceived, 'unixepoch', 'localtime') as received,
       f.Folder_Name as folder,
       m.Message_SenderList as sender,
       m.Message_SenderAddressList as email,
       m.Message_NormalizedSubject as subject,
       substr(m.Message_Preview, 1, 500) as preview,
       m.Message_HasAttachment as att
FROM Mail m
JOIN folders f ON m.Record_FolderID = f.Record_RecordID
WHERE m.Record_RecordID = <ID>;
```

The `Message_Preview` column holds the first ~500 chars of the email body — enough to understand the purpose. For longer bodies, try AppleScript (`properties of theMsg` — requires Accessibility permissions).

### Useful query patterns

```sql
-- LIST RECENT EMAILS ACROSS ALL FOLDERS (canonical — always join folders)
SELECT m.Record_RecordID as id,
       datetime(m.Message_TimeReceived, 'unixepoch') as received,
       f.Folder_Name as folder,
       m.Message_SenderList as sender,
       m.Message_NormalizedSubject as subject,
       m.Message_HasAttachment as att
FROM Mail m
JOIN folders f ON m.Record_FolderID = f.Record_RecordID
ORDER BY m.Message_TimeReceived DESC
LIMIT 15;

-- Filter by specific folder
...WHERE f.Folder_Name = 'Inbox'

-- Count per folder
SELECT f.Folder_Name, COUNT(*) as count
FROM Mail m JOIN folders f ON m.Record_FolderID = f.Record_RecordID
GROUP BY f.Folder_Name ORDER BY count DESC;

-- Find by sender
SELECT Record_RecordID, datetime(Message_TimeReceived, 'unixepoch') as received,
       Message_NormalizedSubject, Message_HasAttachment
FROM Mail
WHERE Message_SenderAddressList LIKE '%email@domain.com%'
ORDER BY Message_TimeReceived DESC;

-- Today's emails (local timezone)
SELECT Record_RecordID, datetime(Message_TimeReceived, 'unixepoch') as received,
       Message_NormalizedSubject, Message_HasAttachment
FROM Mail
WHERE date(Message_TimeReceived, 'unixepoch') = date('now', 'localtime')
ORDER BY Message_TimeReceived ASC;

-- Filter by attachment only
... AND Message_HasAttachment = 1

-- Filter by subject keywords (Arabic or English)
... AND Message_NormalizedSubject LIKE '%متجر%' OR Message_NormalizedSubject LIKE '%project%'

-- Combined: project doc codes + attachments
SELECT Record_RecordID, datetime(Message_TimeReceived, 'unixepoch'),
       Message_SenderList, Message_NormalizedSubject
FROM Mail
WHERE Message_NormalizedSubject LIKE '%MOC-MUS-ASE%'
  AND Message_HasAttachment = 1
ORDER BY Message_TimeReceived DESC;

-- Build team contact index for a project
-- Find all unique senders from a specific project folder or by doc code prefix
SELECT DISTINCT m.Message_SenderList as sender,
       m.Message_SenderAddressList as email
FROM Mail m
JOIN folders f ON m.Record_FolderID = f.Record_RecordID
WHERE f.Folder_Name = 'Asher Regional Museum'  -- or: Message_NormalizedSubject LIKE '%MOC-MUS-ASE%'
ORDER BY m.Message_SenderList;

-- Get email activity summary by person (last 90 days)
SELECT m.Message_SenderList as sender,
       m.Message_SenderAddressList as email,
       COUNT(*) as emails,
       MAX(datetime(m.Message_TimeReceived, 'unixepoch')) as last_email
FROM Mail m
JOIN folders f ON m.Record_FolderID = f.Record_RecordID
WHERE f.Folder_Name = 'Asher Regional Museum'
  AND m.Message_TimeReceived >= strftime('%s', 'now', '-90 days')
GROUP BY m.Message_SenderAddressList
ORDER BY COUNT(*) DESC;

-- Get columns
PRAGMA table_info(Mail);
```

### Workflow: search before concluding

When investigating **why a project folder exists** (e.g. a Plans & Procedures sub-folder like `02.17_Risk_Management_Plan`):
1. First search Outlook by subject keyword (`Risk Management`, `خطة إدارة المخاطر`, doc code, etc.)
2. Then search by sender (e.g. CG consultants: `hmabrouk@cg.com.sa`, `Hesham.a@samayainvest.com`)
3. Only then conclude "no matching attachments exist" — the user created the folder because they received relevant documents on email.

### Pitfalls

**Always show folder context.** Every email listing MUST JOIN with `folders` table and display the folder name. Without it, the user cannot tell which messages are in Inbox vs project-specific sub-folders.

**Arabic subject lines — translate on display, every time.** The user prefers English-only output. When Arabic subjects appear, present them with a concise English description (e.g. `طلب تصديق من الخارجية` → "Attestation request from Ministry of Foreign Affairs"). Do not show raw Arabic text. This applies to sender names and any other Arabic content in email output. Even if the subject was shown raw once, the user expects you to fix it immediately when called out — do not let it appear again in the same session.

**Mail table spans ALL folders implicitly.** Querying `Mail` without a `JOIN folders` on `Record_FolderID` returns everything (Inbox, Sent, Archive, project sub-folders) mixed together. The canonical query always uses `FROM Mail m JOIN folders f ON m.Record_FolderID = f.Record_RecordID` and includes `f.Folder_Name` in the SELECT. Without this, the user sees a jumbled list and can't tell which emails are actionable.

**`PathToDataFile` returns %20-encoded paths.** The `Message%20Attachments/` paths from the DB use URL-encoded spaces. On the filesystem, the actual directory is `Message Attachments/` (literal spaces). Use `$'...'` bash quoting or Python `urllib.parse.unquote` when resolving attachment paths.

**`Message_Preview` is truncated; full body extraction is fragile.** The SQLite `Message_Preview` column holds roughly the first ~500 chars of the email body (Outlook truncates it). The raw `.olk15Message` files use TNEF (winmail.dat) format internally — `strings` or direct text extraction rarely finds contiguous body text. AppleScript via `plain text content of msg` is the preferred way to get the full body. Use a `.applescript` file on disk rather than inline `osascript -e` to avoid quoting issues:

```bash
# Write to a temp file first (via write_file tool), then:
osascript /tmp/read_email.applescript
```

Script template (`read_email.applescript`):
```applescript
tell application "Microsoft Outlook"
    set msg to message id <ID>
    set msgContent to plain text content of msg
    return msgContent
end tell
```

This works even without explicit Accessibility permissions in many setups (the `do shell script` AppleScript context bridges permissions). The fallback, `properties of theMsg`, returns a structured record (not plain text) and is harder to parse. If even AppleScript fails (error **-1741**: "An error of type -1741 has occurred" = Outlook/Accessibility not granted), present what's available from `Message_Preview` and flag it as truncated. To grant: System Settings > Privacy & Security > Automation > allow Terminal/Agent to control Outlook.

**Timezone: always use 'localtime' for filtering.** The `datetime(col, 'unixepoch')` returns UTC. For today/this-week filters, always use `date('now', 'localtime')` to match the user's local timezone. Without `'localtime'`, date boundaries are misaligned (UTC vs AST/GMT+3).

**Email body via `strings` on `.olk15Message` files is unreliable.** The TNEF/winmail.dat format embeds body text as opaque blobs. `strings` with `-n 5` or higher misses most body content. Don't waste time trying to carve out email text from message files — use `Message_Preview` (truncated) or AppleScript (requires permissions) instead.

### Email thread analysis (PREFERRED — Conversation_ConversationID)

Outlook's `Conversation_ConversationID` column groups every message in a thread (replies, forwards, all senders). This is more reliable than subject matching — it's indexed, handles sub-thread variants, and catches cross-sender replies automatically.

**Two-step pattern:**

```sql
-- Step 1: Find one email in the thread
SELECT Record_RecordID FROM Mail
WHERE Message_NormalizedSubject LIKE '%Visualization Package%' LIMIT 1;

-- Step 2: Get the full conversation (use the ID from step 1)
SELECT m.Record_RecordID, datetime(m.Message_TimeSent, 'unixepoch', 'localtime') as sent,
       m.Message_SenderList as sender, m.Message_HasAttachment as att,
       substr(m.Message_Preview, 1, 300) as preview
FROM Mail m
WHERE m.Conversation_ConversationID = (
    SELECT Conversation_ConversationID FROM Mail WHERE Record_RecordID = <ID>
)
ORDER BY m.Message_TimeSent;
```

Use subject-based matching (`LIKE '%keyword%'`) only for **discovery** (finding candidate threads), then switch to `Conversation_ConversationID` to expand each thread.

See `references/email-thread-analysis.md` for a complete worked example comparing both techniques.

## Extracting Attachments — AppleScript (PREFERRED)

Outlook stores attachments inside proprietary `.olk15Message` files. **Always try AppleScript first** — the binary parsing of `.olk15MsgAttachment` files (see "Direct Attachment Extraction" below) is fragile: the `Mail_OwnedBlocks` table provides attachment UUIDs, but pairing them with the correct `.olk15MsgAttachment` file is unreliable. AppleScript via `osascript` is the only method that consistently works for all attachment types.

### Key technique: `touch` before `save`

AppleScript's `POSIX file path as alias` requires the destination file to **already exist**. Create it first with `touch`:

```applescript
set savePath to "/path/to/destination/filename.xlsx"
do shell script "touch " & quoted form of savePath
set saveFile to POSIX file savePath as alias
save att in saveFile
```

### Working with message IDs

The `Record_RecordID` from SQLite maps directly to AppleScript's `message id`:

```applescript
tell application "Microsoft Outlook"
    set theMsg to message id 34500
    set msgSubject to subject of theMsg
    set atts to (every attachment of theMsg)

    repeat with att in atts
        set attName to name of att
        -- save logic here
    end repeat
end tell
```

### Checking attachment types

```applescript
set attName to name of att
set attType to content type of att
set attSize to file size of att
```

### Full extraction script template

```applescript
set baseFolder to "/path/to/output/folder/"
do shell script "mkdir -p " & quoted form of baseFolder

tell application "Microsoft Outlook"
    set emailIds to {34500, 33140}
    set savedCount to 0

    repeat with eid in emailIds
        set eidVal to (eid as integer)
        try
            set theMsg to message id eidVal
            set atts to (every attachment of theMsg)

            repeat with att in atts
                set attName to name of att
                set savePath to baseFolder & eidVal & "_" & attName
                do shell script "touch " & quoted form of savePath
                set saveFile to POSIX file savePath as alias
                save att in saveFile
                set savedCount to savedCount + 1
            end repeat
        end try
    end repeat
    return "Saved: " & savedCount & " files"
end tell
```

### Batch extraction (bash + osascript heredoc)

For mass extraction (50+ emails), the sub-agent approach serializes work. A faster pattern: write a bash script with heredoc osascript blocks, then run it. Each osascript invocation is a separate process, so a simple `for id in ...; do osascript <<EOF ... EOF; done` works reliably:

```bash
#!/bin/bash
#!/bin/bash
# Save as /tmp/batch_extract.sh, then: bash /tmp/batch_extract.sh
for id in 35001 35002 35003; do
  osascript <<EOF
tell application "Microsoft Outlook"
    set theMsg to message id $id
    set atts to (every attachment of theMsg)
    set outFolder to "/tmp/outlook_extracts/"
    repeat with att in atts
        set attName to name of att
        set savePath to outFolder & "${id}_" & attName
        do shell script "touch " & quoted form of savePath
        set saveFile to POSIX file savePath as alias
        save att in saveFile
    end repeat
end tell
EOF
done
echo "DONE"
```

This avoids the sub-agent overhead (context window, tool trace, iteration limits) for pure attachment extraction. After extraction, use Python/`execute_code` for the routing logic (pdftotext → identify → copy).

### Safer alternative — write .scpt file first

When the AppleScript contains special characters (`&`, quotes, Unicode) that break heredoc parsing (bash treats `&` as background operator, causing `Foreground command uses '&' backgrounding` errors), use this pattern instead:

1. **Write the .scpt file** using `write_file` tool (or `skill_manage action=write_file`):
   ```
   /tmp/extract_attachments.scpt
   ```

2. **Run with osascript**:
   ```bash
   osascript /tmp/extract_attachments.scpt
   ```

This bypasses heredoc quoting issues entirely. The .scpt is a proper AppleScript UTF-8 file with no shell interpolation.

### Filtering images vs documents

Most emails include signature images. To extract only non-image attachments:

```applescript
set attType to content type of att
if attType does not start with "image/" then
    -- save document
end if
```

| Content type | Classification |
|---|---|
| `image/jpeg`, `image/png`, `image/gif` | Inline signature/email images — usually skip |
| `application/pdf` | Document — save |
| `application/vnd.ms-excel` | Excel (.xls) — save |
| `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` | Excel (.xlsx) — save |
| `application/vnd.openxmlformats-officedocument.wordprocessingml.document` | Word (.docx) — save |

### Email Reading (no attachments)

For emails without attachments:

```applescript
tell application "Microsoft Outlook"
    set theMsg to message id 12345
    set msgProps to properties of theMsg
    return msgProps  -- gives headers, html, plain text content
end tell
```

**Pitfall: `content` and `plain text content` don't return plain text.** The `content` property returns a record (not a string), and `plain text content` may also fail if Accessibility permissions are not granted. The error looks like: `Can't make {name:"x", ...} into type Unicode text`. When this happens, rely on `Message_Preview` from SQLite (truncated) or use `properties of theMsg` to get the full object dump.

## Creating Draft Emails in Outlook

Use `make new outgoing message` (NOT `make new draft message` — that class doesn't exist in Outlook for Mac).

When drafting appointment/contract emails to subcontractors: reference their own SOW, not other contractors' scope. See `references/subcontractor-email-protocol.md`.

### Plain Text Draft

### Plain Text Draft

```applescript
tell application "Microsoft Outlook"
    set newMsg to make new outgoing message with properties ¬
        {subject:"Your Subject Here"}
    make new recipient at newMsg with properties ¬
        {email address:{address:"person@domain.com"}}
    make new cc recipient at newMsg with properties ¬
        {email address:{address:"ccperson@domain.com"}}
    set content of newMsg to "Email body text here"
end tell
-- Auto-saves as draft; no explicit save needed
```

### HTML Draft with Tables (Formal Style — Preferred)

For business emails requiring tables, use HTML body. **User preference: clean, formal, no brand colors** — use black text on white, simple gray borders (#999999), no navy/red/colored headers.

**Best pattern — write HTML to a file first, then read it in AppleScript.** This avoids escaping issues with special characters (£, &, quotes, Unicode) inside AppleScript strings:

```bash
# 1. Write HTML to a temp file (use write_file tool)
# /tmp/email_body.html

# 2. Read and create draft via one-liner osascript
osascript -e '
set htmlContent to do shell script "cat /tmp/email_body.html"
tell application "Microsoft Outlook"
    set newMsg to make new outgoing message with properties ¬
        {subject:"Subject Line"}
    make new recipient at newMsg with properties ¬
        {email address:{address:"to@domain.com"}}
    make new cc recipient at newMsg with properties ¬
        {email address:{address:"cc@domain.com"}}
    set content of newMsg to htmlContent
end tell
'
```

**HTML template** (formal style — clean, no colors):

```html
<html><body style='font-family:Calibri,Arial,sans-serif;font-size:11pt;color:#000000;'>
<p>Dear ...,</p>
<p>Paragraph text here.</p>

<p><b>Section Heading</b></p>
<table style='border-collapse:collapse;width:100%;font-size:10pt;'>
<tr><td style='padding:4px 8px;border:1px solid #999999;'><b>Col1</b></td><td style='padding:4px 8px;border:1px solid #999999;'><b>Col2</b></td></tr>
<tr><td style='padding:4px 8px;border:1px solid #999999;'>Value</td><td style='padding:4px 8px;border:1px solid #999999;'>Value</td></tr>
</table>

<p>Regards,<br/>Name</p>
</body></html>
```

**Style rules:**
- `font-family: Calibri, Arial, sans-serif` — standard business font
- `font-size: 11pt` — readable but compact
- `color: #000000` — black text, no colors
- Table borders: `1px solid #999999` — subtle gray, no colored headers
- No background fills on table rows (white only)
- Use `<b>` not `<h3>` for headings when max formal

## Batch Email Processing with Sub-Agents

For processing many project emails (10+), delegate individual emails to sub-agents in parallel batches of 3. Each sub-agent handles: read body → extract attachments → read content → determine routing → save to project folder.

**Pattern:**
```sql
-- First: get the list of emails to process
SELECT Record_RecordID, datetime(Message_TimeReceived, 'unixepoch', 'localtime'),
       Message_SenderList, Message_NormalizedSubject, Message_HasAttachment
FROM Mail WHERE ... ORDER BY Message_TimeReceived;
```

Then: queue up to 3 sub-agents at a time via `delegate_task`. Pass each sub-agent:
- The email ID and sender
- The project base path
- The Outlook DB path
- Known routing rules (doc code → folder mapping)

The sub-agent should extract attachments using AppleScript (`osascript message id <ID>`), then read PDF content with `pdftotext`, determine routing, and copy files.

**Routing by doc code convention** (Aseer Museum example):

First, parse the doc code: `MOC-MUS-ASE-{disc}{num}-{type}-{seq}`

| Discipline Code | Discipline |
|----------------|------------|
| 1A0 | Architecture |
| 1C0 | Civil |
| 1E0 | Electrical |
| 1KH | HSE |
| 1K0 | General/Multi |
| 1M0 | Mechanical |
| 1KN | Security/ICT |

| Doc Type | Destination Folder |
|----------|-------------------|
| PL- (Plan) | `02_Plans_and_Procedures/02.{NN}_{Name}/` |
| ZD- (General) | Per discipline folder or `09_Correspondence/` |
| MS- (Method Statement) | `02_Plans_and_Procedures/02.15_Method_Statements/` |
| IR- (Inspection Request) | `Docs/03_Inspection_Requests/` |
| NC-/NCR (Non-Conformance) | `Docs/10_Test_and_Inspection/10.3_NCRs/` |
| SI-/JSI- (Site Instruction) | `Docs/05_SIs/05.1_Issued_by_CG/` |
| PQ- (Prequalification) | `Docs/09_Registers/27_Subcontractor_Prequalification_Register/` |
| MI- (Mobilization Items) | `02_Plans_and_Procedures/02.16_Mobilization_Plan/` |
| TQ- (Technical Query) | `Design Files/` per discipline |
| RP- (Report) | `Design Files/` per discipline |
| SC- (HSE Compliance) | `02.5_HSE_Plan/01_Source_Files/` |

CG responses (Code B/C) go into `02_CG_Responses/` subfolder within the document's parent folder. Original submissions go in `01_Source_Files/`.

**Doc code routing details are project-specific.** The routing table below shows the Aseer Museum conventions as a worked example. For other projects, inspect the target project's folder structure first and extrapolate from the discipline prefix.

## Post-extraction: routing to project folders

After downloading attachments to a staging folder (`/tmp/outlook-attachments/<project>/`), route each file to its correct project path. Use Python (via `execute_code`) to handle Arabic names and special characters in paths — bash quoting of these paths is fragile.

### Route by project mapping

```python
import shutil, os

# Define a mapping: filename → relative-subfolder
map = {
    "MOC-MUS-ASE-1KH-PL-0055.pdf": "Docs/02_Plans_and_Procedures",
    "ZAM-NWC-CTR-CLR-MEP-004_Rev.00.pdf": "Docs",
}

staging = "/tmp/outlook-attachments/aseer"
project_root = "/path/to/Aseer-Museum"

for fname, subdir in map.items():
    src = os.path.join(staging, fname)
    dst = os.path.join(project_root, subdir, fname)
    if os.path.exists(src):
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
```

### Categorize by doc code prefix

| Prefix | Project |
|--------|---------|
| `MOC-MUS-ASE` | Aseer Museum |
| `ZAM-NWC` or `ZAM-` | Zamzam Visitor Center |
| `AL JALAL`, `JALAL` | Al Galal & Al Gamal (Jabal Omar retail) |
| `MOC-ASEER-SIC` | Aseer Museum (alternate code) |

### BIM dedup with OneDrive EDEADLK

When routing to BIM folders on OneDrive (`~/Library/CloudStorage/OneDrive-*/Bim Unit/`), you **cannot read file contents** to deduplicate (all reads trigger EDEADLK). Use filename-only matching:

1. `find -type f` to list all filenames in target BIM subfolders (never tries to read content)
2. Python with Arabic normalization (`unicodedata.normalize('NFC', ...)`, Alef/Yeh mapping, diacritic stripping) for fuzzy matching
3. `difflib.SequenceMatcher` with ratio > 0.9 for `_1`/`_2` suffix variants

See `references/onedrive-edeadlk.md` → "BIM scanning workaround" for full Python implementation.

### Pitfall: BIM is deep — search ALL subfolders

Don't just check the direct target folder (e.g. `05_Correspondence_Archive/`). The BIM archive is organized into numbered subfolders like `02_Correspondence_MOC/`, `01_Plans_and_Reports/`. Use recursive `find` across the whole tree — a file may already be filed in a deeper subfolder you didn't scan.

### Full dedup + routing reference

See `references/batch-email-routing.md` for complete AppleScript + Python workflow.

## Batch Email Pipeline (End-to-End Workflow)

This is the recommended workflow for processing large volumes of project emails (50+ in a session):

### Phase 1 — Discovery
Query Outlook SQLite to find relevant emails. Always JOIN folders table. Always use 'localtime' for date filtering.

```sql
SELECT m.Record_RecordID, datetime(m.Message_TimeReceived, 'unixepoch', 'localtime'),
       f.Folder_Name, m.Message_SenderList, m.Message_NormalizedSubject
FROM Mail m JOIN folders f ON m.Record_FolderID = f.Record_RecordID
WHERE f.Folder_Name = 'Asher Regional Museum' AND m.Message_HasAttachment = 1
ORDER BY m.Message_TimeReceived ASC;
```

Display results in a table with English-only subject translations for Arabic.

### Phase 2 — Extract Attachments (AppleScript batch)
Write a bash heredoc script that loops through email IDs. Run it via `terminal(timeout=120)`:

```bash
#!/bin/bash
for id in 35001 35002 35003; do
  osascript <<EOF
tell application "Microsoft Outlook"
    set theMsg to message id $id
    set atts to (every attachment of theMsg)
    set outFolder to "/tmp/outlook_extracts/"
    repeat with att in atts
        set attName to name of att
        set savePath to outFolder & "${id}_" & attName
        do shell script "touch " & quoted form of savePath
        set saveFile to POSIX file savePath as alias
        save att in saveFile
    end repeat
end tell
EOF
done
echo "DONE"
```

Extracts all attachments including inline images. Filter out .jpg/.png/.gif in routing phase. Limits: ~100 per batch.

### Phase 3 — Read & Route
Use `pdftotext` to extract text from PDFs, then route by document code pattern. Use Python/execute_code for mass filing with shutil.copy2, mapping email ID prefixes to destination folders.

### Phase 4 — Cross-reference & Update
After filing, update:
1. **Situation Reports** — document status in _MANAGER_DASHBOARD/
2. **Master Submittal Register** (Excel) — Dashboard status cells
3. **Subcontractor Prequal Register** — log prequal submissions
4. **Odoo tasks** — create/update under correct package parent
5. **Memory** — key actionable findings (C-status docs, new submissions)

### Phase 5 — Archive
Log the batch to `Email_Archive/_email_processing_log.md` with a summary table.

## Direct Attachment Extraction (fallback — AppleScript is preferred)

**AppleScript is faster and more reliable** than binary parsing for most cases. The batch heredoc pattern (above) can extract 50+ attachments in ~2 minutes. Only fall back to this method when AppleScript fails.

Fallback: extract attachments directly from the Outlook attachment cache by querying the Blocks/Mail_OwnedBlocks relationship in the SQLite database.

### Finding attachment file paths

```sql
-- Find attachment file paths for a specific email
SELECT hex(b.BlockID), b.BlockTag, b.PathToDataFile
FROM Blocks b
JOIN Mail_OwnedBlocks m ON m.BlockID = b.BlockID
WHERE m.Record_RecordID = <RECORD_ID>
ORDER BY m.BlockTag;
```

This returns paths like `Message%20Attachments/35/<UUID>.olk15MsgAttachment` relative to the Data/ directory.

### Extracting PDF from .olk15MsgAttachment files

The `.olk15MsgAttachment` files have a proprietary binary header (~285 bytes) followed by base64-encoded PDF content starting with `JVBER`:

```python
import base64, re

with open('file.olk15MsgAttachment', 'rb') as f:
    data = f.read()

# Find base64 PDF start
idx = data.find(b'JVBER')
if idx >= 0:
    b64_text = data[idx:].decode('ascii', errors='ignore')
    b64_clean = re.sub(r'[^A-Za-z0-9+/=]', '', b64_text)
    pdf_data = base64.b64decode(b64_clean)

    with open('output.pdf', 'wb') as out:
        out.write(pdf_data)
```

### Getting attachment metadata (filenames, types)

The file header (first ~285 bytes) contains metadata in plain text:
- `Content-type: application/pdf; name="filename.pdf";`
- `x-mac-creator=`
- `Content-ID:`
- **iCloud + OneDrive EDEADLK on cloud-only files** — macOS cloud storage providers (OneDrive File Provider and iCloud Drive) permanently lock files whose content hasn't been fully downloaded locally. The error `Resource deadlock avoided (EDEADLK)` appears on any read attempt: cp, ditto, rsync, tar, Python open, head, cat, hexdump, file. This affects BOTH:
  - OneDrive at `~/Library/CloudStorage/OneDrive-*/`
  - iCloud Drive at `~/Documents/` (when iCloud sync is active for Documents)
  
  On iCloud, `file` and `stat` commands also fail (unlike OneDrive where `stat` still works). AppleScript returns I/O error -36.
  
  Detect cloud-stub status: `mdls -name com_apple_provenance_isDownloaded <file>` (OneDrive) or check extended attrs.

  **Priority-ordered workarounds:**
  1. `osascript -e 'do shell script "python3 <script.py> 2>&1"'` — even from a fully locked directory, AppleScript's `do shell script` can execute Python scripts when direct shell access fails. Proven to work on both iCloud and OneDrive.
  2. `python3 <script.py>` — can execute cloud-stored `.py` scripts successfully even when `cat`/`head`/`file` commands fail on the same file. `wc -c` reads full size.
  3. `brctl download <path>` — forces the file to sync locally. Wait 1–2s, verify with `stat -f "%Sf" <path>` (output `-` when fully local).
  4. Delete-and-copy — `os.remove(target_path)` then `cp -X /tmp/source target`; deleting the existing stub removes the sync engine lock.
  5. `cat <src> > /tmp/x && mv /tmp/x <dest>` — bypasses `fcopyfile` deadlock in `cp`. ⚠️ Only works for OneDrive files, NOT iCloud Drive dataless files (those silently produce 0-byte output).
  6. **Content-request via time-based detection** — when you cannot read file contents, use `find -ctime -1` (change time), `find -newermt "<date>"` (modification time), or `find -newer <reference_file>` to detect if new/changed files exist. Compare filenames against target BIM folders with `find ... -name "${base}*"` to determine if already filed, without needing to read file bytes.

  Last resort: write companion sidecar files to the same directory (write-to-cloud works when reads fail — write/read asymmetry).
  See `references/olk15-attachment-parsing.md` for the file format specification (magic bytes, header offsets, base64 boundaries).
  See `references/aseer-email-processing-example.md` for a complete worked example (batch processing, AppleScript extraction, Aseer document routing rules, email thread analysis, team contact indexing).
See `references/onedrive-edeadlk.md` for full diagnostics.
