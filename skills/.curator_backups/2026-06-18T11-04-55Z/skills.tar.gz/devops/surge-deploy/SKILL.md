---
name: surge-deploy
description: Deploy static HTML/CSS sites to Surge.sh from local or OneDrive-synced project directories. Covers selective asset extraction, relative-path fixing, image optimization, and size-limit management.
tags: [surge, deployment, hosting, static-site, web, macos]
---

# Surge Deploy Workflow

## Trigger

User asks to deploy a local HTML/CSS site to `*.surge.sh`.

## Prerequisites

- Surge CLI installed (`npm install -g surge` or via brew)
- Logged in (`surge whoami` / `surge login`)

## Steps

### 1. Understand project structure

Run `ls` on the project dir. Note:
- Is `index.html` at root or in a subdirectory?
- Where are assets relative to the HTML? (`../assets/` vs `assets/`)
- Are there large raw photo directories that shouldn't be deployed?

### 2. Copy to /tmp/ (avoid OneDrive slowness)

When source lives on OneDrive (macOS cloud-sync):

**Slow filesystem workaround**: OneDrive copies can timeout for large dirs. Instead of bulk `cp -R`, use **selective asset extraction** (step 3).

### 3. Extract only referenced assets from HTML/CSS

Use Python regex to find all `url()`, `src=` references and copy only those files:

```python
import re, os, shutil

with open('index.html') as f:
    html = f.read()

refs = set()
# url('../assets/...') or url('assets/...')
for m in re.finditer(r'url\("?([^"\)]+)"?\)', html):
    refs.add(m.group(1))
for m in re.finditer(r"url\('?([^'\)]+)'?\)", html):
    refs.add(m.group(1))
# src="assets/..." or src='assets/...'
for m in re.finditer(r'src="([^"]+)"', html):
    refs.add(m.group(1))
for m in re.finditer(r"src='([^']+)'", html):
    refs.add(m.group(1))

# Strip ../ prefix when HTML is in a subdirectory
src_root = "/path/to/source/assets"
dst_root = "/tmp/deploy/assets"

for ref in sorted(refs):
    if not ref.startswith(('assets/', '../assets/')):
        continue
    clean = ref.replace('../', '')
    src = os.path.join(src_root, clean)
    dst = os.path.join(dst_root, clean)
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.exists(src):
        shutil.copy2(src, dst)
```

This avoids copying entire multi-GB asset directories. See `scripts/selective-asset-copy.py` for a reusable standalone version.

### 4. Fix relative paths for flat root serving

If HTML uses `../assets/...` paths (because it lived in a subdirectory), rewrite them:

```bash
sed 's|\.\./assets/|assets/|g' index.html > deploy/index.html
```

### 5b. CSS class completeness check (before deploy)

After appending new sections to an existing HTML file, verify every CSS class used in the new HTML has a corresponding rule. Missing CSS classes cause unstyled content.

```bash
# Extract all unique class names from HTML
grep -oP 'class="([^"]*)"' index.html | tr ' ' '\n' | sort -u > /tmp/html_classes.txt
# Extract all CSS rule definitions (class selectors)
grep -oP '\.([a-zA-Z0-9_-]+)' css/style.css | sort -u > /tmp/css_classes.txt
# Find classes in HTML without CSS rules
comm -23 /tmp/html_classes.txt /tmp/css_classes.txt
```

For single-file (embedded CSS), search within the file:
```bash
python3 -c "
import re
with open('index.html') as f:
    html = f.read()
style_m = re.search(r'<style>(.*?)</style>', html, re.DOTALL)
css = style_m.group(1) if style_m else ''
html_classes = set(re.findall(r'class=\"([^\"]+)\"', html))
css_rules = set(re.findall(r'\.([a-zA-Z0-9_-]+)\s*\{', css))
missing = sorted(html_classes - css_rules)
if missing:
    print(f'MISSING CSS for: {missing}')
else:
    print('All HTML classes have CSS rules')
"
```

### 5. Check deploy size

Surge **Student/Free plan** limit: ~1GB. Run `du -sh deploy/` before deploying.

### 5a. Pre-deploy contamination check (before every deploy)

Run this BEFORE deploying. Catches the three most common silent corruption modes:

```bash
# 1. Line-number contamination (read_file → write_file bug)
# If read_file() output was written back, every line starts with "123|"
if grep -qP '^\s*\d+\|' index.html; then
  echo "⚠ LINE-NUMBER CONTAMINATION DETECTED"
  echo "   Fix with: sed -i '' 's/^[[:space:]]*[0-9]*|//' index.html"
  exit 1
fi

# 2. Truncation (500-line default limit, file is shorter than expected)
expected_lines=$(grep -c '<div class="section"' index.html)  # adjust selector
actual_lines=$(wc -l < index.html)
if [ "$actual_lines" -lt 500 ] && [ "$expected_lines" -gt 5 ]; then
  echo "⚠ FILE MAY BE TRUNCATED (${actual_lines} lines, expected more)"
fi

# 3. Check for placeholder/leftover text
if grep -qi 'lorem ipsum\|todo\|tbd\|xxxx' index.html; then
  echo "⚠ PLACEHOLDER TEXT FOUND"
fi
```

**Source of contamination (2026-06-16):** `read_file()` returns content with `123|` line-number prefixes. Writing that output directly back via `write_file()` or via `execute_code`'s `from hermes_tools import read_file` → `write_file` cycle corrupts the file. ALWAYS verify file content after any read→write cycle by checking for `^\d+\|` pattern. Also, the default 500-line limit truncates files — always pass `limit=N` where N exceeds the file's expected line count.

### 6. Batch-optimize oversized images (macOS)

Use `sips` (built-in macOS) to resize and compress:

```bash
# Resize JPEGs to max 1920px wide, Q85
find assets/ -type f -iname "*.jpg" -size +500k \
  -exec sips --resampleWidth 1920 --setProperty format jpeg \
    --setProperty formatOptions 85 {} --out {} \;
```

For PNGs that are too large, convert to JPEG with sips or use `pngquant`.

### 7. Deploy

```bash
cd deploy/
surge --project ./ --domain your-domain.surge.sh
```

### 7a. Deploy (large file / slow connection)

For files >2MB or when the standard deploy times out:

1. Use a **PTY background process** with long timeout (600s):
   ```bash
   terminal(command='cd /tmp/deploy && surge --project ./ --domain my-domain.surge.sh',
            pty=true, background=true, notify_on_complete=true, timeout=600)
   ```
2. Monitor progress by polling:
   ```bash
   process(action='wait', session_id=..., timeout=180)  # repeat until done
   ```
3. If the `TypeError` occurs at any percentage, try **`npx surge`** as an alternative CLI version:
   ```bash
   npx surge /tmp/deploy/ my-domain.surge.sh
   ```
4. If both fail, the file is too large or carries an immutable xattr. Externalize embedded assets to shrink the HTML under 1MB, or use a different host.

### 8. Verify (check HTML + CSS content, not just HTTP code)

```bash
# Try verification up to 3 times with 5s delay (Surge cold starts return 504)
for i in 1 2 3; do
  code=$(curl -s -o /dev/null -w "%{http_code}" https://your-domain.surge.sh/)
  if [ "$code" = "200" ]; then
    echo "✓ HTTP 200"
    break
  fi
  echo "Attempt $i: $code — waiting 5s..."
  sleep 5
done

# Verify specific content changes made it
curl -sL https://your-domain.surge.sh/ | grep 'expected-content'

# Check for line-number contamination on live site
curl -sL https://your-domain.surge.sh/ | grep -qP '^\s*\d+\|' && echo "⚠ LINE NUMBERS ON LIVE SITE"
```

Expect 200 on first try; 504 on cold start is normal — retry after 10s.

### 8b. If content is stale after verified deploy

**Surge CDN edge staleness**: After deploy, old content may serve for 10-30 seconds because edge nodes serve cached versions while re-fetching from origin. **The deploy itself is correct** — files are on the origin.

If `curl` still shows old content 30+ seconds after deploy:

1. **Tell the user** to hard-refresh (Cmd+Shift+R) before re-deploying
2. **Add `?v=N` cache-buster** to the CSS `<link>` in HTML (increment N each time):
   ```html
   <link rel="stylesheet" href="css/main.css?v=2">
   ```
3. This forces the browser (and Surge edge) to treat it as a new resource
4. Re-deploy with the updated HTML
5. Verify by checking the HTML live: `curl -sL https://domain/ | grep 'css/main.css'` — should show `?v=N`

## Pitfalls

- **Ask before deploying** — User said "dont deploy to surge without i asked you to deploy". NEVER deploy without explicit user approval. When work is done, summarize changes and ask "Deploy?" before running surge.

- **CHANGELOG.md before deploy** — Every change to the Samaya profile must be logged in `CHANGELOG.md` (at `profile-info-and-control/CHANGELOG.md`) with date, page(s), change description, and author. Update this BEFORE deploying. This enables version tracking and undo.

- **Code backup before changes** — Before making any code changes, create a timestamped backup: `cp -a v6/ v6-backups/v6-code-$(date +%Y%m%d_%H%M%S)` (code files only — HTML + CSS, skip images which are large and don't change).

- **NEVER run `surge logout` in the middle of a session** — it deletes `~/.netrc` which holds the only auth token. Recovery requires the user's password (interactive only). If you need to fix a stale session, instead try re-deploying or use `surge whoami` to check auth status first.
- **Surge auth recovery (if destroyed)**: If `~/.netrc` was deleted (e.g. accidental `surge logout`), recover in this order:
  1. **Plan A (fastest — direct .netrc write)**: Write the credentials file directly if you know the password:
     ```bash
     # Try both surge.sh and api.surge.sh — surge checks both hostnames
     cat > ~/.netrc << 'NETRC'
     machine surge.sh
       login user@example.com
       password yourpassword
     machine api.surge.sh
       login user@example.com
       password yourpassword
     NETRC
     chmod 600 ~/.netrc
     ```
     Verify: `surge whoami` should return the email. If "Not Authenticated", the password is wrong — move to Plan B.
  2. **Plan B (interactive PTY)**: If direct .netrc write fails (wrong password), use the interactive PTY approach:
     - `terminal(command='surge login', pty=true, background=true, notify_on_complete=true)`
     - `process(action='log', session_id=...)` — wait for `email:` prompt
     - `process(action='submit', data='email@example.com', session_id=...)`
     - `process(action='log', session_id=...)` — wait for `password:` prompt
     - `process(action='submit', data='password', session_id=...)`
     - `process(action='wait', session_id=..., timeout=10)` — check for "Success - Logged in"
     - Verify: `surge whoami`
     The `submit` action sends text + newline (unlike `write` which has no newline). If the password is rejected repeatedly via PTY pipe (common with special characters like @, #, $), the credentials are wrong — move to Plan C.
  3. **Plan C (user's terminal)**: Ask the user to run `surge login` directly in their terminal where they can see prompts and enter credentials interactively. Start a foreground PTY session: `terminal(command='surge login', pty=true)` — this blocks so the user can type.
- **Intermittent "permission denied" on surge deploy**: If a deploy that was working suddenly fails with "you do not have permission to publish to this domain", the surge auth session may have expired or the token was invalidated. Solution: run `surge logout` then `surge login` (with user's password) to regenerate `~/.netrc`.
- **OneDrive timeouts**: copying large dirs (>100MB) from OneDrive will time out. Always use selective copy (step 3) or `rsync` with long timeout.
- **Duplicate large images**: when replacing site images with HQ originals, don't copy the same large photo to multiple site paths (wastes bandwidth). Use different photos from the source folder for each target.
- **Free plan size limit**: Surge Student plan blocks deploys >~1GB. Optimize images before deploying.
- **`../` relative paths**: HTML in a subdirectory using `../assets/` will break when served from the Surge root. Always rewrite these.
- **New source folder: `06-Best-High-Res/`**: Contains 3-7MB JPEGs. These will increase deploy size quickly. Always run sips optimization before first deploy after adding them.
- **Missing files from URL-encoded paths**: Paths like `Oddy%20Test_Lab.jpg` may not exist on disk with the encoded name. Use `urllib.parse.unquote()` in Python when checking existence.
- **macOS TCC permission denial on Downloads files**: Files downloaded via browser/sandboxed apps may have extended attributes that prevent `cp`, `mv`, `ditto`, and `shutil.copy2()` — all return "Operation not permitted" even with `xattr -c`. When this happens:
  1. First try: `xattr -c <file>` to clear quarantine flags, then `cp`
  2. If that fails: ask the user to move the file from Downloads to Desktop or another unrestricted location via Finder (drag & drop), or run the `mv` command themselves
  3. Do NOT attempt workarounds like `cat >` redirection, `dd`, or Python `open()` — macOS TCC blocks read access at the kernel level for sandboxed downloads
  4. Prevention: copy photos from WhatsApp temp dir (`~/Library/Containers/net.whatsapp.WhatsApp/Data/tmp/documents/`) immediately when received, before they get quarantined
- **Surge deploy `TypeError: Cannot read properties of undefined (reading 'filename')`** — This cryptic error occurs on the local `surge` CLI (v0.27.4) for files >2MB, typically failing between 20-80% upload. The root cause is a bug in the local surge-stream that misparses the server error response, not file metadata issues.\n  - **`npx surge` is the fix**, not the xattr. The local CLI's surge-stream module (under `~/.npm-global/lib/node_modules/surge/`) has a known processing bug for large single-file uploads. `npx surge` downloads and runs a potentially different version that doesn't have the bug. This works RELIABLY — tested on multiple deploys of the same 6.7MB file where local `surge` failed.\n  - **`com.apple.provenance` xattr is a red herring**. macOS sets this immutable attribute on OneDrive-synced files. It persists through `cp`, Python I/O, bash redirection, and Hermes `write_file`. It does NOT block `npx surge` or the local `surge` CLI — files carrying this attribute deploy successfully with `npx surge`. Do not waste time trying to remove it.\n  - **Fresh directory fix (when it helps)**: creating a FRESH deploy directory from scratch (`mkdir -p /tmp/fresh-deploy && cp files /tmp/fresh-deploy/`) resolves stale-metadata errors on the local CLI for small files, but does NOT fix the `npx surge`-needing cases for large files.\n  - **Large embedded-base64 files**: Standalone HTML files with embedded base64 images (5-7MB) reliably trigger this error on the local `surge` CLI. Deploy with `npx surge` instead, or externalize assets to shrink the HTML under 1MB.\n- **Slow upload monitoring**: For large files (5+ MB), use a PTY background process with periodic `process(action='wait')` polling to track upload progress. Surge Student plan uploads at ~0.5-1 Mbps, so a 6.7MB file takes 5-10 minutes. Do NOT timeout at 180s — use 600s timeout or chain `process(action='wait')` calls. `npx surge` uploads at the same speed but doesn't crash partway.
- **`npx surge` fallback**: When the installed `surge` CLI fails (TypeError, permission errors), try `npx surge` as an alternative — it may use a different version or bypass corrupted local state.
- **504 cold start**: Surge sometimes returns 504 Gateway Timeout on the first hit after a new deploy (cold CDN cache). Wait 10s and retry — second hit returns 200.
- **CDN edge staleness**: After deploy, old content may serve for 10-30 seconds because Surge edge nodes serve cached versions while they re-fetch from origin. The deploy itself is correct. If the user reports "still same", tell them to hard-refresh (Cmd+Shift+R) rather than re-deploying.
- **Verification gotcha**: `curl` right after deploy may hit a stale edge node with old content. Wait 5-10s and retry for an accurate check.
- **Back-cover edits in single-page HTML**: When adding QR codes, phone numbers, or contact info to the last page, search for `ed-back-cover` or `page ed-back-cover` IDs. The back cover usually has inline styles — patch inline, no CSS changes needed.
- **Phone number formatting in contact grid**: User's personal mobile formatted as `+966 XX XXX XXXX` with gold highlight (`var(--gold)`). Add as a separate `<span>` below existing numbers.
- **Text conciseness preference** — User said "dont talk too much" about descriptive text. They prefer brief, bullet-point-style content over paragraphs. When writing section descriptions (e.g. 3D scanning process, HSE philosophy, etc.), keep each step to 1 line with keywords separated by `·`. Arabic should match the same conciseness level. Avoid marketing fluff ("no compromise, no approximation") — just state the facts.
- **Replica gallery overflow -> curate to one page** — When 10+ photos are added to the Replica Works Gallery page (p13b) and it overflows A4, the user prefers curation over multi-page. Pick the best 6 (2 rows of 3) or 9 (3 rows of 3) most representative/impressive photos and remove weaker duplicates. Use `delegate_task` to Claude with curation criteria.
- **Last-page QR code balance** — On the back cover, the QR code in the Online column needs visual balance. Adjust: size from 20mm→18mm, border from 0.6px→0.5px gold semi-transparent, border-radius from 1.5mm→1mm, padding from 1.5mm→1mm, margin-top from 2.5mm→1.5mm (closer to text).

## Site enhancement before deploy

### A. External cover photo

When the user asks to replace the cover photo with an image from another website:

1. **Browse the source site** to find hero/cover images — check `browser_get_images()` for direct URLs
2. **Download** with `curl -sL -o <dest> <url>`
3. **Place** in the project's cover asset dir (e.g. `assets/img/01-cover/`)
4. **Update** the CSS reference — usually a `background:` rule on `.v3-cover .v3-photo-img`
5. **Optimize** with sips (resize max 1920px, JPEG Q85)
6. Rebuild deploy directory and redeploy

```bash
curl -sL -o assets/img/01-cover/hero-cover.jpg "https://source-site.com/assets/hero.jpg"
sips --resampleWidth 1920 --setProperty format jpeg --setProperty formatOptions 85 \
  assets/img/01-cover/hero-cover.jpg --out assets/img/01-cover/hero-cover.jpg
```

### B. QR code on back cover

When the user wants a QR code linking to the deployed site:

1. **Generate QR** via `api.qrserver.com`:
   ```bash
   curl -sL -o assets/img/brand/qr-<label>.png \
     "https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=<encoded-url>&margin=10"
   ```
2. **Save** in `assets/img/brand/` or appropriate location
3. **Edit the back cover HTML** (find `ed-back-cover` section):
   - Add `<img>` with QR code reference
   - Style: white background (`background:#fff; padding:2mm;`), rounded corners (`border-radius:1mm;`), ~28mm
   - Add URL label below in small muted text
   - Add below the contact grid, centered
4. **Add personal phone** if requested: insert a highlighted `<span>` in the Phone column with gold color

```html
<div style="display:flex; flex-direction:column; align-items:center; margin-top:5mm; gap:1.5mm;">
  <img loading="lazy" decoding="async" src="../assets/img/brand/qr-profile.png"
       alt="QR: your-domain.surge.sh"
       style="width:28mm; height:28mm; border-radius:1mm; background:#fff; padding:2mm;">
  <span style="font-family:'Inter',sans-serif; font-size:6.5pt; letter-spacing:.15em; color:rgba(255,255,255,.6);">your-domain.surge.sh</span>
</div>
```

## Post-deploy design iteration (Claude Code)

**User preference: ALWAYS use Claude Code for photo replacements and design changes**, not manual HTML patching. The user explicitly stated to use claude for design work — this means delegate HTML/CSS photo swaps, layout tweaks, and design adjustments to Claude Code via delegate_task, rather than using patch/terminal yourself.

**Cover slogan is SACRED**: The cover tagline (صناعة الإرث. هندسة الفنّ. / Crafting Legacy. Engineering Art.) must NEVER be changed during any redesign. Claude will try to rewrite it during editorial passes — this must be explicitly protected in the delegation prompt to Claude.

**write_file DESTROYS entire files**: Never use write_file on existing multi-file projects. In this session it destroyed the entire 4276-line 30-redesign.css. Always use patch() for targeted edits. write_file is only safe for creating new single files.

### Page-by-page overflow audit workflow

When the user asks to "audit page by page for overflow":

**Phase 1 — Audit (Claude):**
- Go through every page section (by id="pX") in index.html
- For each page, read the HTML section + its CSS rules
- Check: does `.content` have `height: calc(210mm - 22mm - 14mm)` or `overflow: hidden`?
- Estimate: total content height vs ~174mm content area
- Flag pages where content clearly exceeds the available area
- Report in a table: page ID, risk level (OK / MARGINAL / HIGH / CRITICAL), reason

**Phase 2 — Fix (Kimi):**
- For each flagged page, fix by:
  - Removing fixed `height: calc(210mm - 22mm - 14mm)` on `.content` blocks
  - Changing `overflow: hidden` to `overflow: visible` (page level only)
  - Reducing image heights (hero photos, gallery tiles, card thumbnails)
  - Tightening gaps (gap: 2mm → 1.5mm, etc.)
- Verify fix doesn't break layout

**Common overflow fixes by reduction:**
| Element type | Original | Reduced |
|---|---|---|
| Materiality grid cells | 46-48mm | 22mm (if 48+ cells) |
| Capacity hero photo | 62mm min-height | 45mm |
| Gallery tile images | 28-30mm | 24-25mm |
| 3D scanning hero | 42mm | 36mm |
| QA instrument images | 24mm | 20mm |
| Project card gaps | 1mm | 0.6mm |
| CMYK bar | 5mm | 3.5mm |

**Pitfall — modal grid pages (ed-spread)**: Pages using `.ed-spread .content` with `grid-template-rows: minmax(0, 1fr)` cannot overflow — they force content to fit. Only check non-modal pages (v4-capacity, v4-materiality, v4-replica-gallery, etc.).

### TOC update after page changes

Whenever a section is added, removed, or renumbered, the **Table of Contents** (section id="p2") must be updated to match. The TOC lists all sections with page numbers. Steps:
1. Read the current TOC entries
2. Map actual page IDs to their section-tag text
3. Update any entry where the page number or title has changed
4. If a new page was added (e.g. p13b), insert a new entry in the correct position
5. If a page was removed, delete its TOC entry
6. Verify total entry count matches total section count

### Flagship hero photo flipping

Alternate the hero photo side (left/right) across flagship project pages for visual rhythm. The `.proj-flagship .content` is a 2-column grid (`grid-template-columns: 1.2fr 0.8fr`). In RTL, the first DOM child appears on the RIGHT (larger column), second on the LEFT. To flip: swap the DOM order of `.pf-panel` and `.pf-hero` for alternating pages. No CSS changes needed.

### Full-profile overflow audit checklist

Before deploying after any batch of changes, run this check:
1. `rg 'height: calc\\(210mm' css/` — should return 0 results
2. `rg 'overflow: hidden' css/ | grep '\.content'` — should return 0 results
3. Count `<section` vs `</section>` in index.html — should be equal
4. Check TOC entries match actual section IDs
5. Verify cover slogan is untouched

After the initial deploy, the user often asks to **consult Claude Code for design improvements** on specific pages:

1. **Give Claude the full context**: pass the relevant HTML section + CSS class definitions + brand color palette
2. **Specify the design brief clearly**: "more readable", "play with text and charts", "professional", "like a McKinsey deck"
3. **Include exact data points** for charts/stats — don't let Claude guess numbers
4. **Always include brand colors**: navy `#1E293B` (`--v3-ink`), gold `#C9A24B` (`--v3-gold-deep`/`--v3-gold`), cream `#F6F0E4` (`--v3-paper`)
5. **Font stack**: Tajawal (Arabic), Inter (English UI), Cormorant Garamond (serif/italics)
6. **Request inline SVG for charts** (not CSS div bars) — SVGs scale better, look cleaner
7. **Always backup the HTML before delegating**: `cp index.html index.html.bak` — Claude's patches are narrow but can accidentally break other pages via CSS conflicts or tag mismatch

After Claude applies changes, verify: `grep -c '<section'` vs `'</section>'` balance, then rebuild deploy dir and redeploy.

This is especially relevant for:
- Cover page photo replacements
- Stat/data visualization on capacity pages (page 4)
- Back-cover contact/QR integration
- Any "page N" design tweak

## Adding new photos to Samaya profile sections

When the user sends new photos (from Orders/website-ready/) for the Samaya Factory profile, they go through structured placement:

### Photo source structure

All photos come from:
```\nOneDrive-SAMAYAINVESTMENT/Samaya/Orders/2025/00000 صور واتساب سنة 2025 الورشة/classified/website-ready/\n  ├── 01-Finished-Products/     → finished project installation photos\n  ├── 02-Workshop-Environment/  → workshop/fabrication process photos\n  ├── 04-Material-Samples/      → material sample / detail photos\n  ├── 05-Opening-Ceremony/      → event/opening ceremony installation photos\n  └── 06-Best-High-Res/         → high-resolution hero images (3-7MB each)
- `Downloads/Production/` — WhatsApp images saved to the Downloads/Production/ subfolder (e.g. Kaaba door photo)\n```\n\n**Additional source folders (not under website-ready/):**\n- `.../011/` — material & workshop photos (same categories, flat structure)\n- `.../review/needs-vision-check/` — unclassified photos awaiting review\n\n**Desktop drop source**: user may drag photos from WhatsApp/iMessage directly to `~/Desktop/`. When this happens, the source path is `~/Desktop/<filename>` — no deep OneDrive path needed. Copy from there like any other source.

**WhatsApp/iMessage temp directory**: photos sent via WhatsApp appear in `~/Library/Containers/net.whatsapp.WhatsApp/Data/tmp/documents/<UUID>/PHOTO-*.jpg` where `<UUID>` is a hex string directory. These are temporary files — copy immediately as they may auto-delete. Use `ls -lh` on the full path to verify size before copying.

### Target asset folders

```
samaya-profile/assets/img/projects/
  ├── wayfinding/              → signage/wayfinding photos
  ├── material-samples/        → material detail photos
  ├── madinah-royal-reception/ → royal reception photos
  └── ... (per-project folders)
```

### Placement by section

| User says | Target section | Image slot |
|---|---|---|
| whyfinding / lables / signage | p15 (Wayfinding System) | v4-type-workshop 4-5 column gallery below sign families. Photos can come from ANY source subfolder (Workshop-Environment, Material-Samples, or Finished-Products) |
| "material" / "wood" / "chair" | p24c (Materiality & Craft) | Add `pmat-cell` to `pmat-grid` before closing `</div>` |
| "quoran kareem" / "متحف القرآن" | p4-flag4 (Quran Museum) or any flagship | `pf-detail` in `pf-details` grid |
| "banquet" / "royal reception" | p4-flag6 (Madinah Royal Reception) | `pf-detail` in `pf-details` grid, or `pf-hero` |
| "comprehensive scope" / "scope" hero | p5 (Comprehensive Scope) | Hero background-image on `.v4-scope-hero`. If user wants side-by-side 2-column photos, delegate to Claude Code — convert to flex layout with `.v4-scope-hero-col` children separated by a gold hairline divider |
| "bim" / "engineering" / "methodology" | p18 (Engineering & BIM) | Replace the pipeline stage photo directly (see pipeline replacement section below) |

### Caption format

Use bilingual AR/EN with bold English keyword prefix in `pmat-cell`:
```html
<span class="pmat-cell-cap"><strong>English keyword</strong>Arabic description</span>
```

For wayfinding gallery captions:
```html
<span class="v4-type-workshop-cap">EN LABEL · وصف عربي</span>
```

### Flagship page bottom alignment fix

When the user says "not aligned bottom" for flagship pages (pf-details vs pf-hero):

The fix is a 2-part CSS change:

**1. pf-facts: add `flex: 1`** to push pf-details to the bottom:
```css
.proj-flagship .pf-facts {
  flex: 1; min-height: 0;
}
```

**2. pf-panel bottom padding** to match hero overlay padding (4mm):
```css
.proj-flagship .pf-panel {
  padding: 10mm 8mm 4mm 10mm;
}
```

**3. pf-details: remove `margin-top: auto`** — it's redundant when pf-facts has flex:1:
```css
.proj-flagship .pf-details {
  display: grid; grid-template-columns: 1fr 1fr; gap: 2mm;
  /* no margin-top: auto, no padding-bottom */
}
```

This works because:
- `.proj-flagship .content` is `display: grid; grid-template-columns: 1.2fr 0.8fr;`
- Both columns (pf-hero and pf-panel) are in the same grid row — same height
- `flex: 1` on pf-facts makes it grow to fill space, pushing pf-details to the panel bottom
- 4mm padding-bottom on pf-panel matches the hero overlay's 4mm padding-bottom
- Visual result: small photos bottom edge aligns with hero overlay text

### Wayfinding workshop gallery CSS

When adding 4-5 workshop/signage photos below the sign families in p15:

```css
.v4-type-workshop {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr 1fr 1fr; /* 5 columns */
  gap: 2mm;
  margin-top: auto;
}
.v4-type-workshop-img {
  position: relative;
  background: center/cover no-repeat var(--v3-line-soft);
  height: 32mm;
  border: 0.4pt solid var(--hairline);
  overflow: hidden;
}
.v4-type-workshop-cap {
  position: absolute;
  inset-inline: 0;
  bottom: 0;
  font-family: 'Inter', sans-serif;
  font-size: 6pt;
  font-weight: 600;
  letter-spacing: 0.08em;
  color: var(--paper);
  background: linear-gradient(to top, rgba(11,31,63,0.8), transparent);
  padding: 3mm 2mm 1.5mm;
  display: block;
}
```

### Replicas tile photo swapping

The user may ask to swap photos between the 3-tier tiles (01 Museum Grade, 02 Scenography Grade, 03 Arch. Model) in section p13. Pattern: replace the `background-image` URL on each tile's `.v4-tier-tile-img` div.

### Adding featured images to the Replicas gallery (v4-tier-gallery)

**CRITICAL: DO NOT append to the SCOPE page (p13).** The Replicas section (p13, SCOPE 04) is the 3-tier grade grid page — the user explicitly rejected having work photos appended here (phrase: "why you cancel the SCOPE 04 page its very important you can add another page for work photos but dont replace").

Instead, create a **separate standalone page** (p13b) between p13 and p14 with its own header/eyebrow/grid:

```html
<section class="page v4-replica-gallery" id="p13b" dir="rtl">
  <header class="page-header">...</header>
  <div class="content">
    <div class="v4-replica-gallery-head">...</div>
    <div class="v4-replica-gallery-grid"><!-- 3-col grid of items --></div>
  </div>
  <footer class="page-footer">
    <div>REPLICA WORKS GALLERY · N PROJECTS</div>
    <div class="num">13b</div>
  </footer>
</section>
```

**CSS for replicas gallery:**
```css
.v4-tier-gallery {
  display: grid;
  grid-template-columns: repeat(4, 1fr); /* adjust as needed */
  gap: 2mm;
  margin-top: 3mm;
}
.v4-tier-gallery-img {
  position: relative;
  background: center/cover no-repeat var(--v3-line-soft);
  height: 48mm;
  border: 0.4pt solid var(--v3-line);
  overflow: hidden;
}
.v4-tier-gallery-overlay {
  position: absolute;
  inset-inline: 0;
  bottom: 0;
  background: linear-gradient(to top, rgba(11,31,63,0.85), transparent);
  padding: 4mm 6mm 3mm;
}
.v4-tier-gallery-en {
  font-family: 'Inter', sans-serif;
  font-size: 10pt;
  font-weight: 700;
  letter-spacing: 0.08em;
  color: var(--paper);
  display: block;
}
.v4-tier-gallery-ar {
  font-family: 'Tajawal', sans-serif;
  font-size: 8pt;
  color: var(--gold-light);
  display: block;
  margin-top: 0.5mm;
}
```

### Engineering pipeline photo replacement — NEVER add gallery blocks

**CRITICAL PREFERENCE**: When the user says "add photos to ENGINEERING & BIM" or references any pipeline stage by number (01 MODEL, 02 SHOP DRAWING, 03 CNC, 04 ASSEMBLY), they want to **REPLACE the existing pipeline stage photo**, not add a new gallery block below the pipeline.

The 4-stage pipeline in section p18 (class `v4-blueprint`) has these stages with current photos:
- **Stage 01 (MODEL · BIM)**: `04-bim-engineering/bim-screen-1.jpg`
- **Stage 02 (SHOP DRAWING)**: `projects/from-work/safia-museum-engineering-cad.jpg`
- **Stage 03 (CNC · CAM)**: `05-machinery-cnc/cnc-router-technician.jpg`
- **Stage 04 (ASSEMBLY · ON-SITE)**: `projects/from-work/quba-mosque-onsite-installation.jpg`

**Workflow for each stage replacement:**
1. Copy the new photo to `assets/img/projects/bim/<descriptive-name>.jpg`
2. Find the `<article class="v4-blueprint-stage">` for the requested stage number
3. Replace the `background-image` URL in the `style=` attribute on the `.v4-blueprint-stage-photo` div
4. Update the `aria-label=` to match the new photo content
5. Remove any `background-position:` override if the new photo is well-composed
6. Do NOT add a `.v4-blueprint-bim` block — the pipeline itself is the gallery

**Pitfall — DO NOT add gallery blocks**: Previously the skill documented creating a separate BIM gallery block below the evidence band. This was wrong and was explicitly rejected by the user. The pipeline IS the gallery — replace the stage photos directly.

**Pitfall — subagent corruption of adjacent sections**: When delegating broad HTML redesigns to Claude Code via `delegate_task`, the subagent may inadvertently modify OTHER sections of the HTML outside the scope of the task (e.g., a wayfinding page redesign corrupted the Hakaia Elm flagship section's pf-details and hero photos). Always:
1. Limit the context passed to the subagent to ONLY the relevant section ID range
2. After the subagent returns, verify 2-3 adjacent sections are unchanged
3. Run a quick `grep` count on key patterns (`pf-detail`, `pf-hero`) before and after to detect drift

**Pitfall — wayfinding photos must be finished installed signage**: The wayfinding section (p15) was rejected as "total wrong" because it showed workshop fabrication photos instead of finished installed signs. Rule: every photo in the 3 sign-family cards and the hero mockup must show a REAL INSTALLED SIGN, not a fabrication-in-progress shot. Workshop/fabrication photos belong in the Materiality grid (p24c), not in the wayfinding page.

### Caption quality — write descriptive, not generic

When the user sends photos with brief descriptions like "wood work skirting" or "furniture chair", **always expand the caption into a proper bilingual label**. The user explicitly said "you have to rewrite description alwayes" — this is a hard requirement, not optional.

**Rule**: Never use the user's short description verbatim as the caption. Always compose a full bilingual AR/EN label with:

Format: **bold English keyword** (for scannability) + Arabic translation + em-dash elaboration. The caption should tell the reader what specific process or material is shown, not just repeat the filename.

User correction signal: "you have to rewrite description alwayes" = stop using generic labels derived from filenames; always compose a proper bilingual descriptive caption.

### Adding cells to the Materiality grid

Insert new `pmat-cell` blocks before the closing `</div>` of `pmat-grid`:

```html
<div class="pmat-cell">
  <div class="pmat-cell-img" style="background-image:url('../assets/img/projects/material-samples/filename.jpg');"></div>
  <span class="pmat-cell-cap"><strong>EN label</strong>AR description</span>
</div>
```

Then update the footer text: `"MATERIALITY & CRAFT · N PROCESS DETAILS · 100% IN-HOUSE"` incrementing N.

**Pitfall — counter drift**: Every time you add a new `pmat-cell`, the footer counter `· N PROCESS DETAILS ·` must be incremented manually. This is a single find-replace — there is only one such line in the HTML. Forgetting it leaves a stale count (e.g. showing 8 when there are actually 15 cells). Set a reminder or use the new count as the replacement trigger.

### Materiality grid sizing — multi-page fix for 30+ cells

When the user has added 30+ photos to the Materiality grid and says they're "verysmall croped cant see it":

**Problem**: The CSS uses `grid-auto-rows: 1fr` which makes every row the same size, splitting available A4 page height equally. With 30+ cells at 4 columns = 8+ rows, each row gets ~20mm — too small.

**Fix — 3 CSS changes:**

1. `grid-auto-rows: 1fr` → `grid-auto-rows: auto` — rows size to their content
2. Remove `overflow: hidden` from the parent `.content` — allows content to flow to subsequent printed pages
3. Use `background-size: contain` (NOT `cover`) — user explicitly prefers seeing the full photo without cropping

```css
.proj-materiality .pmat-grid {
  flex: 1; min-height: 0;
  display: grid; grid-template-columns: repeat(4, 1fr);
  grid-auto-rows: auto;  /* was 1fr — rows now size to content */
  gap: 2mm;
}
.proj-materiality .pmat-cell-img {
  background-size: contain; background-position: center; background-repeat: no-repeat;
  height: 48mm;           /* increase from 34mm so photos are clearly visible */
  border: 0.4pt solid var(--hairline);
}
.proj-materiality .content {
  padding: 5mm 6mm;
  display: flex; flex-direction: column; gap: 3mm;
  /* no overflow: hidden — allows multi-page flow */
}
```

**CRITICAL — `contain` vs `cover`**: The user corrected this TWICE. `background-size: cover` crops photos to fill the container, which the user explicitly rejected ("photos croped cant see any of it"). Always use `background-size: contain` for the Materiality grid so the full image is visible. The empty space around the image is filled by the container's background (paper color).

**Result**: Each image is 48mm tall × ~70mm wide (4-col). With ~57mm per row (image + caption + gap), 40+ cells span ~4-6 printed A4 pages. The user explicitly accepted multi-page overflow (phrase: "you can make more than one page no problem").

### Comprehensive Scope hero — dual-photo layout

When the user asks to "add side by side photos" to the COMPREHENSIVE SCOPE hero (p5):

**Delegate to Claude Code** — this requires redesigning the HTML/CSS layout from a single `background-image` div to a flex container with two side-by-side photo columns:

1. Replace the `.v4-scope-hero` single div with a flex container
2. Add two child `.v4-scope-hero-col` divs, each with `flex: 1 1 50%`
3. Add a gold hairline divider between columns: `.v4-scope-hero-col + .v4-scope-hero-col { border-inline-start: 0.5pt solid rgba(162, 141, 98, 0.35); }`
4. The caption overlay (eyebrow + title + tag) stays on the parent, spanning both columns
5. Each column gets its own `background: center/cover no-repeat` with a different photo

**CSS summary:**
```css
.v4-scope-hero {
  display: flex;
  flex-flow: row nowrap;
  overflow: hidden;
}
.v4-scope-hero-col {
  flex: 1 1 50%;
  background: center/cover no-repeat var(--v3-line-soft);
  min-block-size: 200px;
}
```

**Result**: Two distinct photos side-by-side with a common caption overlay and subtle gold seam between them.

### Global CSS overflow fix for multi-page profiles

When the user says "fix all pages overflow" or a specific page overflows the A4 landscape format:

**Root cause**: The profile uses a global page constraint in `00-tokens.css`:
```css
.page { width: 297mm; height: 210mm; overflow: hidden; }
```
And most section `.content` divs have:
```css
.content { overflow: hidden; height: calc(210mm - 22mm - 14mm); }
```

These clamp EVERY page to exactly one A4 sheet. Content over 210mm is silently clipped.

**Fix pattern (applied across all CSS files):**

1. **Global page rule** (00-tokens.css):
   ```css
   .page {
     height: auto;       /* allow growth */
     min-height: 210mm;  /* still A4 minimum */
     overflow: visible;  /* don't clip */
   }
   ```

2. **All section `.content` blocks** — remove the fixed height and overflow hidden:
   - Search across `17-archetypes.css`, `18-projects.css`, `30-redesign.css`, `19-org.css`, `20-redesign.css`
   - Remove `height: calc(210mm - 22mm - 14mm)` from every `.content` rule
   - Remove `overflow: hidden` from every `.content` rule (keep overflow:hidden on internal elements like photo grids, cards — those are fine)
   - Fix one-off variants like `height: calc(210mm - 16mm - 14mm)` too

3. **Bulk fix using sed**:
   ```bash
   for f in 17-archetypes.css 18-projects.css 30-redesign.css 19-org.css 20-redesign.css; do
     sed -i '' 's/height: calc(210mm - 22mm - 14mm);//g' "$f"
     sed -i '' '/.content {.*overflow: hidden/s/overflow: hidden;//g' "$f"
   done
   sed -i '' 's/height: calc(210mm - 16mm - 14mm);//g' 30-redesign.css
   ```

**Pitfall — some overflow:hidden are intentional**: Cover pages, back-cover, photo containers with `border-radius`, and card bodies with `text-overflow: ellipsis` all need their overflow hidden. Only remove overflow:hidden from `.content` (the page-level content wrapper) and `.page` (the outer container).

## Deploying React/Vite SPAs

When deploying a React app built with Vite (or any SPA with `dist/` output):

1. **Build first**: `npm run build` in the project root → outputs to `dist/`
2. **Deploy from dist/**: `cd dist && surge --project ./ --domain your-domain.surge.sh`
3. **Check chunk size warning**: Vite warns when bundles exceed 500KB. This is informational, not blocking.

### Subdirectory deployment (domain.com/app/)

If the app is served from a subdirectory (not the root):

1. **All paths must be prefixed** with the subdirectory. In Vite, set `base: '/app/'` in `vite.config.ts`:
   ```ts
   // vite.config.ts
   export default defineConfig({
     base: '/app/',
     // ...
   })
   ```

2. **Image/asset paths in data files** must also be prefixed. If gallery data contains hardcoded paths like `/images/photo.jpg`, change them to `/app/images/photo.jpg`.

3. **Rebuild** after changing the base path: `npm run build`

4. **Deploy same as root**: `cd dist && surge --project ./ --domain domain.surge.sh`

The app will be accessible at `domain.surge.sh/app/`.

### Hostinger subdomain deployment (LAMP host)

When deploying to a Hostinger (or similar LAMP host) with a subdomain:

1. **Verify host**: `curl -sI https://domain.com | grep -i 'server\|x-powered-by'` — check for LiteSpeed + PHP support.

2. **Find the document root** via SSH:
   ```bash
   ssh user@host "find /home/user -maxdepth 4 -name 'public_html' -type d"
   ```

3. **Subdomain not auto-configured**: DNS may resolve but Hostinger may not create the directory structure automatically. Create it: `mkdir -p ~/domains/subdomain.domain.com/public_html/`. If 404 persists, the document root is elsewhere — deploy to main domain's `public_html/` under a path prefix instead.

4. **Upload**:
   ```bash
   tar czf /tmp/deploy.tar.gz -C dist/ .
   scp -P 65002 /tmp/deploy.tar.gz user@host:~
   ssh user@host "cd ~/domains/subdomain.domain.com/public_html && tar xzf ~/deploy.tar.gz && rm ~/deploy.tar.gz"
   ```

5. **.htaccess rewrites** on the main domain may block your subdirectory — add a `RewriteCond %{REQUEST_URI} !^/app/` exclusion.

### Automated deploy with sshpass

For scripted deploys where interactive password entry isn't possible:
```bash
sshpass -p 'password' scp -P 65002 /tmp/deploy.tar.gz user@host:~
sshpass -p 'password' ssh -p 65002 user@host "cd /path && tar xzf /tmp/deploy.tar.gz"
```

## Related

- `claude-code` — full delegation reference, especially the design-consultant pattern
- `samaya-technical-office` — for Samaya-specific project workflows
- `html-print-layout` — if the deployed HTML needs print formatting
- `samaya-proposals` — bilingual HTML proposal generation workflow
- `references/samaya-photo-replacement.md` — HQ photo mapping & batch optimization for Samaya profile
- `references/qr-code-back-cover.md` — QR code generation and back cover enhancement
