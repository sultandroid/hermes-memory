---
name: web-hosting-deployment
description: Deploy React/Vite/static apps to shared web hosting (Hostinger, cPanel) with SSH. Covers subdirectory path fixes, PHP data persistence, and asset path management.
tags: [hosting, deployment, php, ssh, hostinger, static-site, react, vite]
---

# Web Hosting Deployment Workflow

## Trigger

User asks to deploy a static app (React/Vite build) to a shared web host (Hostinger, cPanel, etc.) accessible via SSH.

## Prerequisites

- SSH access to the web host (credentials or key-based)
- A production build of the app (`npm run build` or equivalent)
- Knowledge of the web root path

## Steps

### 1. Build the app

```bash
cd app/ && npm run build
# Output: dist/ (or build/)
```

### 2. Check for subdirectory deployment

If the app will be served from a subdirectory (e.g. `domain.com/aseer/`), ALL asset paths must be absolute-from-root with the subdirectory prefix:

- `/images/photo.jpg` → `/aseer/images/photo.jpg`
- `/assets/style.css` → `/aseer/assets/style.css`

**Search and fix ALL absolute paths** in the source before building:

```bash
# Find all absolute asset references
grep -rn "src=\"/" src/ --include="*.tsx" --include="*.ts" --include="*.jsx"
grep -rn 'href="/' src/ --include="*.tsx" --include="*.ts" --include="*.jsx"
```

Replace any with the subdirectory prefix:

```bash
# Example: replace /images/ → /aseer/images/ everywhere
sed 's|/images/|/aseer/images/|g' src/path/to/file.tsx
```

**Common offenders:**
- Gallery image filenames (hardcoded in data files)
- Logo paths in hero/header sections
- Background images in CSS
- Any hardcoded URL paths

Remember: images copied to `public/images/` in Vite are served at `/images/file.png` by default. If the app is at a subdirectory, they become `/subdir/images/file.png`.

### 3. Package the dist

```bash
tar czf /tmp/deploy.tar.gz -C dist .
```

### 4. Upload via SSH

```bash
# SCP the tarball
scp -P <port> -o StrictHostKeyChecking=no /tmp/deploy.tar.gz user@host:/home/user/

# SSH in and extract
ssh -p <port> user@host "
  cd /path/to/web-root/<subdir> &&   # or create the subdirectory
  tar xzf /home/user/deploy.tar.gz && 
  rm /home/user/deploy.tar.gz
"
```

**For clean replacement (subdirectory build):** Replace the entire subdirectory rather than merging into it:

```bash
ssh -p <port> user@host "
  cd /home/user/domains/domain.com/public_html/build &&
  rm -rf subdir && mkdir subdir && cd subdir &&
  tar xzf /home/user/deploy.tar.gz &&
  rm /home/user/deploy.tar.gz
"
```

This ensures stale files from previous deploys are removed. The `rm -rf && mkdir` pattern is cleaner than overwriting for production deployments where file deletions matter.

**⚠ SSH times out with raw IP but hostname works:** The raw server IP may block SSH while the hostname resolves to a different network interface (behind CDN/proxy gateway). Always try the hostname first if the IP times out. Update deploy scripts to use the hostname, not the raw IP.

### 5. Verify

```bash
curl -sL "https://domain.com/subdir/" | head -3
curl -sL "https://domain.com/subdir/images/logo.png" -o /dev/null -w "%{http_code}"
```

## PHP Data Persistence (Team Sync)

When the app needs to share data across users (e.g. hotspot positions, notes, settings) and the host supports PHP:

### Create a single PHP endpoint

```php
<?php
// sync.php — drop-in API for reading/writing JSON data
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

$dataDir = __DIR__ . '/hotspot-data';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $gallery = $_GET['gallery'] ?? '';
    $view = $_GET['view'] ?? '';
    $file = "$dataDir/{$gallery}_{$view}.json";
    header('Content-Type: application/json');
    echo file_exists($file) ? file_get_contents($file) : '[]';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $body = json_decode(file_get_contents('php://input'), true);
    $key = "{$body['gallery']}_{$body['view']}";
    file_put_contents("$dataDir/{$key}.json", json_encode($body['hotspots'], JSON_PRETTY_PRINT));
    echo json_encode(['ok' => true]);
    exit;
}
```

### Update the app to use the PHP endpoint

In the app's storage layer, replace or augment localStorage calls with fetch to sync.php:

```typescript
// Use empty string to disable sync, set URL to enable
const SYNC_URL = ''; // Set to 'https://domain.com/subdir' when deploying with PHP
const SYNC_ENABLED = !!SYNC_URL;

function apiUrl(galleryId: string, viewName: string): string {
  return SYNC_URL
    ? `${SYNC_URL}/sync.php?gallery=${galleryId}&view=${viewName}`
    : `sync.php?gallery=${galleryId}&view=${viewName}`;
}

async function loadFromServer(gallery: string, view: string) {
  try {
    const res = await fetch(`${apiUrl(gallery, view)}`);
    const data = await res.json();
    return Array.isArray(data) && data.length > 0 ? data : null;
  } catch { return null; }
}

async function saveToServer(gallery: string, view: string, hotspots: any[]) {
  try {
    await fetch(`${SYNC_URL}/sync.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ gallery, view, hotspots }),
    });
  } catch { /* silent fallback */ }
}
```

```

Strategy: try server first, fall back to localStorage. Save to both when writing.

### Data Concurrency Considerations

The PHP flat-file approach is last-write-wins — if two team members edit simultaneously, one's changes overwrite the other's. For teams this is acceptable for low-contention data (hotspot positions) but not for collaborative document editing.

Mitigations:
- Add a `modified_at` timestamp to the PHP response and warn users when their local data is stale
- Consider showing a save-status toast in the UI (green = synced, red = local-only) so users know when a sync failed

### Upload the PHP file

```bash
# Include sync.php in the dist/ before tar
cp sync.php dist/sync.php
tar czf /tmp/deploy.tar.gz -C dist .
# ... upload and extract as usual ...
chmod 755 /path/to/sync.php
```

## React Stale-Closure Fix via useRef

When React event handlers read state values that don't depend on the most recent render (e.g., inside `useCallback` or inline JSX handlers), the closure may capture a stale value. This commonly causes:
- Tooltips disappearing immediately after clicking a pin (the `onMouseLeave` handler fires with the old `pinnedCode=null` before the state update re-renders)
- Conditional logic evaluating the wrong state between `setState` and the next render

**Fix:** Mirror the state in a `useRef` and read from the ref in event handlers:

```tsx
const [pinnedCode, setPinnedCode] = useState<string | null>(null);
const pinnedRef = useRef<string | null>(null);  // mirrors pinnedCode

// On state change, update BOTH:
const handleClick = () => {
  setPinnedCode('val');
  pinnedRef.current = 'val';
};

// In event handlers, read from ref (always latest):
const handleMouseLeave = () => {
  if (!pinnedRef.current) setTooltip(null);  // ✅ always correct
};
```

The ref updates synchronously inside the same call as `setState`, so any event handler that fires before the next render will read the correct value. This pattern is essential for mouse/touch event handlers that fire between `setState` and the React re-render.

## Tooltip Card Viewport Clamping

When rendering an absolute/fixed-position tooltip card on mouse hover or pin click, the card can overflow the viewport. Basic `Math.min()` clamping on the right/bottom edges is insufficient — the card can still overflow left, top, or both after a flip.

**Simple viewport clamp (preferred — keeps card near source):**

```tsx
const cardW = 340, cardH = 420;
const x = Math.max(10, Math.min(tx, window.innerWidth - cardW - 10));
const y = Math.max(10, Math.min(ty, window.innerHeight - cardH - 10));
```

This clamps the card position to stay within the viewport (+10px padding) without trying to flip sides. The card remains near the hotspot/pin it's pointing to.

⚠ **Do NOT use flip logic** — flipping to the opposite side of the cursor (e.g. `tx = e.clientX - cardW - 16`) makes the card appear far from the pin point, which users report as "card flying away from the hotspot." Simple `Math.min(Math.max(...))` clamping at all three entry points (mousemove, pin click, sidebar click) is sufficient and more predictable.

Apply this at every entry point that sets the tooltip position.

## Dynamic Field Groups for Heterogeneous Data

When the app displays items from different categories (e.g., Showcase, Object, Graphic, Setwork schedules) and each category has different fields, use a **field group configuration object** keyed by schedule type:

```tsx
const SCHEDULE_FIELD_GROUPS: Record<string, { label: string; fields: FieldDef[] }[]> = {
  'showcase_schedule': [
    { label: 'Showcase Info', fields: [
      { key: 'Showcase ID', label: 'ID', mono: true },
      { key: 'Showcase Type', label: 'Type' },
    ]},
    { label: 'Glass & Glazing', fields: [
      { key: 'Glass Thcikness', label: 'Thickness' },
      { key: 'No. of glass sides', label: 'Sides' },
    ]},
  ],
  'object_schedule': [
    { label: 'Object Info', fields: [
      { key: 'Object ID', label: 'ID', mono: true },
      { key: 'Artist', label: 'Artist' },
    ]},
  ],
  // ... per schedule type
};
```

Render dynamically by checking `hasValue()` on each field and only showing populated sections:

```tsx
function hasValue(mat: any, key: string): boolean {
  const v = mat[key];
  if (v === undefined || v === null) return false;
  const s = String(v).trim();
  return s !== '' && s !== 'None' && s !== 'n/a' && s !== '#VALUE!';
}
```

For schedule types not in the config, render a generic label:value grid of all non-standard fields. Add `BASE_FIELDS` set to exclude metadata fields from the generic display.

## Simple Admin Password Protection

To protect admin features without a full auth system:

```tsx
const [adminAuthed, setAdminAuthed] = useState(
  () => sessionStorage.getItem('admin_auth') === 'true'
);
const [adminPassword, setAdminPassword] = useState('');
const ADMIN_PW = 'yourpassword';

// Show password modal when admin mode is requested but not authenticated
{adminMode && !adminAuthed && (
  <div className="password-overlay">
    <form onSubmit={e => {
      e.preventDefault();
      if (adminPassword === ADMIN_PW) {
        sessionStorage.setItem('admin_auth', 'true');
        setAdminAuthed(true);
      } else {
        // Show error
      }
    }}>
      <input type="password" value={adminPassword} onChange={...} />
      <button type="submit">Unlock</button>
    </form>
  </div>
)}
```

Lock admin UI behind `adminMode && adminAuthed`. The password is a constant in the code — simple to change, keeps out casual users.

## SSH Reference (Hostinger)

When deploying to Hostinger from this machine:

```bash
# SSH config is at ~/.ssh/config with host alias
ssh <host-alias>

# Or direct:
sshpass -p '<password>' ssh -p <port> user@host_ip

# Common paths:
# Main domain:      /home/user/domains/domain.com/public_html/
# Main build dir:   /home/user/domains/domain.com/public_html/build/
# Subdomain:        /home/user/domains/sub.domain.com/public_html/
# Main public_html: /home/user/public_html/
```

Hostinger/LiteSpeed servers support PHP 8.x. The `.htaccess` may rewrite requests (e.g. `RewriteRule ^(.*)$ /build/$1 [L]`).

## Pitfalls

- **Absolute paths break in subdirectories**: The most common deployment error. `src="/images/pic.jpg"` resolves to `domain.com/images/pic.jpg` even when the app is at `domain.com/subdir/`. Always prefix with the subdirectory path or use relative paths.
- **PHP error pages on subdomain without proper config**: If a subdomain shows "This Page Does Not Exist" from Hostinger, the DocumentRoot may not be set. Either create the subdomain in hPanel or use the main domain's rewrite rules.
- **SSH key permissions**: `~/.ssh/id_rsa` must be `chmod 600`. Hostinger requires the correct user:group (`u517606786:o1009266348`).
- **Apple extended attributes**: macOS tar adds `._*` files (Apple metadata). These cause warnings on extraction but don't affect operation. Use `COPYFILE_DISABLE=1` or strip with `dot_clean` if they're a problem.
- **Tar from macOS to Linux**: Use `tar czf` on macOS, `tar xzf` on the server. Works across platforms despite LIBARCHIVE warnings.
- **Never assume localStorage is shared**: Each browser has its own localStorage. Team collaboration requires server-side persistence.
- **SSH times out with raw IP but hostname works**: The raw server IP (e.g. `92.113.28.249`) may block SSH while the hostname (`samaya-factory.com`) resolves to a different network interface (behind CDN/proxy). Always try the hostname if the IP times out. Update deploy scripts to use hostname, not raw IP.
- **PHP data directory must be outside the build directory**: If `sync.php` stores data at `__DIR__ . '/hotspot-data'` and the deploy script does `rm -rf <build-dir> && mkdir <build-dir>`, ALL saved data is wiped on every deploy. Store data at `__DIR__ . '/../../hotspot-data'` (two levels up) or another path outside the deploy target. Each deploy recreates only the build directory, the data directory survives.
- **Forgetting to reset state on navigation**: When the user clicks a category card and scrolls to the schedule section, sessionStorage should carry the selected filter. The schedule page should read it on mount.
- **`.toLowerCase()` on undefined crashes when data has missing fields**: When filtering material data from heterogeneous sources (different schedule types have different fields), calling `field.toLowerCase().includes(q)` on a field that may be `undefined` throws `TypeError`. Always guard: `field && field.toLowerCase().includes(q)`. This is especially common after importing Excel data where fields are sparse — many items will have `undefined` for fields like `category`, `element`, `description`, `colour`, etc. The crash happens silently during React's render phase and makes the entire component tree disappear.

## Related

- `surge-deploy` — for Surge.sh preview deployments (different auth model, static-only)
- `html-print-layout` — if the deployed app needs print formatting
- `references/tooltip-field-groups-pattern.md` — dynamic field groups for heterogeneous data cards
- `references/chrome-leveldb-localstorage-recovery.md` — recovering localStorage data from Chrome LevelDB when server data was wiped
