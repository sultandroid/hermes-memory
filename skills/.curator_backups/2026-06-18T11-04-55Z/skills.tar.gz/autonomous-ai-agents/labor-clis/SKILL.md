---
name: labor-clis
description: "Use local CLI labor agents (Claude Code, Kimi, Gemini) as sub-agents via terminal — not delegate_task ACP. Direct CLI invocation."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [Coding-Agent, Subagent, CLI, Claude, Kimi, Gemini]
    related_skills: [claude-code, sub-labor-orchestrator]
---

# Labor CLIs — Direct Terminal Invocation

## 🔴 MANDATORY: Delegate Heavy Work to Labors

**The user's explicit rule:** ALWAYS delegate substantive tasks to Claude, Kimi, or Codex. Never do heavy work yourself. Reasons:
1. **Protect your context quota** — heavy sessions (OCR, SVG gen, bulk edits, complex calculations, file searches) consume 50K+ tokens in your context window. Labors absorb this.
2. **The user has an army** — Claude Code, Kimi, and Codex are all installed and available. Using them is the expected workflow.
3. **Name the labor** — always state which labor performed each task in your response (e.g. "Done via Kimi", "Claude Code fixed").

**When to use each:**
- **Kimi** — fast print-mode tasks: OCR, file scanning, simple HTML gen, verification passes. Use `echo "task" | kimi --print --quiet`
- **Claude Code** — complex reasoning: SVG charts, deep analysis, multi-file operations, stakeholder reports. Use `claude -p "task" --max-turns N`
- **Codex** — quality controller: audit another labor's output, sandboxed verification. Use `codex exec "task" --sandbox workspace-write`

**When NOT to delegate:**
- Simple single tool calls (`ls`, `grep`, `read_file`)
- Clarifying with the user
- Quick verification checks (<3 tool calls)
- Any task where delegation overhead exceeds the work itself

## Standard Invocation

## Available Labors

| Labor | Path | Print Mode | Verified |
|-------|------|------------|----------|
| **Pi Agent (Commander)** | `~/.npm-global/bin/pi` | ✅ `pi -p "task"` | ✅ Commander — delegates to others |
| **Claude Code** | `~/.npm-global/bin/claude` | ✅ `claude -p "task" --max-turns N` | ✅ Works |
| **Codex** | `~/.npm-global/bin/codex` | ✅ `codex exec "task" --sandbox workspace-write` | ✅ Works (pty=true) |
| Gemini | `/opt/homebrew/bin/gemini` | ✅ `gemini -p "task" --yolo` | ⚠️ Hangs on directory list |
| OpenAI | `~/.hermes/hermes-agent/venv/bin/openai` | API calls only | ✅ Works |
| **OpenClaw** | `/opt/homebrew/bin/openclaw` | ✅ `openclaw agent --local --message "task"` | ✅ Works (agent mode) |

## Codex CLI (Quality Controller)

Codex is the **Quality Controller** gate. It audits all Claude Code output before delivery.

```bash
# One-shot task with sandbox (--full-auto is deprecated, use --sandbox)
codex exec "Create a QA report for file.html: check div balance, tags, CSS, logos" --sandbox workspace-write

# Git repo required — create scratch repo for standalone tasks
cd $(mktemp -d) && git init && echo "# scratch" > README.md && git add . && git commit -m "init"
codex exec "task description" --sandbox workspace-write

# Background mode (long tasks)
terminal(command="codex exec '...' --sandbox workspace-write", workdir="/path", background=true, pty=true)

# YOLO mode (fastest, no sandbox — use for trusted tasks only)
codex exec "task" --yolo
```

Key limitations:
- Must run inside a git repo (refuses otherwise)
- Requires pty=true in terminal calls (no ACP/stdio support)
- `--full-auto` deprecated → use `--sandbox workspace-write` instead
- Model: gpt-5.5 (OpenAI), reasoning: medium

## Claude Code (Preferred)

```bash
# Print mode — preferred for automation
claude -p "task description" --max-turns 10 --allowedTools "Read,Edit,Bash" --output-format json

# With workdir
claude -p "Fix the auth bug" --max-turns 5 --allowedTools "Read,Edit" --work-dir /path/to/project

# Session continuation
claude -p "Continue the refactor" --continue --max-turns 5

# With model selection
claude -p "task" --model sonnet --max-turns 3
```

## Kimi CLI (Print Mode via Stdin)

Kimi's `-p` mode requires stdin pipe — do NOT use positional argument:

```bash
# ✅ CORRECT — pipe input to stdin
echo "List all Python files in src/" | kimi --print --quiet

# ✅ With workdir
echo "Fix the auth bug" | kimi --print --quiet --work-dir /path/to/project

# ❌ WRONG — will fail
kimi -p "task"
kimi --print "task"
```

The `--print` flag auto-approves tool calls, `--quiet` suppresses the session resume message.

### Reading Images via Kimi (Hermes vision fallback)

Hermes has no built-in vision_analyze tool. Kimi's built-in `ReadMediaFile` tool activates when files are in its workspace scope. Use `--add-dir` to grant directory access:

```bash
echo "Read this image and describe its contents" | kimi --print --add-dir /path/to/image/dir 2>&1
```

Kimi identifies the image path, calls `ReadMediaFile`, and describes the visual content. Pipe the specific file path in the prompt so Kimi knows what to open. Use `2>&1` to capture the full response (print mode outputs verbose metadata; the answer is in the final `TextPart` block).

## Gemini CLI

```bash
# Print mode with auto-approve
gemini -p "task" --yolo --approval-mode yolo

# With model
gemini -p "task" --model gemini-2.5-flash

# Work directory
cd /path/to/project && gemini -p "task" --skip-trust
```

## Pi Agent (Commander Role)

Pi Agent (`@earendil-works/pi-coding-agent`) is a local coding agent — **always use it as commander/orchestrator** that delegates to other labor CLIs (Claude Code, Codex, Kimi), NOT as a simple worker.

See `references/onboarding-new-cli-agents.md` for the full onboarding pattern used to integrate Pi into the labor army.

```bash
# Print mode — preferred for automation
pi -p "task description"

# With provider/model
pi --provider google --model gemini-2.5-flash -p "task"

# Interactive mode
pi "task description"

# Print mode with session naming
pi -p "task" --name "Audit session"

# List options
pi --help
```

Default provider is `google`. Supports model switching at runtime (`Ctrl+P`). Version 0.78.0 installed at `~/.npm-global/bin/pi`.

Note: Pi Agent has a separate Python package `pi` (v0.1.2) at `~/.venvs/pi/bin/pi` which is a different tool and is broken on Python 3.14 — ignore it.

## OpenAI CLI (API Mode)

```bash
# Simple API call
openai api chat.completions.create -m gpt-4o -m "Hello"

# Not agentic — better for one-shot API tasks
```

## Orchestration Pattern

When you need to delegate work to a labor:

1. **Choose the right tool** for the task
2. **Set workdir** so the labor operates on the correct project
3. **Set --max-turns** to prevent runaway loops
4. **Set --allowedTools** to scope permissions
5. **Report back** to user when done, mentioning which labor was used

For simple CLI tasks:
```
You → Hermes (orchestrator) → Claude Code (-p print mode) → Report result back
You → Hermes (orchestrator) → Kimi (stdin pipe) → Report result back
```

**For tasks needing web research:** See the Research Phase section in the `sub-labor-orchestrator` skill. Quick reference:
- Fast lookup (1-2 questions) → Kimi (SearchWeb built-in, ~2s startup)
- Parallel multi-aspect → Hermes delegate_task with toolsets=["web"]
- Deep synthesis → Claude Code with --allowedTools "WebSearch,WebFetch"

## Error Handling

- **Timeout**: Labor exceeded time budget → report partial progress
- **Permission denied**: Check `--allowedTools` scope
- **Session not found**: Create tmux session first
- **API key missing**: Set env var before calling (ANTHROPIC_API_KEY for Claude)
- **OneDrive sync broken after rename**: Codex uses `mv` to rename files, which bypasses macOS File Provider and corrupts ALL sibling folders' sync state. **Never delegate OneDrive folder renames to Codex or any labor using `mv`.** Always use OneDrive web for folder renames in cloud-synced directories. See `macos-housekeeping` skill's Renaming section for details and repair pattern.

### Labor Fallback Pattern — When All Labors Fail

Both Claude Code and Kimi can fail in different ways:
- **Claude Code**: Auth error 401 (API key expired, socket closed). The `claude -p` call returns immediately with `api_error_status: 401`. The JSON response contains `"is_error":true,"api_error_status":401,"result":"Failed to authenticate..."`.
- **Kimi**: Timeout on long/complex tasks (>300s shell timeout). Kimi's `--print` mode runs but the shell times out when the combined ReadFile + response cycle exceeds 300s. This happens with files >30KB, 30+ slide decks, or multi-stage prompts.
- **Codex**: Requires pty=true AND a git repo. Cannot run complex PPTX/Excel operations that need openpyxl or other non-stdlib packages.
- **delegate_task**: The most reliable fallback for complex generation tasks. Uses Hermes subprocess transport (not Claude API). Handles large HTML generation, multi-file operations, and tasks requiring web research.

**Fallback chain for PPTX/HTML/Excel/file-generation tasks:**

```
Try Claude Code CLI → (401) → Try Kimi CLI → (timeout) → delegate_task → (600s timeout) → Direct Python script
```

Implementation pattern:
```
# Attempt 1: Claude Code CLI
result = terminal("claude -p 'task...' --allowedTools Read,Edit,Write,Bash --max-turns 40 --output-format json", timeout=300)
if 401 error in result:
    failed.append("Claude Code (401 auth)")
    # Attempt 2: Kimi
    result = terminal("cat << 'EOF' | kimi --print 2>&1\ntask...\nEOF", timeout=300)
    if timeout:
        failed.append("Kimi (timeout)")
        # Attempt 3: delegate_task (for HTML gen, analysis, document creation)
        delegate_task(goal="task...", context="...", toolsets=["terminal", "file"])
        # OR if delegate_task also fails:
        # Attempt 4: Direct Python (for known programmatic tasks)
        write_file("script.py", "python code...")
        terminal("python3 script.py", timeout=120)
```

**When to skip labors entirely:** If the task is a known class of programmatic operation (openpyxl formula fix, python-pptx restyle, regex bulk rename, Pillow image processing) that requires specific Python libraries, skip the labor CLI and write the Python script directly. Labors are for research, analysis, design decisions, and natural-language document generation — not for running `pip install openpyxl; python3 script.py`.

**Pitfall:** Do NOT retry the same labor with the same prompt after it fails — change approach or change labor. Claude 401 auth won't resolve on retry. Kimi timeout won't resolve with a longer timeout on the same task — the issue is prompt complexity, not wall time.

**Pitfall:** If ALL labors fail (Claude 401 + Kimi timeout + delegate_task fails), report the complete failure chain to the user rather than fabricating a result. Say "all 3 labors failed: X, Y, Z" and ask how they want to proceed.

Each labor stores memory and skills in its own format and location. A cronjob (`memory-skills-exchange`) syncs knowledge across all agents every 6 hours.

### Storage Locations

| Labor | Memory Location | Skills Location |
|-------|----------------|-----------------|
| **Hermes** | `~/.hermes/memories/MEMORY.md` + `USER.md` | `~/.hermes/skills/` |
| **Claude Code** | `~/.claude/CLAUDE.md` + `history.jsonl` | `~/.claude/skills/` |
| **Codex** | `~/.codex/memories/` (markdown files) | `~/.codex/skills/` |
| **Kimi** | `~/.kimi/memories/MEMORY.md` + `USER.md` | `~/.kimi/skills/` |
| **Pi Agent** | `~/.pi/agent/AGENTS.md` (consolidated) | `~/.pi/agent/skills/` |
| **OpenClaw** | `~/.openclaw/workspace/MEMORY.md` + `USER.md` | `~/.openclaw/workspace/skills/` |

### Exchange Mechanism (`memory-skills-exchange` cronjob)

Runs every 6h via Hermes cron (watchdog/no-agent mode, no tokens consumed). Script: `~/.hermes/scripts/memory_skills_exchange.sh`.

**Pipeline:**
1. **Collect skills** — rsync each agent's skills dir into `~/.hermes/shared_exchange/skills/<agent>/`
2. **Build SKILL_INDEX.md** — consolidated catalog of all 500+ skills across all agents
3. **Collect memory** — merge MEMORY.md / USER.md / AGENTS.md / CLAUDE.md from all agents
4. **Generate UNIFIED_MEMORY.md** — extract key facts (user profile, projects, rules, people, tools, contracts, locations)
5. **Distribute** — write unified memory to each agent's native format

**Output files under `~/.hermes/shared_exchange/`:**
- `SKILL_INDEX.md` — full skill catalog with descriptions per agent
- `UNIFIED_MEMORY.md` — cross-agent consolidated knowledge
- `skills/<agent>/` — raw skill files per labor

### How Each Agent Receives the Sync

| Labor | What Gets Written |
|-------|------------------|
| Claude Code | `## Unified Memory Exchange` section appended to `CLAUDE.md` |
| Codex | `unified_exchange_memory.md` in `memories/` |
| Kimi | `unified_exchange_memory.md` in `memories/` |
| Pi Agent | `memory_collection.md` in `agent/` |
| Hermes | Reads from `shared_exchange/` directly |
| OpenClaw | `unified_exchange_memory.md` + `HERMES_MEMORY.md` + `HERMES_USER.md` in `workspace/` |

### Querying Another Agent's Skills

To discover what skills another labor has:
```bash
# Full index
cat ~/.hermes/shared_exchange/SKILL_INDEX.md

# Skills from a specific agent
ls ~/.hermes/shared_exchange/skills/claude/
ls ~/.hermes/shared_exchange/skills/codex/

# Unified memory
head -100 ~/.hermes/shared_exchange/UNIFIED_MEMORY.md
```

### Pi Agent's AGENTS.md — Best Single Source

Pi Agent's `AGENTS.md` (~20KB) is the most comprehensive consolidated memory. It already contains merged knowledge from all other agents: user profile, project data, critical safety rules, key people, and orchestration workflows. When any agent needs a complete picture of this user's setup, Pi's AGENTS.md is the richest single source.

### OpenClaw — Knowledge Exchange Partner

OpenClaw is installed and running as a separate agent gateway with its own workspace. Skills and memory were migrated from Hermes to OpenClaw in this session. See `references/openclaw-setup.md` for install, setup flow, and known pitfalls (Telegram token capture bug, migration `baseUrl` cascading error).

## Cleanup

Always clean up tmux sessions when done:
```bash
tmux kill-session -t <session-name> 2>/dev/null
```