# Memory & Skills Exchange Cronjob

Multi-agent knowledge synchronization across all 5 labors: **Hermes, Pi, Claude Code, Codex, Kimi**.

## Purpose
Ensures every agent has access to the consolidated memory and skills of all others. Runs as a silent watchdog cronjob (no LLM tokens consumed).

## How It Works

```
cronjob (every 6h) → no_agent=true → memory_skills_exchange.sh
```

The shell script (`~/.hermes/scripts/memory_skills_exchange.sh`) executes these steps:

### Step 1: Collect Skills
Rsyncs all `SKILL.md` files from each agent into `~/.hermes/shared_exchange/skills/<agent>/`:
- hermes → `~/.hermes/skills/`
- claude → `~/.claude/skills/`
- codex → `~/.codex/skills/`
- kimi → `~/.kimi/skills/`
- pi → `~/.pi/agent/skills/`

### Step 2: Build Skill Index
Creates `SKILL_INDEX.md` with all 559+ skills listed by agent and category.

### Step 3: Collect Memory
Gathers all memory files from all agents into `MEMORY_COLLECTION.md` (~36KB):
- Hermes: MEMORY.md, USER.md
- Codex: memory_summary.md, raw_memories.md
- Kimi: MEMORY.md, USER.md, HERMES_SOUL.md
- Pi: AGENTS.md (the most comprehensive — already consolidated)
- Claude: CLAUDE.md (orchestration protocol)

### Step 4: Generate Unified Memory
Extracts key facts (user profile, critical rules, projects, people, tools, contracts, locations) into `UNIFIED_MEMORY.md` (~31KB).

### Step 5: Distribute Back
Pushes unified knowledge to each agent in its native format:
- Claude Code → appended as `## Unified Memory Exchange` section in `CLAUDE.md`
- Codex → `unified_exchange_memory.md` in `memories/`
- Kimi → `unified_exchange_memory.md` in `memories/`
- Pi → `memory_collection.md` in `agent/`
- Hermes → accessible at `~/.hermes/shared_exchange/`

## Cronjob Setup

```bash
cronjob create \
  --name "memory-skills-exchange" \
  --schedule "every 6h" \
  --no-agent true \
  --script "memory_skills_exchange.sh"
```

Schedule: Every 6 hours (next run: 01:25 / 07:25 / 13:25 / 19:25 KSA)
no_agent=true: Zero LLM tokens consumed — pure bash script execution

## File Locations

| Resource | Path |
|----------|------|
| Script | `~/.hermes/scripts/memory_skills_exchange.sh` |
| Shared output | `~/.hermes/shared_exchange/` |
| Skill index | `~/.hermes/shared_exchange/SKILL_INDEX.md` |
| Memory collection | `~/.hermes/shared_exchange/MEMORY_COLLECTION.md` |
| Unified memory | `~/.hermes/shared_exchange/UNIFIED_MEMORY.md` |

## When to Use

- **First session of the day** — run the exchange manually to get fresh unified memory: `bash ~/.hermes/scripts/memory_skills_exchange.sh`
- **After major project updates** — force sync so all agents learn about new contracts, people, rules
- **When switching agents** — the unified memory ensures Claude/Kimi/Codex/Pi all have the same context

## Pitfalls

- **OneDrive lock** — files under `OneDrive-SAMAYAINVESTMENT/` may be inaccessible during sync if OneDrive holds APFS file leases. Script handles this by focusing on non-OneDrive paths.
- **Claude Code's CLAUDE.md** — if the exchange section grows too large, it may bloat Claude's context. Keep it to 80 lines of key facts.
- **Codex memory format** — Codex uses a git repo for memories. The unified file is added as a plain markdown, not committed. That's intentional — it's ephemeral cache, not version-controlled history.
