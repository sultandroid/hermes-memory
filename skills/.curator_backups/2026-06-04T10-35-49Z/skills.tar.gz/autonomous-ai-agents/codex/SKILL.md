---
name: codex
description: "Quality Controller + Order Rewriter + coding agent. Audits ALL Claude Code output, rewrites user orders into structured specs, and can execute coding tasks and research/document-creation workflows."
version: 2.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Quality-Controller, Codex, OpenAI, Code-Review, QC-Gate, HTML-Audit]
    related_skills: [claude-code, hermes-agent, sub-labor-orchestrator]
---

# Codex CLI — Quality Controller & Order Rewriter

Codex CLI is OpenAI's autonomous coding agent CLI, now serving as the **Quality Controller** in the labor org chart. Two roles:

1. **Order Rewriter** — rewrites/structures ALL user orders before any labor executes them
2. **QC Gate** — audits ALL Claude Code output before delivery
3. **Coding** — can also execute coding tasks directly

## Labor Position
```
Hermes Agent (Leader)
  │
  ├── Codex CLI (QC Gate + Order Rewriter) ← YOU ARE HERE
  │
  ├── Claude Code (Main Labor — executes after Codex rewrites)
  │
  └── Kimi (Monkey Work)
```

## QC Role: HTML Audit Checklist

When auditing Claude Code's HTML output, Codex MUST check all 10 quality standards:

| # | Check | What to verify |
|---|-------|----------------|
| 1 | **DOCTYPE** | `<!DOCTYPE html>` present at start |
| 2 | **Tag balance** | All divs, tables, bodies, html properly opened and closed. Use Python regex: count `<div[>\s]` vs `</div>` — diff should be 0 |
| 3 | **No line-number contamination** | First line must NOT start with spaces+digits+pipe like `     1|<!DOCTYPE...` |
| 4 | **Closing tags** | `</html>`, `</body>` must exist at end of file |
| 5 | **CSS @page** | Must have `@page{size:A4 portrait;margin:0}` for print layout |
| 6 | **Sheet sizing** | `.sheet{width:210mm;min-height:297mm;overflow:hidden;page-break-after:always}` |
| 7 | **Logo paths** | Must use relative `../Docs/09_Registers/Key_Personnel_Register/CVs/_assets/logos/` prefix |
| 8 | **Fonts** | Calibri/Carlito loaded from Google Fonts (`fonts.googleapis.com`) |
| 9 | **Div balance per sheet** | Count open/close divs inside each `.sheet` — imbalance clips content |
| 10 | **Content overflow** | `overflow:hidden` clips content that exceeds 297mm per sheet — verify sheet fits |

## QC Role: Order Rewriting Pattern

When the user gives an order, Codex should:
1. Clarify ambiguous requirements
2. Break complex tasks into structured steps
3. Define acceptance criteria
4. Specify which labor should execute
5. Write the rewritten spec to a temp file for reference

## QC Role: Scope Audit Pattern

For contract scope verification (proven 2026-05-29):
1. Read the deliverable tree/report HTML
2. Extract all deliverables with their descriptions
3. Cross-reference against contract docs (ER clauses, SOW sections, BOQ pricing sections)
4. Classify each as: In Scope / Excluded / Deferred / Clarification Required
5. Produce: Executive Summary + Per-Category Matrix + Gap Register + Risk & Action Log

## Research & Document Creation Workflow

Codex can execute research-heavy tasks combining **web search** with structured document creation. Proven workflow (31 May 2026 — vendor evaluation meeting prep):

### Workflow Steps

1. **Create a scratch git repo** (Codex requires one):
   ```bash
   cd $(mktemp -d) && git init
   ```

2. **Set git config locally** (if global config is absent — Codex will fail to commit without this):
   ```bash
   git config user.email "user@example.com"
   git config user.name "Your Name"
   ```

3. **Add reference files** the agent should read:
   ```bash
   cp /path/to/input.pdf ./ && pdftotext input.pdf reference.txt
   # or copy any supporting documents
   ```

4. **Commit the reference data**:
   ```bash
   git add -A && git commit -m "init"
   ```

5. **Launch Codex with a structured spec** — write a detailed prompt with:
   - **Context paragraph** — project, audience, who the output is for
   - **Explicit sections** with bullet points for what each section must contain
   - **Research requirements** — what to search for online (prices, alternatives, specs)
   - **Output file name** — tell Codex where to save the result
   - **Quality constraints** — cite sources, don't make up prices, write for the audience
   
   ```bash
   codex exec "Long structured prompt..." --sandbox workspace-write
   ```

6. **Monitor in background** (for long tasks):
   ```bash
   terminal(command="codex exec '...' --sandbox workspace-write", workdir="/tmp/repo", background=true, pty=true, notify_on_complete=true)
   # Monitor with process(action="poll") or process(action="wait")
   ```

7. **Copy output to target location** after completion:
   ```bash
   cp /tmp/repo/Output_File.md ~/Desktop/Output_File.md
   ```

### Structured Prompt Template

For research/document-creation tasks, write the prompt as a detailed outline:

```
Create [document type] for [purpose]. Save as '[filename]'.

## Context
[Background, who needs it, what decision it supports]

## The document MUST cover:

### Section 1
- [sub-point A]
- [sub-point B]

### Section 2
- [sub-point A]
...

## Important
- Research actual data online — don't fabricate
- Cite sources with URLs
- Write for [audience description]
- Add a table of contents
```

This pattern works for: vendor evaluations, market research, project proposals, technical comparison documents, feasibility studies, and procurement analysis.

> **Template available:** `references/research-document-prompt-template.md` — reusable structured prompt skeleton with placeholders. Copy and adapt for each new task.

### Known Pitfall: Git Config

Codex (`git commit`) fails with `fatal: unable to auto-detect email address` if `user.email` and `user.name` are not set. Always set them locally before committing in the scratch repo. Do NOT assume global config exists.

### Known Pitfall: Initial Commit Required

Codex refuses to run (`"Not inside a trusted directory"`) even in a `git init`'d repo **if there are no commits**. Always run `git add -A && git commit -m "init"` after `git init` — not just `git init` alone. The `git init` + first commit must happen before `codex exec`, not inside the Codex prompt.

This is why the combined one-liner works:
```bash
cd $(mktemp -d) && git init && git config user.email "agent@hermes" && git config user.name "Hermes Agent" && git add -A && git commit -m "init" && codex exec "..." --sandbox workspace-write
```
While the partial form fails:
```bash
cd $(mktemp -d) && git init && codex exec "..."  # FAILS — no commit
```

### Known Pitfall: Tasks That Interleave Web Search with Writing

Codex may need multiple web search + write cycles. The `--sandbox workspace-write` mode auto-approves file writes but not web search results — Codex handles web search autonomously. Trust the process and monitor with `process(action="wait")`.

### Known Pitfall: Arabic/Unicode Folder Names on macOS

When Codex writes Python rename scripts that deal with Arabic folder names, the script may silently skip folders because macOS/OneDrive uses non-breaking space (U+00A0 = 0xC2 0xA0) characters that look like regular spaces. See `references/arabic-folder-unicode-pitfall.md` for detection, reproduction, and fix patterns.

## Invocation

### One-Shot Task (via terminal)
```bash
codex exec "task description" --sandbox workspace-write
```

**Note:** `--full-auto` is deprecated — use `--sandbox workspace-write` instead.

### QC Audit (HTML verification with Python validation scripts)
```bash
codex exec "Read file X.html and create a QA report listing all HTML quality issues: div balance, missing tags, doctype, font loading, @page CSS, sheet sizing, logo paths, line number contamination" --sandbox workspace-write
```

### Must run inside a git repo
```bash
cd $(mktemp -d) && git init && git config user.email "agent@hermes" && git config user.name "Hermes Agent" && git add -A && git commit -m "init" && codex exec "task" --sandbox workspace-write
```

### Background mode (long tasks)
```bash
terminal(command="codex exec '...' --sandbox workspace-write", workdir="/path", background=true, pty=true, notify_on_complete=true)
```

## Prerequisites

- Codex installed: `npm install -g @openai/codex`
- OpenAI auth configured: either `OPENAI_API_KEY` or Codex OAuth credentials
  from the Codex CLI login flow
- **Must run inside a git repository** — Codex refuses to run outside one
- Use `pty=true` in terminal calls — Codex is an interactive terminal app

For Hermes itself, `model.provider: openai-codex` uses Hermes-managed Codex
OAuth from `~/.hermes/auth.json` after `hermes auth add openai-codex`. For the
standalone Codex CLI, a valid CLI OAuth session may live under
`~/.codex/auth.json`; do not treat a missing `OPENAI_API_KEY` alone as proof
that Codex auth is missing.

## One-Shot Tasks

```
terminal(command="codex exec 'Add dark mode toggle to settings'", workdir="~/project", pty=true)
```

For scratch work (Codex needs a git repo with at least one commit):
```
terminal(command="cd $(mktemp -d) && git init && git config user.email 'agent@hermes' && git config user.name 'Hermes Agent' && touch .gitkeep && git add -A && git commit -m 'init' && codex exec 'Build a snake game in Python' --sandbox workspace-write", pty=true)
```

## Background Mode (Long Tasks)

```bash
# Start in background with PTY
terminal(command="codex exec 'Refactor the auth module' --sandbox workspace-write", workdir="~/project", background=true, pty=true)
# Returns session_id

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send input if Codex asks a question
process(action="submit", session_id="<id>", data="yes")

# Kill if needed
process(action="kill", session_id="<id>")
```

## Key Flags

| Flag | Effect |
|------|--------|
| `exec "prompt"` | One-shot execution, exits when done |
| `--sandbox workspace-write` | Auto-approves file changes in workspace (replaces deprecated `--full-auto`) |
| `--sandbox read` | Read-only sandbox (no file writes allowed) |
| `--yolo` | No sandbox, no approvals (fastest, most dangerous) |

## PR Reviews

Clone to a temp directory for safe review:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && gh pr checkout 42 && codex review --base origin/main", pty=true)
```

## Parallel Issue Fixing with Worktrees

```
# Create worktrees
terminal(command="git worktree add -b fix/issue-78 /tmp/issue-78 main", workdir="~/project")
terminal(command="git worktree add -b fix/issue-99 /tmp/issue-99 main", workdir="~/project")

# Launch Codex in each
terminal(command="codex --yolo exec 'Fix issue #78: <description>. Commit when done.'", workdir="/tmp/issue-78", background=true, pty=true)
terminal(command="codex --yolo exec 'Fix issue #99: <description>. Commit when done.'", workdir="/tmp/issue-99", background=true, pty=true)

# Monitor
process(action="list")

# After completion, push and create PRs
terminal(command="cd /tmp/issue-78 && git push -u origin fix/issue-78")
terminal(command="gh pr create --repo user/repo --head fix/issue-78 --title 'fix: ...' --body '...'")

# Cleanup
terminal(command="git worktree remove /tmp/issue-78", workdir="~/project")
```

## Batch PR Reviews

```
# Fetch all PR refs
terminal(command="git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'", workdir="~/project")

# Review multiple PRs in parallel
terminal(command="codex exec 'Review PR #86. git diff origin/main...origin/pr/86'", workdir="~/project", background=true, pty=true)
terminal(command="codex exec 'Review PR #87. git diff origin/main...origin/pr/87'", workdir="~/project", background=true, pty=true)

# Post results
terminal(command="gh pr comment 86 --body '<review>'", workdir="~/project")
```

## Rules

1. **Always use `pty=true`** — Codex is an interactive terminal app and hangs without a PTY
2. **Git repo required** — Codex won't run outside a git directory. Use `mktemp -d && git init` for scratch
3. **Use `exec` for one-shots** — `codex exec "prompt"` runs and exits cleanly
4. **`--full-auto` for building** — auto-approves changes within the sandbox
5. **Background for long tasks** — use `background=true` and monitor with `process` tool
6. **Don't interfere** — monitor with `poll`/`log`, be patient with long-running tasks
7. **Parallel is fine** — run multiple Codex processes at once for batch work
