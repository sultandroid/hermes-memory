---
name: document-analysis
description: "Use when extracting structured data from PDFs, scans, or exported Excel registers (BIM/museum project logs) — handles RTL Arabic, mirrored pages, multi-section registers, table continuity, and OneDrive-locked files."
version: 1.0.0
author: hermes
license: MIT
platforms: [macos, linux]
prerequisites:
  commands: [python3, pdfplumber, tesseract]
  env_vars: []
metadata:
  hermes:
    tags: [pdf, document-extraction, rtl, arabic, excel, register]
    examples: ["aseer-register", "pdfplumber"]
---

# Document Analysis

Extract structured data from PDFs and Excel exports for BIM/museum project registers.

## Pick the right route

| Source | Tool | Notes |
|--------|------|-------|
| PDF with real tables | `pdfplumber` | `extract_tables()` + `extract_text()` |
| Simple single-column PDF (quotes) | `pdftotext` (poppler) | beats pdfplumber on irregular layouts |
| Image-based PDF (no text layer) | PyMuPDF (`fitz`) → render to PNG → `tesseract` OCR | common for Illustrator/InDesign exports, scanned drawings |
| OneDrive-locked PDF | hydrate via `open` (Preview), then `pdftotext` | NOT the Excel/AppleScript route |
| `.xlsb` (OneDrive-locked) | Excel → Save As `.xlsx`, then `openpyxl` | only working path; xlsb is binary |
| `.xlsx` | `openpyxl` (`read_only`, `data_only`) | |

## Setup

```bash
# Core tools
pip3 install pdfplumber openpyxl PyMuPDF   # system python3
brew install poppler tesseract             # pdftotext + OCR engine
brew install tesseract-lang                # Arabic + additional OCR languages

# Or inside a venv
python3 -m pip install pdfplumber openpyxl PyMuPDF
```

## PDF Reading Pattern

### Basic multi-page extraction

```python
import pdfplumber

pdf_path = "/path/to/register.pdf"

with pdfplumber.open(pdf_path) as pdf:
    print(f"Total Pages: {len(pdf.pages)}")
    for i, page in enumerate(pdf.pages):
        text = page.extract_text() or ""
        tables = page.extract_tables()
        print(f"\n{'='*80}")
        print(f"PAGE {i+1} — {len(tables)} table(s)")
        print(text[:2000])
        for t, table in enumerate(tables):
            for row in table[:5]:
                print(row)
```

### Image-based PDFs (no text layer)

PDFs from Adobe Illustrator, InDesign, or scanned documents may have zero extractable text. Detect with PyMuPDF:

```python
import fitz
doc = fitz.open(path)
for i, page in enumerate(doc):
    text = page.get_text()
    if not text.strip():
        print(f"Page {i+1}: no text layer — need OCR")
```

**Workflow — render to image + tesseract OCR:**

```python
import fitz
import subprocess

doc = fitz.open(path)
for i, page in enumerate(doc):
    pix = page.get_pixmap(dpi=300)          # 300 DPI for decent OCR
    png_path = f"/tmp/page_{i}.png"
    pix.save(png_path)

    # OCR with tesseract (supports Arabic + English)
    result = subprocess.run(
        ["tesseract", png_path, "stdout", "-l", "eng+ara"],
        capture_output=True, text=True, timeout=60
    )
    print(f"--- Page {i+1} ---")
    print(result.stdout or "[no text detected]")
```

**Pitfalls:**
- Tesseract may fail to open files saved under `/tmp` due to filesystem isolation in sandboxed environments. Save the rendered PNG in the current working directory instead.
- Adobe Illustrator PDFs often contain only vector graphics, not embedded raster images. `get_pixmap(dpi=300)` renders the vector page to a raster image first — this is the correct approach.
- For large multi-page image PDFs (scanned drawings, specification books), process page-by-page to avoid memory bloat.
- Install tesseract with Arabic language pack: `brew install tesseract tesseract-lang` (macOS) or `apt install tesseract-ocr tesseract-ocr-ara` (Linux).

### Register with mirrored/duplicate pages

Many BIM register PDFs are Excel-to-PDF exports that repeat header rows on every printed page. The result: pages 2–7 may all show the same header, then page 8 starts fresh. When scanning:

1. Read all pages with `pdfplumber`
2. Deduplicate by comparing first N chars of extracted text
3. Keep only the first occurrence of each unique section header block

```python
# Deduplicate mirrored pages
seen_headers = set()
unique_pages = []
for page in pdf.pages:
    text = page.extract_text() or ""
    header = text[:200]  # first 200 chars as signature
    if header not in seen_headers:
        seen_headers.add(header)
        unique_pages.append(page)
```

### RTL Arabic text handling

Arabic text in PDFs comes out mirrored or with RTL glyphs. For register extraction:
- Use `pdfplumber` raw text — it preserves Arabic unicode
- Do NOT try to reverse or flip — just capture as-is
- When displaying to user, note "Arabic text appears as extracted from PDF"
- When searching, use Arabic keywords directly

```python
# Search for Arabic text
arabic_query = "عورشملل"
for page in pdf.pages:
    text = page.extract_text() or ""
    if arabic_query in text:
        print(f"Found on page {page.page_number}")
```

### Multi-section registers (8 log types in one PDF)

Aseer-style registers pack 8 log types into a single PDF, each section starting on a new page. Pattern:

```
Pages 2-7   → Material Submittal Log (with status codes A/B/C/D/E/F/U)
Pages 8-10  → SNA (Start New Activity)
Pages 11+   → Shop Drawings, Method Statements, RFI Log, SI Log, NCR Log, Correspondence
```

Scan for section headers first:

```python
SECTION_KEYWORDS = {
    "Material Submittal": ["MATERIAL SUBMITTAL LOG", "Material Submittal Log"],
    "SNA": ["Start New Activity", "SNA"],
    "RFI": ["REQUEST FOR INFORMATION", "RFI Log"],
    "Site Instruction": ["Site Instruction LOG", "SITE INSTRUCTION LOG"],
    "NCR": ["Non-Conformance Report LOG", "NON-CONFORMANCE REPORT LOG"],
    "Outgoing Correspondence": ["OUTGOING CORRESPONDENCE", "Outgoing Correspondence"],
    "Incoming Correspondence": ["INCOMING CORRESPONDENCE", "Incoming Correspondence"],
}

def classify_page(text):
    for section, keywords in SECTION_KEYWORDS.items():
        if any(kw.upper() in text.upper() for kw in keywords):
            return section
    return "Unknown"
```

## OneDrive-locked PDFs

BIM registers often live as `.xlsb` files or PDFs on OneDrive. They are **unreadable by any tool** from the terminal because the OneDrive sync engine holds a file lock.

**Symptom**: `Resource deadlock avoided` — every syscall (read, copy, stat) fails. Files show `compressed,dataless` flag in `ls -laO`.

**Workaround — hydrate via `open` then extract:**

OneDrive PDFs can be hydrated (downloaded from cloud) by opening them in their native app (Preview for PDFs). Once hydrated, they become regular files readable by extraction tools.

```bash
# Step 1: Trigger hydration by opening in Preview
open "/path/to/OneDrive-locked-file.pdf"
# Step 2: Wait a few seconds for download
sleep 8
# Step 3: Verify dataless flag is gone
ls -laO "/path/to/file.pdf"
# → compressed,dataless should no longer appear
# Step 4: Extract text with pdftotext (from poppler)
pdftotext "/path/to/file.pdf" - 2>/dev/null
```

The `open` command triggers macOS LaunchServices → Preview → OneDrive hydrates the file. The dataless flag disappears and the file becomes a regular file.

Do NOT use non-native apps (e.g. `open -a TextEdit file.pdf`) — they open blank for dataless files.

### Extracting pricing data from quotation PDFs

Quotation PDFs from vendors often have irregular table layouts. `pdftotext` (poppler) gives better results than pdfplumber for simple single-column quotations:

```python
import subprocess, re
# Extract all text
result = subprocess.run(["pdftotext", "/path/to/quote.pdf", "-"],
    capture_output=True, text=True, timeout=30)
text = result.stdout

# Extract pricing patterns
prices = re.findall(r'\$\s*[\d,]+\.?\d*', text)
# → ['$31,000.00', '$3,300.00', '$800.00', ...]

# Find total
total_match = re.search(r'Total.*?\$\s*([\d,]+\.?\d*)', text)
if total_match:
    total = total_match.group(1)  # '35,000.00'

# Find item descriptions
lines = text.split('\n')
for i, line in enumerate(lines):
    if re.search(r'\$\s*[\d,]+\.?\d*', line):
        desc = lines[i-1] if i > 0 else ''
        price = re.search(r'\$\s*([\d,]+\.?\d*)', line).group(1)
        print(f"{desc.strip()} → ${price}")
```

## OneDrive-locked Excel files (.xlsb)

BIM registers often live as `.xlsb` files on OneDrive. They are **unreadable by any tool** from the terminal because the OneDrive sync engine holds a file lock.

**Symptom**: `Resource deadlock avoided` — every syscall (read, copy, stat) fails.

**Solution — Excel conversion only**:
```python
import subprocess

# Open in Excel via AppleScript, save as .xlsx
script = '''
tell application "Microsoft Excel"
    activate
    open "/path/to/Live Register Log.xlsb"
    delay 5
    save active workbook in "/tmp/Live_Register_Log.xlsx" as Excel workbook
    delay 1
    close active workbook
    quit
end tell
'''
with open("/tmp/convert.scpt", "w") as f:
    f.write(script)
subprocess.run(["osascript", "/tmp/convert.scpt"], timeout=60)
```

Or via `open` CLI:
```bash
open -a "Microsoft Excel" "/path/to/file.xlsb"
# Then user must File → Save As .xlsx manually
```

After conversion, read with openpyxl:
```python
import openpyxl
wb = openpyxl.load_workbook("/tmp/file.xlsx", read_only=True, data_only=True)
ws = wb.active
headers = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
```

## Status Code Reference (Aseer-style)

| Code | Meaning |
|------|---------|
| A | Approved |
| B | Approved With Comments |
| C | Revise and Resubmit |
| D | Rejected |
| E | Not Required |
| F | For Information |
| U | Under Review |

## Pitfalls

1. **Double extension files**: PDFs exported from Excel often get `.pdf.pdf` extension. Handle gracefully.
2. **Empty pages**: Some pages in multi-section PDFs are blank separators. Skip if `text.strip() == ""` and `len(tables) == 0`.
3. **Table split across pages**: If a table ends mid-page, the continuation will have no header row. Solution: accumulate rows until a new header row is detected.
4. **Column offset in extracted tables**: `pdfplumber` tables sometimes return `None` for empty cells, shifting column alignment. Validate with `row[0]` being the expected first column.
5. **OneDrive lock affects ALL syscalls**: `shutil.copy2`, `open(...,'rb')`, `os.stat` — all fail with `Resource deadlock avoided`. There is no partial-read workaround for dataless placeholders.
6. **OneDrive-locked PDFs differ from .xlsb**: Excel .xlsb files need the Excel conversion workaround. PDFs can be hydrated via `open` (Preview) then read with `pdftotext` — do not try the AppleScript/Excel route for PDFs.
7. **System python3 vs venv**: `pdfplumber` may be installed under `/usr/local/bin/python3` but not under the hermes venv python. Use explicit path or check both.
8. **Tesseract /tmp access**: Tesseract can fail with `fopenReadStream` errors when the image is in `/tmp` on locked-down systems. Save rendered PNGs to the current working directory instead.
9. **No text layer detection is not an error**: PyMuPDF `page.get_text()` returning empty string is valid for image-based PDFs. Always check text length first before deciding the route.

## Verification

```bash
# Test pdfplumber works
python3 -c "import pdfplumber; print('ok')"

# Test a single page
python3 - <<'PYEOF'
import pdfplumber
with pdfplumber.open("/tmp/test.pdf") as pdf:
    print(f"Pages: {len(pdf.pages)}")
    t = pdf.pages[0].extract_text()
    print(t[:500] if t else "[empty]")
PYEOF
```