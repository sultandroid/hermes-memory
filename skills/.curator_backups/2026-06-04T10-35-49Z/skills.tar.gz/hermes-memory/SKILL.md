---
name: hermes-memory
description: Hermes memory migration — user profile, project context, and critical safety rules. Load when user references Samaya, Hermes, Mohamed Essa, Zamzam Museum, Aseer Museum, BIM Unit, or any migrated Hermes context.
version: 1.0.0
author: Kimi (migrated from Hermes)
---

# Hermes Memory Migration

## User Profile

**Mohamed Essa** — Director, Technical Office / BIM Unit at Samaya Investment (KSA). Manages museum construction projects (Zamzam #121, Aseer #3092, etc.).

**Key colleagues:**
- **Sultan** (Odoo/Outlook, sultan@samayainvest.com)
- **Ali Abdelrahman** (BIM Lead)
- **Adel Darwish** (Project Director)
- **Mohamed Samir** (Construction Manager)
- **Hesham Ezzat** (Document Controller)

**Telegram:** @SultanMacBook_Bot
**Notion:** MacHermes bot on Samaya inv. workspace

**Default Odoo:** Samaya (samayainv.odoo.com, user sultan@samayainvest.com). Dawam Odoo (dawam-tech.odoo.com) is only used when explicitly asked.

**Labor Rules (Claude Code, Kimi, Gemini):**
- Always NAME which labor does each task.
- Labors MUST cross-audit each other at PhD depth.
- ALL scripts/skills MUST be audited by a labor as "AI skills professional" before finalizing — this is mandatory QA.
- Always plan first, audit plan with labor, then execute.
- FIRM RULE: Always confirm task completion — report what was done, what changed, any issues. Never create new Excel files, only append rows. Never rm -rf folders. Never move unknown/non-project files.
- Bilingual work.

---

## Project Memories

### Zamzam Museum (ID 121/P0639) — Makkah KSA
- Samaya developer, Wael Al-Masri design, Dr. Sharif reviewer.
- 3 sub-project IDs: P0639-01/02/03.
- 828 emails tracked (Sep 2023–May 2026).
- MEP clash G-5, facade redesign (3 alternatives).
- OCULEAP 5D cinema, OTIS lifts, Obeikan Glass.

### Aseer Regional Museum (Contract 0010003521, May 2026)
- From SMP PL-0020 Rev 02 + CRP PL-0027 Rev C01.
- Employer: MoC. PMC: ACE Moharram-Bakhoum.
- CG: Eng. Mohammad Elbaz (Acting PM), Eng. Abdrabo Shahin (Sr Structure/Reviewer).
- Samaya: PD Eng. Adel Darwish (Acting), Tech Office Eng. Mohamed Sultan, BIM Eng. Waleed Salah, CRP author Eng. Mohamed Elshikh.
- Design Lead: NRS (AoR).
- 52-stakeholder register (T1 Ops 6 / T2 Specialists 20 / T3 Authorities 14 / Ext MoC 7 / Statutory 5).
- 7 lifecycle phases, 7 report series, 11 standing meetings.
- SLAs: Submittal 14d, RFI/TQ 7d, SI 10d.
- 5-tier escalation L1→L5 (max 27d); 8 auto-fire triggers.
- 6 Authorities: SCD/GDCD, SEC, MoMRAH, CITC/CST, MOI, Aseer Emirate.
- KPIs: CDE 100%, RFI ≤7d, satisfaction ≥4.0/5.0.
- NRS Joint-Authorship model.
- CG Submission Sequence Rule (27-Apr-26): submittals without approved materials/design/specialist refs → Code C.
- All 8 CG comments CLOSED on SMP Rev 02.

### Aseer Register Log (DC Copy, 60 pages, May 28 2026)
- 8 types: Material Submittals (0A/3B/2C/1D/0U), SNA (2B/1U), RFI (4 open/20 closed), SI (~4 open), NCR (1C/4U), Outgoing (30 letters), Incoming (1 from CG).
- Status codes: A/B/C/D/E/F/U.
- Doc prefix: MOC-MUS-ASE-.
- Key open: NCR-001 (63d delay), SI-011/013/014/015, open RFIs: GN-007, GN-009, SIC-1A0-TQ-0020/0022.
- EOT Claim 01 Rev.00 (Apr 2026).
- Source: Aseer-Museum/Docs/09_Registers/Submittal_Tracker_IFC_Log/ (OneDrive .xlsb locked — save as .xlsx in Excel to read).
- NRS submittals: Submittal 11 (SC_01/SC_02 shop dwgs, May 25), Lighting/AV/M&E G11 & G13 (May 28), Invoice INV-4825 (May 28).
- Register 284 rows, updated May 25-28 2026.

---

## Critical Safety Rules (Never Violate)

1. **ALWAYS confirm task completion to Mohamed Essa** — no "ok done". Report specifically what was done, what changed, and any issues.
2. **NEVER use `rm -rf`** on any path — OneDrive propagates deletions immediately.
3. **NEVER create new Excel files** for registers — only append rows to existing ones.
4. **NEVER move unknown/non-project files** from Downloads.
5. **When marking Odoo tasks as done**, use `state = '1_done'` — marks completed in-place without changing stage.

---

## OneDrive SAMAYAINVESTMENT File Lock

**Symptom:** `Resource deadlock avoided` on reads — APFS file lease held by OneDrive sync engine.
**Recovery:** Quit OneDrive completely, wait 30s, retry. Or kill secondary OneDrive instances. Or write to `/tmp/` first.
**Scope:** Affects ALL files in `OneDrive-SAMAYAINVESTMENT` account. Personal OneDrive is unaffected.

---

## Hermes Personality (Previous Agent)

Hermes was configured with a default empty persona (SOUL.md deleted/empty). Display personality was set to `kawaii` in config.
