---
name: bim-email-pipeline
description: "Check Outlook every 2 hours → classify emails by project → download attachments → copy to project subfolders → update Excel registers → archive as MD"
version: 2.5.0
author: Hermes Agent
platforms: [macos]
metadata:
  hermes:
    tags: [BIM, Email, Outlook, Pipeline, Samaya, Automation]
prerequisites:
  python: [openpyxl]
  commands: [osascript]
  app: [Microsoft Outlook]
---

# BIM Email Pipeline v2.5

Automated email processing pipeline for the Samaya BIM Unit.
Checks Microsoft Outlook every 2 hours, downloads new project emails,
classifies them, extracts attachments to correct project subfolders,
and updates Excel registers.

## Architecture

```
Outlook (macOS) ──AppleScript──▶ bim_email_pipeline.py
    (file-based)                     │
                           ┌────────┼────────┐
                           ▼        ▼        ▼
                    Classify    Download  Archive
                   (Project +  Attachments as .md
                    Category)     │
                           ┌──────┘
                           ▼
                    Copy to
                    Project
                    Subfolders
```

### Files

| File | Purpose |
|------|---------|
| `~/.hermes/scripts/bim_email_pipeline.py` | Main pipeline script |
| `~/.hermes/scripts/bim_fetch_emails.applescript` | Fetches recent emails from Outlook |
| `~/.hermes/scripts/bim_download_attachment.applescript` | Downloads individual attachments |
| `~/.hermes/scripts/.email_pipeline_state.json` | Tracks processed email IDs |
| `~/.hermes/scripts/.email_pipeline.lock` | Prevents concurrent runs |
| `~/.hermes/scripts/bim_email_pipeline.log` | Rotating log (10MB × 5) |

### References (under this skill directory)

| Reference File | Purpose |
|----------------|---------|
| `references/outlook-applescript-troubleshooting.md` | AppleScript error messages and fixes |
| `references/outlook-search-by-sender.md` | Fast sender-based email search |
| `references/outlook-topic-search.md` | Broad keyword topic search (AV, acoustics, etc.) — benchmarks, patterns, keyword strategy |
| `references/aseer-document-routing.md` | Document code → folder mapping for Aseer-Museum, Zamzam, Jabal Omar projects. Who sends what and where it goes. |
| `references/audit-lessons.md` | Lessons from audit sessions |
| `references/outlook-sqlite-scanning.md` | Direct SQLite queries — faster than AppleScript for discovery across ALL folders, not just Inbox. Use for: finding emails by sender/domain, identifying unread emails across folders, email counts and patterns. Then use AppleScript for targeted attachment downloads. |
| `references/outlook-folder-hierarchy.md` | Full folder tree for sultan@samayainvest.com — dual-inbox architecture (Exchange vs On My Computer), project subfolders, Deleted Items folder with trailing-space quirk, and Exchange account health check. |

### AppleScripts — Critical Notes

Using **file-based** AppleScripts (not inline) for reliability. Two scripts:

1. `bim_fetch_emails.applescript` — called with `osascript bim_fetch_emails.applescript "Inbox" 50`
   - Returns emails in `===EMAIL===` / `===END===` tagged format
   - Includes: ID, FROM, DATE, SUBJ, BODY, ATT (attachment names)
   - Handles errors gracefully per message

2. `bim_download_attachment.applescript` — called with `osascript bim_download_attachment.applescript "Inbox" "msgId" "attName" "/output/path"`
   - Uses `message id <id>` for O(1) lookup — this is the **Outlook internal message ID** (e.g. 34360), NOT the sequential index (1, 2, 3...)
   - Returns the output path on success, "NOT_FOUND" on failure
   - To get the internal message ID from an index: `osascript -e 'tell app "Microsoft Outlook" to get id of message INDEX of inbox'`
   - Proven with index 37 → message id 34360 (Hesham email, May 25)

#### ⚠️ Faster Alternative: SQLite Direct Query for Discovery

For bulk email discovery (finding all emails from a sender/domain, checking unread status across all folders, pattern matching), **direct SQLite query is ~1000x faster** than AppleScript scanning:

```bash
sqlite3 "$HOME/Library/Group Containers/UBF8T346G9.Office/Outlook/Outlook 15 Profiles/Main Profile/Data/Outlook.sqlite" "
SELECT datetime(m.Message_TimeReceived, 'unixepoch') as dt,
       m.Message_NormalizedSubject, m.Message_SenderAddressList,
       f.Folder_Name as folder,
       CASE WHEN m.Message_ReadFlag = 0 THEN 'UNREAD' ELSE 'read' END as status
FROM Mail m
JOIN Folders f ON m.Record_FolderID = f.Record_RecordID
WHERE m.Message_SenderAddressList LIKE '%@domain.com'
ORDER BY m.Message_TimeReceived DESC;
"
```

**AppleScript** is still needed for: downloading attachments, moving/deleting messages, sending replies. Use SQLite for discovery, AppleScript for action. See `references/outlook-sqlite-scanning.md` for full schema and query patterns.

| Problem | Fix |
|---------|-----|
| `date received of msg` → *"variable received is not defined"* | Use `time received of msg` instead |
| Looping through 18K+ messages times out | Inbox is reverse-chron (ID 1 = newest, today). Scan **forward from ID 1**, stop after N items or when date crosses cutoff. |
| `address of sender of msg` → *Can't make ... into type specifier* | Use `address of snd` where `snd` is `sender of msg` |
| `repeat with i from 1 to count of messages` — very slow | Use `repeat with i from totalCount to 1 by -1` for newest-first, cap at 300–500 iterations |
| AppleScript variable named `count` conflicts | Rename to `cnt` or `scanCount` |
| Script works in Script Editor but times out in `osascript` | Use background mode with `notify_on_complete=True`; expect 60–120s for 500 messages |
| `set d to (current date) - (31 * days)` → compile error with `osacompile` ("Expected ',' but found class name") | Replace `days` with seconds: `31 * 24 * 60 * 60`. The `days` keyword works at runtime in `osascript` but `osacompile` rejects it inside a `tell app` block. Using seconds is portable across both. |

#### Confirmed Working AppleScript Template (Newest-First Scan, Forward)

**Tested May 29, 2026 — verified direction:** message 1 = newest (today), message N = oldest.

```applescript
tell application "Microsoft Outlook"
    set inboxCount to count of messages of inbox
    set cutoffDate to (current date) - (7 * days)
    set recentList to {}
    set scanLimit to 500
    set scanned to 0

    -- SCAN FORWARD: msg 1 = newest (today), msg N = oldest
    repeat with i from 1 to inboxCount
        if scanned ≥ scanLimit then exit repeat
        try
            set msg to message i of inbox
            set msgDt to time received of msg

            if msgDt ≥ cutoffDate then
                set msgSubject to subject of msg
                set snd to sender of msg
                set sndAddr to address of snd
                set end of recentList to "ID:" & i & "|" & (short date string of msgDt) & "|" & sndAddr & "|" & msgSubject
                set scanned to scanned + 1
            else
                -- Past the cutoff (older messages), stop
                exit repeat
            end if
        on error
            set scanned to scanned + 1
        end try
    end repeat

    set output to "CNT:" & scanned & "|FOUND:" & (count of recentList) & "|"
    repeat with e in recentList
        set output to output & e & "|EMAIL|"
    end repeat
    return output
end tell
```

**Direction confirmed (May 29, 2026):** message 1 = May 29 (newest), message 18092 = Jul 20, 2022 (oldest). Scanning forward (1 → inboxCount) yields newest-first. Scanning backward (inboxCount → 1) yields oldest-first. Always test message 1 date to confirm before scanning. Use `osascript -e 'tell app "Microsoft Outlook" to get time received of message 1 of inbox'` to verify current ordering.
- `time received of msg` ✓ — works reliably
- `date received of msg` ✗ — returns *"variable received is not defined"*
- `address of sender of msg` ✗ — *"Can't make into type specifier"*. Use: `snd = sender of msg` then `address of snd`
- Variable `keepGoing` must be lowercase booleans: `true`/`false` (AppleScript is case-sensitive)
- AppleScript variable `count` conflicts — rename to `cnt` or `scanCount`
- Use `message i of inbox` — NOT `incoming message` class
- Use `exit repeat` with a scan counter (`≥ scanLimit`) to stop — simpler and more reliable than `keepGoing` boolean
- `keepGoing` boolean approach is unreliable since scan direction depends on inbox sort order

**Inbox confirmed (May 29, 2026):** 18,092 messages total. `message 1` = newest (today, May 29), `message N` = oldest (Jul 20, 2022). Always scan **forward from ID 1** for newest-first iteration. Verify direction at session start: `osascript -e 'tell app \"Microsoft Outlook\" to get time received of message 1 of inbox'`

## Script Usage

```bash
# Quick test (reads Outlook Inbox, lists what it would do)
python3 ~/.hermes/scripts/bim_email_pipeline.py --dry-run -v

# Live run
python3 ~/.hermes/scripts/bim_email_pipeline.py

# Silent for cron
python3 ~/.hermes/scripts/bim_email_pipeline.py 2>&1
```

## Project Classification

The pipeline uses a scoring engine with three factors:

1. **Keywords** (+10) — project name, Arabic/English terms
2. **Project Codes** (+50) — e.g. `ZVC-`, `ASER-`, `ALF-`, `EG-`
3. **People/Sender** (+30) — known contacts per project

### Supported Projects

| Project | Code | BIM Folder |
|---------|------|------------|
| Zamzam Museum | `ZVC-`, `ZM-` | `Bim Unit/Zamzam Museum/` |
| Aseer Regional Museum | `OC-ASER`, `ASER-`, `ARM` | `Bim Unit/Aseer-Museum/` |
| Al Faw Visitor Center | `ALF-` | `04_Al_Faw/` |
| El-Ghamama Museum | `EG-` | `El-Ghamama Museum/` |
| El-Haramain Museum | `EH-` | `El-Haramain Museum/` |

### Email Categories & File Routing

| Code | Meaning | Project Subfolder | Register |
|------|---------|-------------------|----------|
| SDR | Shop Drawing | `02_Submittals/01_Shop Drawings` | Submittal_Register |
| MAR | Material Approval | `02_Submittals/02_Material Samples` | Submittal_Register |
| RFI | Request for Info | `02_Submittals/03_Method Statements` | RFI_Register |
| IR | Inspection Request | `09_Site/01_Inspection Requests` | Inspection_Register |
| SI | Site Instruction | `09_Site/00_Site Instructions` | SI_Register |
| MIN | Meeting Minutes | `07_Meetings/00_Minutes of Meetings` | Meeting_Minutes_Register |
| REP | Progress Report | `08_Schedules/02_Progress Reports` | Submittal_Register |
| NCR | Non-Conformance | `09_Site/03_Snag Lists` | NCR_Register |
| DOC | Transmittal | `00_Admin/01_Correspondence` | Transmittal_Register |
| MSG | General | `01_Client Inbox` | Correspondence_Log |

Discipline fallback: filenames containing `STR`→Structural, `ARC`→Architectural,
`MEP`→MEP, `LND`→Landscape, `INT`→Interior.

## Cron Job

Registered as `BIM Email Pipeline` — **every 2 hours** (no_agent mode):

```json
{
  "job_id": "8bf950b52a36",
  "schedule": "every 2h",
  "script": "bim_email_pipeline.py",
  "no_agent": true
}
```

## Error Handling & Safety

| Issue | Protection |
|-------|-----------|
| **State corruption** | Atomic write (`.tmp` → `os.replace`) + auto-recovery from `.bak` |
| **Concurrent runs** | PID lock file prevents overlap |
| **AppleScript timeout** | Retry with exponential backoff (2s, 4s, 8s) |
| **Log bloat** | RotatingFileHandler (10MB, 5 backups) |
| **processed_ids bloat** | Pruned to max 5000 entries |
| **File duplicates** | Auto-rename with `_1`, `_2` suffixes |
| **Attachment cleanup** | Originals deleted after 7 days |
| **Cron monitoring** | Exit code 0=success, 2=partial failure |

## 🔴 CRITICAL: Dual-Inbox Architecture & Exchange Sync (Discovered May 31, 2026)

The Outlook setup for `sultan@samayainvest.com` has a **dual-inbox architecture** that the pipeline MUST understand.

### Two Inboxes Exist

| Inbox | Messages | Type | Purpose |
|-------|:--------:|------|---------|
| **On My Computer > Inbox** | 18,099 | Local (PST/OLM) | Old emails, stopped syncing July 2022 |
| **Exchange > Inbox** | **0** ❗ | Exchange (server) | Should receive new emails — currently broken |

### Project Subfolders (Under Exchange Account)

| Folder | Messages | Latest Email | Parent |
|--------|:--------:|:------------:|--------|
| `Inbox > Asher Regional Museum` | 649 | Oct 2025 | Exchange |
| `Inbox > Zamzam Project` | 46 | Oct 2025 | Exchange |
| `Inbox > Zamzam Projects` | 828 | Jul 2025 | Exchange |
| `Inbox > erp` (ERP POs) | 433 | Feb 12, 2026 | Exchange |
| `Deleted Items > Zamzam Project  ` (trailing space!) | 49 | **May 19, 2026** | Exchange |

### Root Cause: Exchange Account Disconnected

- Exchange account `sultan@samayainvest.com` shows **0 msgs in Inbox**.
- Online status cannot be read (`cannot read online status`).
- The account appears disconnected from the Exchange server.
- Project subfolders under Exchange have stale data (latest Oct 2025–Feb 2026).
- Most recent project emails (May 19, 2026) are in **Deleted Items** — deleted before the sync broke.

### Impact on Pipeline

The pipeline only checks Exchange Inbox (0 msgs). This is why every cron run reports "New: 0". The pipeline script is not broken — the **data source is**.

### What the Pipeline SHOULD Check

For a complete sweep, also check:
1. **"On My Computer" Inbox** — old-but-unprocessed emails
2. **Exchange Inbox subfolders** — Asher Regional Museum, Zamzam Project, Zamzam Projects, erp
3. **Deleted Items** — project folders under Deleted Items may have recent emails

```python
TARGET_FOLDERS = [
    "Asher Regional Museum",
    "Zamzam Project",      # under Inbox (no trailing space)
    "Zamzam Projects",
    "erp",
    "Zamzam Project ",     # under Deleted Items (trailing space!)
]
```

### ⚠️ Folder Name Quirks

Two "Zamzam Project" folders exist:
- **`Zamzam Project`** (no trailing space, 46 msgs) — under `Inbox`, latest Oct 2025
- **`Zamzam Project `** (WITH trailing space, 49 msgs) — under `Deleted Items`, latest May 19, 2026

AppleScript `name of mail folder` returns the name **including trailing spaces**. Filter carefully.

### Exchange Reconnection Needed

To fix: Open Outlook → Tools → Accounts → select `sultan@samayainvest.com` → re-authenticate. After reconnection, the Exchange Inbox should show today's emails.

### 🔴 Exchange-Disconnected: AppleScript `save attachment` Fails Entirely (Discovered Jun 4, 2026)

When the Exchange account is disconnected, **all** AppleScript attachment download methods fail:

- `bim_download_attachment.applescript` → `NOT_FOUND`
- Direct `save a in "/path"` → `"Microsoft Outlook got an error: An error has occurred." (-2700)`
- This happens even though message metadata (subject, sender, attachment names) is fully accessible
- Saves to `/tmp/`, Desktop, or anywhere else all fail identically — it's not a path/permissions issue

**Root cause:** Outlook can't fetch the binary attachment data from the disconnected Exchange server. The attachment metadata (name, size) is in the local SQLite cache, but the binary blob requires server access.

**✅ Working workaround — "open in Outlook" method (proven Jun 4):**
1. User opens the email in Outlook GUI (double-click)
2. Outlook auto-caches attachments to: `~/Library/Containers/com.microsoft.Outlook/Data/tmp/Outlook Temp/`
3. Agent then detects and copies those cached files to project folders
4. Files appear with their original names (e.g. `MOC-MUS-ASE-1KH-PL-0047.pdf`)
5. Inline images (image001.png etc.) also appear with mangled names — skip these

```bash
# Check what's been cached
ls ~/Library/Containers/com.microsoft.Outlook/Data/tmp/Outlook\ Temp/ | grep -v "^image"

# Copy to project
cp "$TEMP/MOC-MUS-ASE-1KH-PL-0047.pdf" "$ASEER/Docs/02_Plans_and_Procedures/"
```

**✅ Secondary fallback — check ~/Downloads:**
Some attachments get auto-downloaded by the browser/Preview when clicked in Outlook. Check `~/Downloads/` for recently added PDFs, zips, and docx files that match email subjects.

**Limitation:** This is a manual-trigger approach. Programmatic batch download of all attachments from recent emails is impossible until Exchange is reconnected.

### ⚠️ bim_download_attachment.applescript Fails for Subfolder Messages

The script uses `mail folder theFolder` (e.g. `mail folder "Inbox"`) which only finds **top-level folders**. Many project messages live in subfolders:
- `Inbox > Zamzam Projects`
- `Inbox > Asher Regional Museum`
- `Deleted Items > Zamzam Project ` (trailing space!)

For these, `message id X of Inbox` returns NOT_FOUND because the message isn't in Inbox.

**Workaround:** Use global `message id X` (unscoped) to access message metadata:
```applescript
set m to message id 34826  -- works without folder scope
set atts to every attachment of m
```
BUT `save` still fails when Exchange is disconnected. The unscoped access bypasses the folder-lookup failure for metadata, but the attachment binary fetch still hits the Exchange barrier.

## 🔴 CRITICAL Email Workflow (For Manual Agent Sessions)

When the user says "check outlook" or "check emails", this is the FULL pipeline. Do NOT stop at listing emails.

### Step 1: Dedup — Check Already-Archived Emails First
Before any download or processing, check the project's `Email_Archive/` folder for existing markdown files:
```bash
# Check for existing archive files
ls -la "$ASEER/Email_Archive/"*.md 2>/dev/null
```
If an email's subject+date already appears in an archive file, **skip it entirely**. Never reprocess a checked email.

### Step 2: Find & List Project Emails
Use AppleScript to scan Outlook Inbox:
```applescript
-- msg 1 = newest (verified May 29, 2026). Scan forward.
repeat with i from 1 to inboxCount
    if time received of msg ≥ cutoffDate then
        -- check sender name/address for target person
        -- collect: index, internal message id (id of msg), subject, date, attachment names
    end if
end repeat
```

### Step 3: Classify Attachments
Map each attachment by its document code prefix:
- `PL` → Plans → `Submittals/Design Submital/` (or project-specific Plans folder)
- `ZD` → General Docs → `Invoices/Docs/` (or `00_Admin/03_Project Documents/`)
- `SC` / HSE-related → `Submittals/Life and Safety/`
- `RP` / `REP` → Reports → `Reports & Meeting/`
- `SI` → Site Instructions → `Correspondence/`
- `IR` → Inspection Requests → `Correspondence/`
- `NCR` / `NC` → Non-Conformance → `Correspondence/`
- `PQ` → Prequalification → `Invoices/Docs/`
- `MSG` (no code) → General → `Correspondence/` or `01_Client Inbox/`

### Step 4: Download Attachments to /tmp
Use the existing `bim_download_attachment.applescript` or direct AppleScript:
1. Get the Outlook internal message ID: `id of message INDEX of inbox`
2. Download to `/tmp/aseer_attachments/` (outside OneDrive — bypasses file lock)
3. The source file must NOT be inside a OneDrive mount, or the sync engine blocks it

### Step 5: Copy to Project Subfolders
Copy from `/tmp/aseer_attachments/` to the correct target folder under the project. This works because the source is outside OneDrive.

### Step 6: Markdown Enrichment — Labors Read Attachments
Send key attachments to labors for reading and summarization:
- **Kimi** (fast, good for routine docs like weekly reports, plans)
- **Claude Code** (deep, good for complex technical docs, contracts)
Each labor reads the PDF and produces a markdown summary with: document code, key findings, decisions, action items, technical data.
- Save summaries to a temp location, then copy to `Scripts/notes/Knowledge Notes - <title>.md`

### Step 7: Archive as Markdown
Create a consolidated email archive file at:
```
Email_Archive/<person>_archive_<month><year>.md
```
Include: summary by category, full email list with attachment mapping, status per email, dedup notes.

### Step 8: Update Registers
Append new entries to the project's Submittal/Progress/HSE registers.

### Step 9: Update Knowledge Base
Copy labor-generated markdown summaries to `Scripts/notes/` under the project.

---

## Troubleshooting

### Script says "Another instance running"
```bash
rm ~/.hermes/scripts/.email_pipeline.lock
```

### AppleScript hangs or times out
- Inbox has 18,000+ messages. **Never iterate forward from ID N** without checking direction first — the newest message may be ID 1 or ID N depending on the Outlook folder sort order.
- Always scan in the correct direction. Default assumption (verified May 29): msg 1 = newest. Verify at session start.
- Use background mode (`notify_on_complete=True`) and expect 60–120s for 500 messages.
- If you see `date received of msg` failing with *"variable received is not defined"*, replace with `time received of msg`.

### Test AppleScript separately
```bash
# Get inbox count
osascript -e 'tell app "Microsoft Outlook" to get count of messages of inbox'

# Get oldest and newest messages (fast)
osascript -e 'tell app "Microsoft Outlook" to get time received of message 1 of inbox'
osascript -e 'tell app "Microsoft Outlook" to get time received of message (count of messages of inbox) of inbox'

# Fetch last N emails (newest first) — BACKGROUND, cap at 500
osascript /tmp/outlook_recent4.scpt 2>&1

# Download attachment
osascript ~/.hermes/scripts/bim_download_attachment.applescript "Inbox" "12345" "file.pdf" "/tmp/test.pdf"
```

### Reset state
```bash
rm ~/.hermes/scripts/.email_pipeline_state.json*
```

### Post-Pipeline Checklist (Manual Session)

When reviewing emails manually (not via cron), after processing new emails:

1. **Downloads folder** — check `~/Downloads` for recently auto-downloaded attachments (e.g. `Submittal 11 05-25-2026.zip`, `Invoice *.pdf`). These appear before the pipeline runs.
2. **Move files to correct subfolder** — see Routing table below. **Critical**: NRS (Nissen Richards Studio) showcase submittals go to `Subcontractors/01_Showcase_Contractor/`, NOT `Submittals/Showcases/From NSR/`.
3. **Update register** — append new entries to `Register_ASEER_Professional.csv` (Aseer) or the relevant project register
4. **Update PROJECT_MEMORY.md** — if OneDrive is syncing, the file may be locked ("Resource deadlock avoided"). Retry after a delay.
5. **Update Notion** — if configured, post to the Samaya inv. workspace

### OneDrive Root-Level File Copy Lock (Critical Pitfall)

When OneDrive auto-downloads Outlook attachments to the root `OneDrive-SAMAYAINVESTMENT/` folder, the `fileprovi` sync engine holds an exclusive file lock on those files. Any attempt to read, copy, or move them **within the same OneDrive mount** fails with:
```
Resource deadlock avoided
```

This affects:
- `cp`, `mv`, `shutil.copy2` — all fail when both source and destination are under OneDrive
- Even `cat` and `dd` fail on the source file — the lock prevents ALL reads

**Workaround (proven May 29, 2026):**
1. Download from Outlook directly to `/tmp/` (outside OneDrive) using the AppleScript `bim_download_attachment.applescript`
2. Then copy from `/tmp/` to the OneDrive destination — the second hop succeeds because the source is outside the mount

```bash
# Step 1: Download to /tmp (bypasses the lock)
osascript ~/.hermes/scripts/bim_download_attachment.applescript "Inbox" "MSG_ID" "filename.pdf" "/tmp/aseer_attachments/filename.pdf"

# Step 2: Copy from /tmp to OneDrive destination (succeeds because source is outside OneDrive)
cp /tmp/aseer_attachments/filename.pdf "/Users/.../OneDrive-SAMAYAINVESTMENT/.../target/filename.pdf"
```

**Same issue affects OneDrive-Personal(2) and any other OneDrive mount** — not just SAMAYAINVESTMENT.

The Zamzam Museum email register CSV at:
```
.../Zamzam Museum/Docs/Email Archive/مشروع تأهيل مسار الزوار زمزم/Project_Log_مشروع تأهيل مسار الزوار زمزم.csv
```
**cannot be read directly** when OneDrive sync is active. Any attempt returns:
```
Error: cannot read `Project_Log_مشروع تأهيل مسار الزوار زمزم.csv' (Resource deadlock avoided)
```
This is a **known OneDrive file-lock issue** — the sync engine holds an exclusive lock while the CSV is open in Excel or syncing.

**Workaround for the daily todo cron job (May 2026):**
- Read the Aseer register directly from CSV (it is stable and readable)
- For Zamzam: rely solely on `~/.hermes/scripts/.watchdog_state.json` (file-system watcher) for recent files
  - Zamzam files in the last 3 days appear in watchdog state under paths containing `Zamzam`
  - Filter entries where `mtime` is within 3 days of today
  - Extract file names as proxy for recent Zamzam activity
- **Do not attempt to read the Zamzam CSV in a cron/scheduled context** — it will always deadlock
- For manual sessions: ask the user to close the file in Excel, or copy it locally first

**Discovery command (Python):**
```python
import json
from datetime import datetime, timedelta
cutoff = datetime.now() - timedelta(days=3)
with open('/Users/mohamedessa/.hermes/scripts/.watchdog_state.json') as f:
    watchdog = json.load(f)
zamzam_recent = [(p, info['mtime']) for p, info in watchdog.items()
                 if 'Zamzam' in p and info.get('mtime', 0) >= cutoff.timestamp()]
```

### Critical Routing Note — NRS Showcase Submittals

**Correct path:**
```
Subcontractors/01_Showcase_Contractor/Submittal_11_05-25-2026/
Subcontractors/01_Showcase_Contractor/Lighting_AV_ME_G11_G13_05-28-2026.pdf
```

**Wrong path (do not use):**
```
Submittals/Showcases/From NSR/   ← This is incorrect for active project files
```

Other Showcase Contractor files (from GBH/Glasbau Hahn) may also belong here depending on project structure.

## Future (v3.0)

- [x] Multi-folder monitoring (Inbox, Asher Regional Museum, Zamzam Project, erp, Deleted Items) — structure mapped, see `references/outlook-folder-hierarchy.md`
- [ ] AppleScript migration to multiple-folder fetch
- [ ] Exchange reconnection detection — alert user when Inbox shows 0 msgs
- [ ] Conversation thread grouping
- [ ] Direct Excel register updates
- [ ] Email → Odoo task creation
- [ ] Microsoft Graph API (replace AppleScript)
