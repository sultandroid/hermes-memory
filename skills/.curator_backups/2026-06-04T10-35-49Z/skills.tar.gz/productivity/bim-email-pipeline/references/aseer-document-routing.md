# Aseer-Museum Document Code → Folder Routing

Document code prefixes map to Aseer-Museum's numbered `Docs/` subfolder structure:

| Code | Meaning | Target Folder |
|------|---------|---------------|
| `PL` | Plan / Procedure | `Docs/02_Plans_and_Procedures/` |
| `ZD` | General Document | `Docs/11_Correspondence/` |
| `TQ` | Technical Query | `Docs/04_RFIs/` |
| `RP` | Report | `Docs/07_Reports/` |
| `IR` | Inspection Request | `Docs/10_Test_and_Inspection/` |
| `SI` | Site Instruction | `Docs/05_SIs/` |
| `NC` / `NCR` | Non-Conformance | `Docs/12_Compliance_and_Audit/` |
| `DOC` | Transmittal | `Docs/11_Correspondence/` |
| `MIN` | Meeting Minutes | `Docs/08_Meeting_Minutes/` |
| `SDR` | Shop Drawing | `Docs/03_Submittals/` |
| `MAR` | Material Approval | `Docs/03_Submittals/` |

## Common Email Sender → Project Mapping

| Sender Domain | Project Assignment |
|---------------|-------------------|
| `@samayainvest.com` | Internal — classify by subject code |
| `@cg.com.sa` | CG Consultant → **Aseer** (all MOC-MUS-ASE docs) |
| `@nissenrichardsstudio.com` | NRS (Showcase Designer) → **Aseer** |
| `@glasbau-hahn.de` | GBH (Showcase Fabricator) → **Aseer** |
| `@adeng.com.sa` | Supervision/Adeng → **Aseer** |
| `@egec.com.sa` | EGEC → **Zamzam** |
| `@3d-me.com` | 3DME (Artec Spider) → **Aseer/Replica** |
| `@sitml.com` | SITML (Lidar scanning) → **Aseer** or **General** |

## Non-Aseer Attachments

| Sender | Subject Pattern | Project | Target |
|--------|----------------|---------|--------|
| `Kareem.Hussain` | jabal omar | Jabal Omar | `Jabal Omar - Samaya Scope/Docs/` |
| `M.almakarem` | زمزم / Zamzam | Zamzam MVC | `Zamzam Museum/Submittal's/` |
| `erp@samayainvest.com` | P0xxxx | Various | Route by project code in title |
| `sultan@samayainvest.com` | تسعير / Quotation | General | `Samaya/Estimations/` |
| `maged@samayainvest.com` | تسعير / Quotation | General | `Samaya/Estimations/` |
| Supplier quotes | Quotation | General | `Samaya/Estimations/` |

## Aseer-Museum HR / CV Routing

CV attachments from recruitment emails → `Aseer-Museum/HR/CVs/`

## Zamzam Museum Submittals

Zamzam documents from M. Almakarem use code pattern `ZAM-NWC-CTR-{TYPE}-{DISC}-{NUM}_Rev.XX.pdf`:
- `WIR` → Work Inspection Request
- `IR` → Inspection Request  
- `DOC` → Document Transmittal
- `CLR` → Clearance

All go to `Zamzam Museum/Submittal's/` (note the possessive apostrophe — this is the existing folder name).
