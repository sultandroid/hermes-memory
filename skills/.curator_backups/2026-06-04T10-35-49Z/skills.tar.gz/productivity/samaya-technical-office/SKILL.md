---
name: samaya-technical-office
description: Complete workflows, conventions, and project structure for Samaya Investment's Technical Office / BIM Unit. Covers Zamzam Museum (ID 121/P0639), Aseer Regional Museum (3092), document control, email pipeline, Telegram gateway, CV pack generation, NRS tender package audit/consolidation, drawing status tree update. Load when user references Samaya, Technical Office, BIM Unit, or any of these projects.
version: 1.20.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [samaya, bim, construction, project-management, construction-document-control, saudi-arabia]
    related_skills: [opencode, hermes-agent, project-email-archive, bim-email-pipeline, bim-daily-todo, evm-analysis-chart]
---

# Samaya Technical Office — BIM Unit Workflows

## Company Context

**Samaya Investment** (شركة سمايا الاستثمارية) — KSA real estate/investment/construction company. Based in Makkah. Managed by Mohamed Essa (Director, Technical Office / BIM Unit). Projects synced via OneDrive under:
`/Users/mohamedessa/Library/CloudStorage/OneDrive-SAMAYAINVESTMENT/Samaya/Technical Office/`

**Key colleagues:**
- **Sultan** (sultan@samayainvest.com) — Outlook email extraction pipeline
- **Ali Abdelrahman** (ali.abdelrahman@samayainvest.com) — Senior Architect, BIM Lead
- **Adel Darwish** — Project Director
- **Mohamed Samir** — Construction Manager
- **Hesham Abd Elhameed Ezzat** — Document Controller
- **Dr. Sharif El-Sherbiny** — Submittal reviewer/approver

### 5. Al Faw Visitor Center (Tqanny Projects — Personal OneDrive)
- **Location:** Al Faw UNESCO World Heritage Site (19.782457°N, 45.147648°E)
- **Client:** Heritage Commission — Ministry of Culture
- **Design Consultant:** AMA Architecture
- **Reviewer:** RS
- **Contractor:** Tqanny Projects
- **Phase:** Concept Design Rev 02 → DD transition
- **Built area:** ~290 m²
- **OneDrive path:** `OneDrive-Personal(2)/Work/PWork/01_PROJECTS/Tqanny_Projects/04_Al_Faw/`
- **PEP:** `08_Schedules/00_Master Program/PEP_PROJECT_EXECUTION_PLAN.rev0*.html`
- **Design concept:** Solid adobe-style earth walls (RC masonry + earth brick cladding) + light horizontal tent roof (HDG steel + ALUCOBOND A2) + engineered sand dune wind protection

**Key risks:** Adobe SBC compliance, UNESCO buffer zone clearance, remote desert logistics, sand abrasion on metal panels, thermal performance in 50°C

**Bilingual docs required:** Arabic lead, English following, Tajawal font, RTL layout

---

### 1. Zamzam Museum & Visitor Center (ID 121 / P0639)
- **Location:** Makkah, KSA
- **Client/Owner:** National Water Company (NWC)
- **Design Consultant:** Wael Al-Masri Planners & Architects
- **Document prefix:** `ZAM-NWC-{CTR|MUM}-`
- **Phase:** Active construction/execution (May 2026)

**Three sub-projects:**
| Sub-project | Scope | Email Volume |
|---|---|---|
| Visitor Reception Center | Building construction, MEP, structure | ~168 msgs |
| Museum Pathway Rehabilitation | Fit-out, exhibition, MEP, structure (largest) | ~552 msgs |
| Tafweej (Pilgrim-grouping) Center | Design studies | ~13 msgs |

**Key issues (as of May 2026):**
- MEP clash coordination in Area G-5 (HVAC vs ceiling heights)
- Facade redesign — 3 alternatives submitted, awaiting final stamp
- Material approvals active: fire pumps, HVAC, electrical panels, GRC facades, waterproofing

**Specialist suppliers:** OCULEAP (5D cinema), OTIS (lifts), Obeikan Glass, JAWDAH (access panels), York/Johnson (HVAC), AVAYO (raised floor), DCP (waterstop)

### 2. Aseer Regional Museum (Project 3092)
- **Location:** Aseer region, KSA
- **Client/Owner:** Ministry of Culture (MoC)
- **Submittal reviewer:** Nissen Richards Studio (NRS)
- **Document code prefix:** `MOC-MUS-ASE`
- **Phase:** ~90% technical design complete, construction preparation

**Zone codes** (used in document numbers `MOC-MUS-ASE-<zone>-<disc>-<num>`):
| Zone | Meaning |
|------|---------|
| `1A0` | Architectural package |
| `1E0` | Electrical / AV / MEP |
| `1K0` | Master / coordination / plans (SMP, CRP, DMP, BEP all use 1K0) |
| `1V0` | Site / survey / inspection |
| `0PS` | Scheduling / time programme |
| `1KH` | HSE (health, safety, environment) |

**Key project documents (authoritative doc numbers from live files):**
| Doc | Number | Rev | Date |
|----|--------|-----|------|
| Stakeholder Management Plan | MOC-ASEER-SIC-1K0-PL-0020 | Rev 02 | 11-May-26 |
| Communication & Reporting Plan | MOC-ASEER-SIC-1K0-PL-0027 | Rev C01 | 13-May-26 |
- **Nissen Richards Studio (NRS)** — exhibition design, submittal reviewer
  - **Aseer DMP Governance Reference:**
  The full DMP Rev C04 governance study is saved as a reference: `references/aseer-dmp-study.md`. Key content: 5 stage gates (G1→G5, D0→D300), Joint-Authorship model (NRS = R(DL/AoR) on ALL 14 disciplines), 7-step submittal lifecycle, CR Cat 1/2 routing, VE red lines, mock-up types G2→G5, BIM LOD progression 300→350→400→500, 8 KPIs, and currently open issues (TQ-0016 4-month MoC overdue, Type 1 door blocked, brass/Corian CR Cat 2 needed).

  - **Aseer Actual NRS Submittal Sequence (May 2026):**
    | # | Document | Date | Status |
    |---|----------|------|--------|
    | 10 | NRS Comments package | May 20, 2026 | Submitted |
    | 11 | Wall Case SC_01 + Freestanding Case SC_02 (shop drawings, NRS stamped) | May 25, 2026 | Submitted |
    | 12 | Lighting/AV/M&E G11 + G13 | May 28, 2026 | Just issued |
    | 13 | Invoice INV-4825 (NRS-SAM-2026-004) | May 28, 2026 | Issued |
    ⚠️ **No renders, DD, IFC, or AFC sequence is visible in local registers.** The DMP prescribes Track 2 renders D28→D65, G2 (D35) 3D-R V1, G3 (D65) 3D-R V2 all 21 spaces, G4 (D82) FULL 1:1 prototype (IFC NOC gate), G5 (D88) CONS first-install (AFC NOC gate). We are May 28, 2026 — D82 was supposed to be the IFC NOC gate. Confirm Aconex CDE for the authoritative submittals register; the local `Submission_Plan_Aseer_Museum copy.xlsx` was unreadable (OneDrive lock).

  - **RFI workflow — ALWAYS read the DMP first (CRITICAL):**
  Before working on any RFI, design change, or approval matter, **read the DMP first**. The DMP defines:
- The RFI approval chain (which changes need MoC submission vs. NRS approval only)
- **CR Cat 1 vs Cat 2 routing** — material substitutions (brass, Corian, etc.) = CR Cat 2 (MoC Change Order required), NOT just an RFI
- Correct query type: RFI → NRS · TQ → Samaya EoR · Authority Query → MoC via CG/Aconex
- 7-day SLA for CG review; escalation at Day 8 per Conflict Resolution Matrix Sec 5.3.3
- Authority submission thresholds (what requires Ministry of Culture sign-off vs. Samaya/NRS internal approval)
- The DMP lives at: `Docs/02_Plans_and_Procedures/02.1_DMP/`
  - Latest signed version: `2026-05-18_DMP_Rev_C04_REV02_NRS_signed.pdf`
  - Working copy: `Aseer_Museum_DMP_Rev03_C03_NRS_Lead.docx`
  - Chapter structure in `02_DMP_Chapters/` (markdown files — but see ⚠️ below)
- ⚠️ DMP PDF files are in OneDrive cloud storage — "Resource deadlock avoided" on read means the file is cloud-only and not locally downloaded. Use a locally cached copy (e.g., from email attachments) or the Design Management Plan.pdf from the Telegram cache.

- Full RFI-008 status, decision matrix, DMP routing classification, and file locations: `references/aseer-rfi-008.md` — Updated May 28 2026. Contains: CR Cat 1/2 classification of each item, correct DMP query type routing, Types 6A/6B pull-slide already NRS-approved finding, Type 1 blocked finding, MoC 4-month overdue escalation note.
- **Nissen Richards Studio (NRS)** — exhibition design, submittal reviewer
- **Mada Gypsum** — ceilings / partitions
- **Bluhouse** — MEP design
- **JOCAVI** — acoustic panels
- **Panasonic** — projectors
- **Artec Space Spider II** — replica fabrication (3D scanner for G12 touch interactives)
  - Tender folder: `Samaya/Tenders/2026/Aseer Museum - Artec Space Spider Replica/01 RFQ/`
  - Distributor: 3D Middle East (3DME) — Riyadh office, info@3d-me.com
  - See `references/aseer-scanner-procurement.md` for full procurement details

**Docs structure** (01–12 classification):
- `01_Contracts_and_ER/` — Contract 10003521, employer requirements
- `02_Plans_and_Procedures/` — 20 items: BIM MIDP/TIDP, procurement plan, subcontractor deliverables
- `03_Submittals/` — Architectural, design, structural, MEP packages
- `04_RFIs/` — RFI register + NRS A2742 submissions
- `05_SIs/` — SI-CG-ASEER-007 (active, 3 revisions)
- `06_Authority_Submissions/` — Civil Defense, MoC, MoMRAH, Municipality
- `07_Reports/` — Weekly progress, method statements
- `08_Meeting_Minutes/` — Weekly coordination, monthly strategic, workshops
- `09_Registers/` — 19 registers: Drawing, Submittal_IFC_Log, BCF, Design_Risk, Material_Sample, AV_Interface, Procurement_Schedule, Subcontractor_Prequalification, NCR, Transmittal, VE, etc.
- `10_Test_and_Inspection/` — Material tests, IRs
- `11_Correspondence/` — To/from CG and PMC
- `12_Compliance_and_Audit/` — Audit logs, DC manifest

**Active email traffic (May 2026):**
- GBH RFIs #4–9 (Apr–May 2026)
- Artec Space Spider RFQ for replica fabrication
- MEP design services by Bluhouse
- IFC drawing packages (Stages 4–5): IFC-0001 to IFC-0008
- Weekly coordination every Monday

**Aseer Downloads → project folder workflow (May 2026 — corrected):**
When recent files appear in `~/Downloads`:
1. Identify project from filename keywords (Aseer, NRS, Submittal, Invoice, MOC-MUS)
2. Extract zip archives before copying to OneDrive
3. **Route: NRS submittals → `Subcontractors/01_Showcase_Contractor/Submittal_NN_date/`** ← correct
4. **Route: NRS invoices → `Invoices/YYYY-MM-DD_INV-{number}_{vendor}.pdf`** ← correct
5. **Route: Lighting/AV/M&E docs → `Subcontractors/01_Showcase_Contractor/`** ← correct
6. Confirm copy, then delete originals from Downloads

> ⚠️ Do NOT use `Submittals/Showcases/From NSR/` for active project files — that is incorrect. `Subcontractors/01_Showcase_Contractor/` is the correct home for all active NRS showcase documents.

**Example (corrected May 28, 2026):**
- `Submittal 11 05-25-2026.zip` → extracted → `…/Subcontractors/01_Showcase_Contractor/Submittal_11_05-25-2026/`
- `Aseer Museum - Invoice NRS-SAM-2026-004 (INV-4825).pdf` → `…/Invoices/2026-05-28_INV-4825_NRS-SAM-2026-004.pdf`
- `Lighting, AV and Sundry M&E…G11…G13…pdf` → `…/Subcontractors/01_Showcase_Contractor/Lighting_AV_ME_G11_G13_05-28-2026.pdf`

**Email archive:** Restructured May 2026 to match the `project-email-archive` template.
`Docs/Email Archive/مشروع متحف عسير الإقليمي/` — 308 files in 12 category folders (DOC, IR, MAR, RFP, RFI, SI, SCH, SDR, REP, GEN + MIR/WIR empty) + Project_Log CSV + Dashboard HTML.

## OneDrive SAMAYAINVESTMENT Account — Systemic File Lock (Resource Deadlock Avoided)

**Symptom:** `Resource deadlock avoided` on `dd`, `cat`, Python `open()`, `rsync`, `copyfile()` — but `kMDItemIsUploaded = 1` and `kMDItemIsDownloaded = 1`. File is locally complete and uploaded. This is NOT a sync/download issue.

**Scope:** Affects **ALL files** in `OneDrive-SAMAYAINVESTMENT` account (all Samaya projects: Aseer, Zamzam, Hera' Ghar, Alnoor, etc.). Personal OneDrive (`OneDrive-Personal(2)`) is unaffected.

**Root cause:** APFS file lease held by OneDrive sync engine. Extended attribute `com.apple.FinderInfo: 0xFF…` confirms an active file lease. Multiple OneDrive processes (`/Applications/OneDrive.app`, `OneDrive File Provider.appex`, `OneDrive Sync Service`) can hold conflicting leases.

### Cloud Stubs (Different from Lock) — OneDrive "Files On-Demand"

A separate issue from file locking: some files may be **cloud-only placeholders** that were never downloaded locally. These are ~6.5 KB stub files with only `com.apple.FinderInfo` xattr (no `com.apple.provenance`). They are NOT real files — `openpyxl.load_workbook()` fails with "File is not a zip file" and `dd`/`cp` reads fail with "Resource deadlock avoided".

**Detection:** Check for valid ZIP content before treating a file as a real xlsx:
```python
import zipfile
def is_valid_register(path):
    if not os.path.exists(path):
        return False
    try:
        with zipfile.ZipFile(path) as z:
            return len(z.filelist) > 0
    except Exception:
        return False
```

**Scope (May 2026):** Hera' Ghar's `Docs/09_Registers/` has all 14 registers as cloud stubs. Masjid Alnoor and El-Ghamama Gift Shop(2) registers are genuine downloaded files.

**Fix:** Open the file in Excel to trigger OneDrive download, or mark the folder as "Always keep on this device" in OneDrive settings.

**Diagnostic checklist (in order):**
1. `stat -x <file>` — check modified date, inode, device. If `kMDItemIsDownloaded = 1` but reads fail → lock confirmed.
2. `lsof +c 0 <file>` — check which process holds the file. OneDrive processes (PIDs 5468, 5470, 8087, 8228 as of May 2026) are the usual suspects.
3. `xattr -px com.apple.FinderInfo <file>` — if `FF FF FF FF FF FF FF FF` → APFS file lease active.
4. `fuser <file>` — if empty stdout → lease is held at application level, not kernel level.
5. `mdls <file>` — confirm `kMDItemIsUploaded = 1` (rules out incomplete sync).

**Recovery options (try in order):**
1. **Quit OneDrive completely** (all processes: main app + File Provider + Sync Service), wait 30 s, then try reading. Restart OneDrive when done.
2. **Web download:** Go to onedrive.com → navigate to file → download from web. Re-upload when lock clears.
3. **Kill secondary OneDrive instances:** `kill -9 <pid>` on secondary processes (8087, 8228), keep only main (5468) and File Provider (5470). Try reading again.
4. **Rename-via-web:** Rename the file on onedrive.com to a temp name, wait 5 min, rename back. Forces OneDrive to re-sync the inode.
5. **Write to `/tmp/` first:** If you need to create/modify a file that will later be moved to OneDrive, write to `/tmp/` and copy from there. OneDrive sometimes allows reading locked files via `cp` to `/tmp/` even when direct reads fail.
6. **Wait and retry:** If none of the above work, the lock may clear after OneDrive's internal retry cycle (5–30 min). Cron job the retry.

**What NOT to do:**
- Do NOT kill the main OneDrive process (5468) and expect it to release the lock — it doesn't.
- Do NOT try `rsync`, `dd`, or `fcopyfile` — they all hit the same kernel-level lease.
- Do NOT force unmount the OneDrive volume — this corrupts the sync database.

**Prevention:** Avoid having multiple apps open files in OneDrive folders simultaneously (VS Code with OneDrive files, Finder previews, browser downloads). Large batches of simultaneous file writes by OneDrive can leave leases dangling.

### 3. Masjid Alnoor (OneDrive: `Samaya/Technical Office/Bim Unit/Masjid Alnoor`)
- **Location:** Makkah, KSA (Jabal Al-Nour)
- **Client:** NWC (National Water Company)
- **Scope:** Mosque + Visitor/Tafweej center
- **Phase:** Design development, contract finalization

**Known structure:**
```
Masjid Alnoor/
├── As-Built Docs/
├── B.O.Q/
├── Contracts/           ← Engineering services agreements (Rev 01, Rev 02)
├── Design Files/
│   ├── CAD/             ← 5 DWG files (Mosque GF/1F, Visitors GF/Roof, Levels)
│   └── PDF/             ← 6 PDFs + 2 large presentation sets (135MB, 31MB)
├── Docs/
│   ├── 09_Registers/    ← Excel registers: Drawing, Submittal, RFI, SI, NCR, etc.
│   └── ...
├── Submittals/
│   └── Arch/            ← Proposals, CVs, contracts by: SG Group, Segma, TGH, Bedier
└── ...
```

**Drawing Register codes:** DWG-001 to DWG-005 (CAD) · PDF-001 to PDF-006 (PDFs)

### 4. El-Ghamama Gift Shop (2) (OneDrive: `Samaya/Technical Office/Bim Unit/El-Ghamama Gift Shop(2)`)
- **Location:** Makkah, KSA
- **Scope:** Gift shop retail fit-out (branch 2)
- **Phase:** Design development / procurement
- **Registers:** `Docs/09_Registers/` — all 14 registers (Drawing, Submittal, RFI, SI, NCR, CO, Material, Invoice, Meeting Minutes, Transmittal, Contract, Risk, Subcontractor, HSE)

**Known folder structure:**
```
El-Ghamama Gift Shop(2)/
├── B.O.Q/
│   ├── El-Ghamama Gift Shop(2) - BOQ.xlsx
│   ├── GH Retail 02 HVAC BOQ.xls
│   └── List-For-BOQ-abdelrehman.xlsx
├── Design Files/
│   ├── ELGHAMAMH STORE.dwg / .pdf / .bak
│   ├── Plan.dwg, CE.dwg, sec.dwg
│   ├── تصميم متجر هدايا طيبة فرع الغمامة.pdf
│   └── furniture/           ← 30+ Revit families (FU-01 to FU-12)
├── Docs/
│   └── 09_Registers/        ← Full 14-register set
├── Submittal's/              ← ⚠️ Note: "Submittal's" (apostrophe-s)
│   ├── Arch/Last Drawing/
│   │   ├── General Arrangment/  (GA-001, GA-002 Rev-02)
│   │   ├── Rcp/               (RCP-001 Rev-01)
│   │   ├── Flooring/         (FL-001 Rev-01)
│   │   ├── TIMBER PARTITION/ (TP-001, TP-002 Rev-02)
│   │   └── Furntiure/        (DF-001 Rev-01, DF-002 Rev-02)
│   └── Mep/HVAC/
│       ├── GHCC Retail 02- HVAC SD Layout/
│       └── GHCC Retail 02- HAP Reports/
└── Revit Files/
    ├── Rfa/  (ceiling panel, omega, c-channel families)
    └── Rvt/ARCH/  (GHCC Retail 01.rvt, archive versions)
```

**Drawing code prefix:** `GA-` (General Arrangement) · `RCP-` (Reflected Ceiling) · `FL-` (Flooring) · `TP-` (Timber Partition) · `DF-` (Display Furniture) · `ST-` (Store Package)

---

## Document Control Convention

### ✅ Standard Folder Structure (Aseer Template — FINAL)
Every project must mirror this exact layout. For **Completed Tender Package From NRS**, use the 5-folder structure below instead.

```
Project Name/
├── As-Built Docs/
├── B.O.Q/
├── Completed Tender Package From NRS/   (see 5-folder template)
├── Contracts/
├── Design Files/
├── Docs/
│   ├── 00_Project_Charter
│   ├── 01_Contracts_and_ER
│   ├── 02_Plans_and_Procedures
│   ├── 03_Submittals
│   ├── 04_RFIs
│   ├── 05_SIs
│   ├── 06_Authority_Submissions
│   ├── 07_Reports
│   ├── 08_Meeting_Minutes
│   ├── 09_Registers            ← Excel tracking registers
│   ├── 10_Test_and_Inspection
│   ├── 11_Correspondence
│   ├── 12_Compliance_and_Audit
│   ├── 99_Archive
│   └── 99_Reference
├── Email_Archive/
├── Invoices/
├── MOBILIZATION/
├── Reports & Meetings/
├── Revit Files/
│   ├── Cad/  Clash Reports/  Excel Sch/  fbx/  FBX_RVT/
│   ├── Nwc/  Nwd/  Nwf/  Pdf/  Refrences/  Rfa/  Rvt/
├── Scripts/
│   ├── notes/  output/  plans/
├── Specs & Datasheet/
│   ├── GENERAL SPECIFICATIONS/  Project Codes/
├── Submittals/              ← NOT Submittal's (no apostrophe)
│   ├── Arch/  AV Drawings/  BIM/  Consultant Submittel Review/
│   ├── Design Submital/  DOCS/  Life and Safety/  Mep/
│   ├── Reports/  Showcases/  Struc/  Title Block/
├── Time Schedules/          ← NOT Time Scheduales
└── odoo/
    ├── 01_Initiation/  02_DD_Stage/  03_Procurement/
    ├── 04_Manufacturing/  05_Execution/  06_Handover/
```

### 📄 Aseer HTML Document Standard

Every HTML document for the Aseer Museum project **must** follow the CV Submittal Pack template (`ASR-SAM-KP-CV-PACK-SUST-001.html`). See:
`references/aseer-html-doc-standard.md` — covers: required elements (logo-strip, doc-strip, meta-grid, dc-block), CSS foundation (Calibri/Carlito, black borders, 9.75pt), print CSS (A4 portrait, min-height:297mm, overflow:visible for multi-page), naming convention (`ASR-SAM-*`), status tag patterns, and the Drawing Status Tree variant with counter tiles + discipline summary grid.

**⚠️ CRITICAL: Do NOT use `@page { margin: 15mm 18mm }` with `.sheet { padding: 14mm 18mm }`.** This double-applies margins, creating an ~154mm wide column with excessive wasted space. Always use `@page { margin: 0 }` and let `.sheet` padding handle all spacing. The `.sheet` is sized at `width: 210mm` (exact A4) with `padding: 14mm 18mm` giving a 174mm-wide content area (matches the Samaya CV template).

**Logo path** from the `Completed Tender Package From NRS/` root:
```
../Docs/09_Registers/Key_Personnel_Register/CVs/_assets/logos/moc.png
../Docs/09_Registers/Key_Personnel_Register/CVs/_assets/logos/pmc_ace.png
../Docs/09_Registers/Key_Personnel_Register/CVs/_assets/logos/cg.png
../Docs/09_Registers/Key_Personnel_Register/CVs/_assets/logos/samaya.png
```
The `../` goes up one level from the package root to the Aseer-Museum root.

### ✅ Completed Tender Package Structure (NRS Package — 5 folders, NO Incoming_For_Review)

When organizing a design consultant's tender/construction drawing package, use EXACTLY this 5-folder structure. **There is NO `03_Incoming_For_Review` folder** — the user found this confusing and it has been eliminated entirely:

```
Completed Tender Package From NRS/
├── 01_Registers_and_Logs/          # Drawing registers + audit reports
├── 02_Approved_Stamped_Packages/   # STAMPED PDFs ONLY (zero CAD files)
├── 04_Specifications_and_BOQ/      # Specs, BOQ, appendix PDFs
├── 05_Correspondence_Archive/      # Raw deliveries, old revisions, RFIs, REBA remarks
└── 06_Drawing_Source_Folders/      # COMPLETE, UNIQUE, SINGLE SOURCE for ALL drawing files
```

**Key rules (CONFIRMED in May 2026 session):**
- `02_Approved_Stamped_Packages` has **ZERO CAD files** — stamped PDFs only. All source CAD goes to `06_Drawing_Source_Folders/00_Stamped_CAD_Source/`.
- `03_Incoming_For_Review` is **entirely eliminated** — its content was distributed:
  - Unique drawing files → `06_Drawing_Source_Folders/<discipline>/`
  - Appendix PDFs, spec versions → `04_Specifications_and_BOQ/`
  - REBA remarks, RFIs, incoming registers, raw NRS transfers → `05_Correspondence_Archive/`
  - AV Package, Life Safety (non-drawing consultancy docs) → `05_Correspondence_Archive/Incoming_Specs_and_Reports/`
- `05_Correspondence_Archive` holds ALL raw/original/unsorted content: NRS auto-download folders, old revisions, incoming registers, RFIs, REBA remarks, AV/Life Safety packages.
- `06_Drawing_Source_Folders` is the **complete, unique, single source** for all drawing files. No duplicates allowed. All 243 drawings from DIS_021 should be represented here.

### ⚠️ Non-Standard Project Structures
Some projects use completely different folder conventions. The watchdog's classification uses these as fallback "Docs" when no subfolder keyword match is found. Known departures:

| Project | Notes |
|---|---|
| **Masjid Alnoor** | Now follows standard template ✅ |
| **Jabal Omar - Samaya Scope** | `Datasheets`, `Docs`, `Exterior Screens`, `General`, `Jabal Omar - Deliverables` (no standard subdirs) |
| **Ryadh Museum** | `Docs`, `Ryadh Meuseum Fin` |
| **Hadaya_Teiba_01_GND** | Only `odoo/` |

When processing files from these projects, manually map to the non-standard subdir rather than the template.

```
ZAM-NWC-<CTR|MUM>-<TYPE>-<DISCIPLINE>-<NNN>_Rev.<XX>
   │   │     │        │         │        │
   │   │     │        │         │        └── Revision (00 = first issue)
   │   │     │        │         └─────────── Sequential number
   │   │     │        └────────────────────── Discipline
   │   │     └─────────────────────────────── Submittal type
   │   └───────────────────────────────────── CTR=Contractor / MUM=Museum-employer side
   └───────────────────────────────────────── ZAM=Zamzam project
```

**Submittal types:** DOC · MAR · MIR · SDR · RFP · RFI · IR · SI · SCH · REP · GEN · LET

**Disciplines:** AR (Architecture) · STR (Structural) · EL (Electrical) · ME (Mechanical/HVAC) · FP (Fire Protection) · PLM (Plumbing/Drainage) · CONT (Exhibition Content) · GN/GEN (General)

**Review statuses:** قيد الدراسة (Under Review) · A (Approved) · B (Approved w/ comments) · C - إعادة تقديم (Resubmit)

**Auto-sort routing (by discipline code in filename):**
- `-STR-` → `Submittal's/Struc`
- `-EL-` / `-ME-` → `Submittal's/Mep`
- `-AR-` → `Submittal's/Arch`

---

## Email & Attachment Pipeline

**Source:** Outlook `sultan@samayainvest.com` → `Zamzam Projects` folder (828 msgs, Sep 2023→May 2026)

**Pipeline scripts** (in `Docs/_Tools/` of Zamzam project):
```
01_extract.py       → attached/ + manifest.json
02_generate_md.py   → Category MD files (re-runnable)
classify_driver.py  → Kimi + Gemini auto-classification
```

**Output:** One Markdown file per category in `Docs/Zamzam_Emails_Organized/` + INDEX.md.
Each row: date · sub-project · direction · subject · attachment/SharePoint link · move-status (📥 staged → ✅ moved)

**Workflow:**
1. Extract emails with `01_extract.py`
2. Run `02_generate_md.py` to refresh category files
3. Run `classify_driver.py` (Kimi+Gemini) to auto-classify attachments
4. Move files from `attached/` to proper folders
5. Re-run `02_generate_md.py` to flip status from 📥 to ✅
6. Do NOT save emails individually — update category MD files only

**Detailed reference:** `references/email-pipeline-commands.md`

**General project email archive template:** See `project-email-archive` skill — defines the canonical 2-tier structure (Email_Archive/ + Docs/Email Archive/), 14 document-category codes, and naming conventions that apply to ALL Samaya projects, not just Zamzam.

**Automated email pipeline:** See `bim-email-pipeline` skill — runs every 2 hours via cron, connects to Outlook via AppleScript, classifies emails by project, downloads attachments to correct subfolders, and archives as MD files.

---

## CV Pack System (samaya-cv-pk)

HTML-based A4-portrait CV Submittal Packs with `.sheet` framing system.

| Team | Doc Code |
|---|---|
| Samaya (Site) Team | `ASR-SAM-KP-CV-PACK-SITE-001` |
| BIM Unit | `ASR-SAM-KP-CV-PACK-BIM-001` |
| Sustainability | `ASR-SAM-KP-CV-PACK-SUST-001` |

**Submittal path:** `Subcontractors/01_Showcase_Contractor/` — NRS-stamped CV packs and showcase submittals are filed here as `Submittal_NN_date/` subfolders or individual dated PDFs.

**Reference files:** `Docs/09_Registers/Key_Personnel_Register/CVs/_archive/HTML/`
**Two CSS variants:** Standard (9.75pt) · Compact (8pt)
**RTL support:** Tajawal font, dir=rtl for Arabic/bilingual docs
**Auto-paginate:** Use `scripts/autopaginate.js` (v2.1) — embedded JS that **splits** overflowing .sheet content into new pages (not just detect). Include before `</body>` in every Samaya bilingual HTML report. Re-numbers page footers automatically. CSS must have `.sheet { max-height: 297mm; overflow: hidden; }` for detection to work.
**Per-candidate:** Professional Summary → Mission Brief → Scope → Competencies → Experience → Education → Certifications → Languages

---

### Report Chart & SVG Style Guide

When creating charts (EVM S-curves, payment waterfalls, etc.) for Samaya reports, reference `references/samaya-template-style.md` for exact colors, sizes, and layout conventions.

Key rules:
- **Light theme only** — white backgrounds (`#FFF`), never dark
- **A4 portrait** — charts fit within 210mm × 297mm
- **Samaya tag colors** — use `.tag.*` palette (green/blue/amber/red/gray)
- **Assessment boxes** — amber warning style matching `.note.warn`
- **No redesign** — always `patch()` existing reports, append new sheets
- **Delegate chart verification** to Claude Code subagent for SVG validity + coordinate math

### Odoo ERP — Live API Connections

Two Odoo instances accessed through **Claude Code** (sub-labor) via Python XML-RPC:

### Instance 1: Samaya Investment
| Detail | Value |
|---|---|
| **URL** | `https://samayainv.odoo.com` |
| **Database** | `peerless-tech-samaya-18-0-18447146` |
| **User** | `sultan@samayainvest.com` (uid 151) |
| **Version** | Odoo 18.0+e |
| **Creds file** | `~/.config/samaya/odoo.env` (mode 600) — DO NOT move to OneDrive |
| **API key env var** | `ODOO_API_KEY` in that file |
| **Projects mapped** | 13 tracker IDs ↔ Odoo #s: Zamzam #121, Aseer, Maalim Museum #176, Ghamama #136, Quran Museum #137, Bay'a Center #246, CEO Villa #294, etc. |

**Auth method:** XML-RPC with `certifi` (macOS cert store fails SaaS handshake otherwise):
```python
import xmlrpc.client, ssl, certifi
ctx = ssl.create_default_context(cafile=certifi.where())
transport = xmlrpc.client.SafeTransport(context=ctx)
```

### Instance 2: Dawam Tech
| Detail | Value |
|---|---|
| **URL** | `https://dawam-tech.odoo.com` |
| **Database** | `dawam-tech` |
| **User** | `sultan@dawamtech.com` (uid=2) |
| **Version** | Odoo 19.0+e |

**Claude Code memory reference:** `~/.claude/projects/-Users-mohamedessa/memory/reference_odoo_dawam.md`
Contains verified product IDs (181-183), tax IDs, UoM IDs, and sale-order automation patterns.

### Important: How to find Odoo connection details
When you need Odoo access, **delegate to Claude Code** to search its own project memory:
```
claude -p "Search your project memory for Odoo connection details" --allowedTools "Glob,Grep,Read" --max-turns 5
```
Claude stores Odoo references in `~/.claude/projects/*/memory/` and credentials in `~/.config/samaya/odoo.env`.

### Odoo 18 ↔ 19 quirks (from Dawam experience)
- `sale.order.line.tax_id` was renamed to `tax_ids` (Many2many) in v19
- `sale.order.line.product_uom` was removed → use `product_uom_qty`
- `uom.uom.category_id` removed in v19
- `product.template.type` values: `consu`, `service`, `combo` (no `product`, no `detailed_type`)

---

## Notion Integration

**Setup:**
- API key stored in `~/.hermes/.env` as `NOTION_API_KEY` (format: `ntn_...`)
- Bot name: MacHermes (connected to **Samaya inv.** workspace, ID: `69e666ae-f47b-4c7d-84d7-e8ee1f58eaef`)
- Skill: `productivity/notion` (load for full API reference)

### ntn CLI — Install & Headless Setup

```bash
# Install (non-root — avoids /usr/local/bin permission error)
curl -fsSL "https://ntn.dev" | NTN_INSTALL_DIR="$HOME/.local/bin" bash

# Add to ~/.hermes/.env for headless operation:
export NOTION_API_TOKEN=***  # same value as NOTION_API_KEY
export NOTION_KEYRING=0                     # file-based auth (no keychain)
export NOTION_WORKSPACE_ID="69e666ae-f47b-4c7d-84d7-e8ee1f58eaef"
export PATH="$HOME/.local/bin:$PATH"
```

**Key distinction:** Notion REST API uses `secret_`-prefixed tokens (for curl/HTTP calls).
`ntn` CLI uses `ntn_`-prefixed tokens. Both formats are set via `NOTION_API_KEY` in `.env`.
The `NOTION_API_TOKEN` env var (with the same value) is what `ntn` reads at runtime.

**Verify:**
```bash
ntn --version
ntn api v1/users       # lists workspace users
ntn api v1/search -X POST query=.   # search pages
```

**Available through Notion API HTTP + curl:**
- Search, read, create, update pages and databases
- Read/write page as Markdown (`/markdown` endpoints)
- Query data sources (databases)
- Upload files

**Also available through Claude Code MCP:** Claude has Notion MCP connected (`claude.ai Notion`). For Notion operations, you can either use the Notion API directly or delegate to Claude Code.

---

## Odoo Procurement — File-Based Records

Records stored under `odoo/` in project directories. Format:
```
PO_NUMBER: P00448
VENDOR: Outsorce Labor
AMOUNT: 19973.89 SAR
STATUS: COMPLETED (PAID)
```

For live Odoo queries (open POs, vendor lookups, project status), delegate to Claude Code with the XML-RPC pattern above.

---

## Odoo Personal Tasks (To-Do Module)

For Odoo To-Do task creation via XML-RPC (personal tasks, no project), see:
`references/odoo-personal-tasks.md` — covers authentication fix (`{'interactive': True}` required for Odoo 18), stage_id=95 (Inbox), priority string values, and the `create` + `user_ids` assignment pattern.

## Daily Todo Cron

Automated daily extraction of action items from email registers + watchdog file activity.
See: `references/daily-todo-workflow.md` — data sources, priority classification, deduplication, output format, and delivery options (Telegram vs Odoo To-Do).

## Odoo

Two Odoo instances:
1. **Samaya** (default) — `samayainv.odoo.com`, Odoo 18, db: `peerless-tech-samaya-18-0-18447146`, user: `sultan@samayainvest.com`. Credentials: `~/.config/samaya/odoo.env`. This is the **default** — always use this unless Dawam is explicitly requested.
2. **Dawam Tech** (only on request) — `dawam-tech.odoo.com`, Odoo 19, db: `dawam-tech`, user: `sultan@dawamtech.com`. Referenced in Claude Code's memory at `reference_odoo_dawam.md`.

### Task Management Rules
- **Marking tasks done:** Use `state = '1_done'` — this marks the task as completed WITHOUT changing its stage. Do NOT move tasks to a different stage to mark them done.
- **XML-RPC pattern:**
  ```python
  M.execute_kw(DB, uid, PWD, 'project.task', 'write', [[task_id], {'state': '1_done'}])
  ```
- **Update deadlines:** `M.execute_kw(DB, uid, PWD, 'project.task', 'write', [[task_id], {'date_deadline': '2026-06-07'}])`
- **Query tasks:** `search_read` with domain `[['user_ids', 'in', [uid]]]`
- **Connect:** Use `certifi` SSL context for XML-RPC to handle macOS cert issues. Python boilerplate in Claude's project memory.

**When marking tasks as done, do NOT change the stage.** The team marks tasks done in-place using the `state` field:

```python
# CORRECT — marks done without moving stage
M.execute_kw(DB, uid, PWD, 'project.task', 'write', [[task_id], {'state': '1_done'}])

# WRONG — do not change stage_id
M.execute_kw(DB, uid, PWD, 'project.task', 'write', [[task_id], {'stage_id': some_stage}])
```

Tasks stay in their current stage so you can see all tasks in a pipeline with their completion status visible per-stage. The `state = '1_done'` field sets `is_closed = True` automatically.

### Username correctness is critical
- Samaya Odoo: `sultan@samayainvest.com` (correct)
- Dawam Odoo: `sultan@dawamtech.com` — note: **no hyphen** in dawamtech.com even though the URL uses `dawam-tech.odoo.com`. Always verify from the credentials file, never guess the hyphenation.

## 🔴 CRITICAL SAFETY RULES (Never Violate — These caused data loss before)

1. **ALWAYS confirm task completion to Mohamed Essa** — even for terminal/CLI commands. Report what was done, what changed, and any issues found. "ok done" means NOTHING — you must always report back. This is non-negotiable.

2. **`rm -rf` — STRICT CONTROL, not absolute ban** — `rm -rf` deletes entire folders irreversibly through OneDrive sync
   - **Allowed ONLY when:** the user explicitly confirms the specific folder path via the `clarify` tool with choice confirmation. The user's approval creates an explicit audit trail.
   - **Preferred pattern for folders:** Always present the option list showing exactly what will be deleted, use `clarify` to get user choice, and only after explicit confirmation proceed with `rm -rf <confirmed_path>`
   - **Default (no confirmation):** Use file-level `rm <filename>` for individual files, never `rm -rf <folder>`
   - OneDrive propagates deletions to the cloud immediately — no undo

3. **When the user asks to clean up Downloads/organize files**, archive unknown/non-project files to `_Archive/_from_Downloads_Documents/Samaya_Misc/` — do NOT leave them in place. But NEVER use `rm -rf` — remove individual files only. Archive folders go under `_Archive/` at the BIM Unit root.

4. **NEVER create new Excel files** for registers — only append rows to existing ones
   - Scan the project for existing `.xlsx`/`.xls` files first
   - Find the best-matching file by filename + column headers
   - Append rows at the bottom of the data sheet
   - Only if zero Excel files exist, then ask the user about creating one

5. **When marking Odoo tasks as done**, use `state = '1_done'` — this marks completed in-place without changing the stage. Do NOT move tasks to a different stage.

## 🧹 Existing Project Folder — Cleanup & Template Alignment

When an existing project folder has accumulated junk software artifacts (Program Files/, Users/ from 3ds Max), lock files, duplicate ZIPS, generic folder names ("New folder"), cross-project documents, or is missing standard template subfolders — see `references/existing-project-cleanup.md`.

This is a structured 7-phase process: remove software artifacts → remove lock/temp files → remove duplicate ZIPS → remove cross-project documents → rename generic folders → create missing template folders → verify. See the reference for exact commands for each phase.

## 📁 Automatic Root-File Organization

When given a file path at the **root** of any project folder (not inside a numbered subfolder), automatically:

1. **Read** the file to understand its type and content
2. **Check for duplicates** — search for same-named files across Outlook Temp/, Desktop/, other project folders, Subcontractors/, Email Archive/
3. **Move** it to the correct BIM subfolder based on content:
   - Plans/strategies → `02_Plans_and_Procedures/`
   - Submittals/design docs → `03_Submittals/`
   - RFIs/TQs/technical queries → `04_RFIs/`
   - SIs → `05_SIs/`
   - Reports → `07_Reports/`
   - Meeting minutes → `08_Meeting_Minutes/`
   - Registers/logs → `09_Registers/`
   - Correspondence/emails → `11_Correspondence/`
   - Contracts → `01_Contracts_and_ER/`
   - Proposals → route by discipline
4. **Clean up** — delete duplicate temp/Desktop copies after confirming canonical copy is filed correctly
5. **Confirm** the move with the user — what was moved, duplicates removed, where the canonical copy lives

Never leave loose files at the project root. Always file into the proper numbered subfolder structure.

## 🧹 File & Document Deletion Workflow (Samaya OneDrive)

When the user asks to remove files/documents from Samaya projects (e.g., project cleanup, removing obsolete tenders, deleting wrong-project files):

### 1. SEARCH — Use `mdfind` for fast OneDrive-wide search
The Samaya OneDrive is too large for `find`/`grep` (timeouts on 60s+ scans). Always use Spotlight (`mdfind`) for initial discovery:

```bash
mdfind -onlyin "/path/to/Samaya/OneDrive" "كسوة الكعبة" 2>/dev/null
mdfind -onlyin "/path/to/Samaya/OneDrive" "keyword" 2>/dev/null
```

- Supports Arabic and English keywords
- Searches filenames AND file content (be aware of content-level matches)
- Returns paths directly — no timeout issues
- Also try: `mdfind "kiswa" -onlyin ~` for cross-folder searches

### 2. CATEGORIZE — Classify results into groups
Arabic naming can be ambiguous (كسوة = "Kaaba covering" project OR "cladding" in general construction). Categorize into:

- **Direct project files** — Belong to the project the user wants removed
- **Related but different** — Same term but different project context (e.g., "Kaba Door" is a museum exhibit, not "Kiswa" project)
- **Not related** — Homonyms (كسوة as "cladding" in shower specs), brand names (DormaKaba), vendor logos

### 3. PRESENT & CONFIRM — Use `clarify` for explicit scope choice
Always present categorized options via the `clarify` tool:
- "Category A only (direct project files)"
- "Category A + B (broader scope)"
- Include the file count per category

**Never delete without explicit user confirmation.**

### 4. DELETE — Use verified paths
After confirmation:
- **For individual files:** `rm <filepath>` per file
- **For entire folders** (user confirmed): `rm -rf <folderpath>` — ONLY after clarify confirmation
- Delete the cleanest path — if a whole folder is all Kiswa files (e.g., `Tenders/2026/kabaa cover store/`), remove the folder rather than individual files to avoid leftover empty directories

### 5. VERIFY — Confirm deletion succeeded
- Check `ls <path>` returns "No such file or directory" for removed files
- Re-run `mdfind` to confirm no remaining matches
- For OneDrive cloud paths, verify on the web if possible (deletion syncs to cloud immediately)

### 6. REPORT — Structured confirmation
Always report back to Mohamed Essa with:
- What was deleted (locations + item counts)
- What was kept (explicitly excluded)
- Verification results (clean/remaining)

### ⚠️ Pitfall: OneDrive cloud-stub and file lock
Some OneDrive files may be cloud-only stubs (~6.5 KB). `rm` and `mv` work on these (metadata-only operations). But `cp` and read operations hang. For deletion, `rm` is safe — it just removes the directory entry without downloading the file content.

### 🔴 CRITICAL: Audit Scope Baseline — Always Read ER & SOW First

Before starting ANY RIBA audit or deliverable mapping for a Samaya project:

1. **Locate the Employer's Requirements (ER)** — Search the project for `ER*`, `Employer*Requirement*` in `01_Contracts_and_ER/`, `Design Files/Package_Part 2/`, and `Docs/03_Submittals/.../01_NRS_Specs/`. The ER defines what the Contractor must deliver.
2. **Locate the Scope of Work (SOW)** — Search for `*Scope of Work*`, `*SOW*`, `*Contractors Scope*` — often a separate PDF/MD in the tender pack.
3. **Read both** before writing a single line of audit. Extract:
   - What is explicitly **in scope** for the Contractor
   - What is **excluded** (marked [MoC] — employer-supplied)
   - **Handover requirements** (often a numbered list, e.g. ER §2.7 has 17 items)
   - **Approval responsibility** (who submits which NOC/approval)
   - **BIM requirements** (BEP mandatory? LOD? As-built?)
4. **Tag every deliverable** with its scope origin:
   - `[MoC]` = Employer-supplied, NOT in Contractor scope (text/labels, AV software, content research, copyright, mounts package)
   - `[NRS/DESIGN]` = NRS design deliverable managed by Samaya
   - `[SAMAYA]` = Direct Samaya responsibility
   - `[ER §X.X]` = Reference to specific ER clause
5. **Include a scope disclaimer** on the cover sheet of every audit document, listing what is excluded and what contractual docs were used.

**⚠️ Pitfall:** An audit that skips this step will mark MoC-excluded items as "MISSING" (incorrect) or miss mandatory in-scope deliverables (BEP, Design Cert, ITCA, 17-item handover, etc.).

**Aseer-specific references (verified May 2026):**
- ER: `Design Files/Package_Part 2/05_AS_Employer's Requirements Documents_250313/Contractors Employers Requirements - Engineering_250313/` (170pp, Rev 1.0, 12 Mar 2025)
- SOW: `Design Files/Package_Part 2/05_AS_Employer's Requirements Documents_250313/Contractors Scope of Works Document - Technical_250313/6380_KMS_RPT_PM_AS_00006_Aseer_Contractors_Scope of Work.md` (46pp, 3 Mar 2025)

### Exclusions Register (Aseer Museum — MoC-Supplied, NOT Samaya Scope)
- Exhibition text and labels
- Content research
- Image copyright and licensing
- Mounts package
- AV/Media software and content (AV HARDWARE is in scope)
- Exterior landscape EX1/EX2 (deferred to later stage)

### Handover Deliverables (ER §2.7 — 17 items, ALL Samaya responsibility)
1. Room Data Sheet compliance | 2. Snag list completion | 3. As-Built drawings | 4. Permits and NOCs | 5. O&M Manuals | 6. Warranties and guarantees | 7. Spares schedule | 8. Keys and access devices | 9. ITCA test results | 10. Pest control certificate | 11. Building Manual | 12. H&S File | 13. Training certificates | 14. Asset Information | 15. Final cleaning certificate | 16. Commissioning certificates | 17. Practical Completion Certificate

### 🎯 RIBA 2020 Framework — Multi-Stage Deliverable Mapping (D&B Main Contractor)

When asked to map deliverables for RIBA Stages 4, 5, and 6 from the Main Contractor's perspective in a Design & Build project, use this workflow and the 100-deliverable 15-category (A-O) structure.

### Core RIBA 2020 Deliverable Understanding (from official docs)

**Stage 4 (Technical Design):** "All design information required to manufacture and construct the project completed." The design team + specialist subcontractors complete the technical design. Two types of info:
- **Prescriptive Information** — can be used directly for construction (design team produces)
- **Descriptive Information** — issued where a specialist subcontractor will design a Building System

**Stage 5 (Manufacturing & Construction):** "Manufacturing, construction and Commissioning completed." The construction team takes centre stage. No design work except responding to Site Queries. Prepares towards Practical Completion.

**Stage 6 (Handover):** "Building handed over, Aftercare initiated and Building Contract concluded." Starts at Practical Completion. Includes Building Manual, H&S File, defects rectification, Aftercare, POE, Final Certificate.

### Multi-Stage Deliverable Tree Workflow

When asked to produce a Stage 4-6 deliverable tree for a D&B project:

1. **Understand procurement context** — Is it D&B single stage? Two stage? Who is Design Lead (NRS)? Which specialists are appointed? (OTIS, OCULEAP, Obeikan, BCG). Check the existing Drawing Register (DIS_021).

2. **Map deliverable categories across 3 stages** — Use the 15-category structure below. For each, assess current project status using 6-level RAG:
   - **OK** (g/green) — Complete, signed off
   - **PARTIAL** (a/amber) — Received but pending review/action
   - **PENDING** (b/blue) — Not started but scope known
   - **MISSING** (r/red) — Critical gap, never received, blocking downstream
   - **FUTURE** (f/grey) — Not yet due (construction/handover activities)
   - **N/A** (n/light grey) — Not applicable

3. **Build the tree** — Each category is a group header (A-O). Items within are numbered (A01, A02...) with monospace tree lines (`├── └──`). Each row has: Ref, Tree path (with indentation), Status description, RAG badge.

4. **Generate HTML** — Use Samaya template with `.tree-table` CSS class (monospace tree column). 6 sheets: Cover + Stage 4 Part 1 + Stage 4 Part 2 + Stage 5 + Stage 6 + Summary Dashboard with category-by-category RAG breakdown and priority actions.

### Standard Tree Categories (A-O) — 100+ Deliverables

```
STAGE 4 — TECHNICAL DESIGN
├── A. Manufacturing Information (Prescriptive, NRS direct output)
│   ├── A01 General Arrangement Drawings (plans, sections, elevations)
│   ├── A02 Wall Type Details (internal wall build-ups, junctions)
│   ├── A03 Floor Type Details (floor build-ups)
│   ├── A04 Ceiling Type Details (ceiling build-ups)
│   ├── A05 Door Types & Schedules (ironmongery)
│   ├── A06 Finish Schedules (room finishes)
│   ├── A07 Stairs Details (stair plans, sections)
│   ├── A08 Internal Elevations (gallery wall elevations)
│   ├── A09 Existing/Demolition Plans [often MISSING from NRS]
│   └── A10 Sections (longitudinal) [often MISSING from NRS]
├── B. Construction Information (Descriptive — for specialist subcontractors)
│   ├── B01 Showcases & Display Cases (types 1-6B)
│   ├── B02 Setworks & Partitions (freestanding walls)
│   ├── B03 Setworks Details (furniture, exhibits, displays)
│   ├── B04 Graphics & Panel Housing (labels, signage)
│   ├── B05 AV & Multimedia (AV totems, monitor housing, projection)
│   ├── B06 External Details (fixed benches) [often PDF-only, no CAD]
│   ├── B07 Washrooms/VIP WC
│   └── B08 Painted Finishes
├── C. Specialist Subcontractor Design (Stage 4/5 overlap)
│   ├── C01 Showcase / Display Case Design (Glasbau Hahn)
│   ├── C02 Setworks & Scenography Design (Samaya in-house)
│   ├── C03 Graphics & Wayfinding Production Design
│   ├── C04 Models & Replicas Design
│   ├── C05 AV/IT Systems Design (BOQ §011 hardware; software MoC)
│   ├── C06 Exhibition Lighting Design
│   ├── C07 Acoustics Design
│   ├── C08 Rigging Design (overhead exhibit rigging)
│   ├── C09 Furniture & FF&E Design
│   ├── C10 MEP Systems Design (BCG — HVAC, electrical, plumbing, BMS)
│   ├── C11 Fire Protection & Life Safety Design
│   ├── C12 Structural Modifications
│   ├── C13 Specialist Glazing Design (Obeikan Glass)
│   ├── C14 OTIS Lift Design (shaft, structural interface, platform)
│   ├── C15 Materials Testing & Certification (Oddy, PAS 198, ISO 16000)
├── D. Specifications & Reports
│   ├── D01 Architectural Specification (NRS)
│   ├── D02 Ceilings Performance Spec
│   ├── D03 Floors Performance Spec
│   ├── D04 Wall Systems Performance Spec
│   ├── D05 Sustainability / Mostadam Strategy [often PENDING]
│   ├── D06 Fire Safety Strategy
│   ├── D07 Cost Plan / Pre-Tender Estimate
│   ├── D08 Preliminaries / Project Management Sections
│   ├── D09 Design Certification [ER §6.8] — often MISSING
│   ├── D10 IFC Document List — often MISSING
│   ├── D11 Product Data & Certificates
│   └── D12 Interface Responsibility Matrix
├── E. Statutory & Authority Compliance [ALL Samaya responsibility — often ALL MISSING]
│   ├── E01 Building Regulations Application (SBC)
│   ├── E02 Discharge Pre-Commencement Conditions
│   ├── E03 SCD/GDCD Approval
│   ├── E04 SEC Approval (Saudi Electricity Company)
│   ├── E05 MOI Civil Defence Approval
│   ├── E06 Municipality (MoMRAH) Approval
│   ├── E07 CITC/CST Approval
│   └── E08 Aseer Emirate Approval
├── F. BIM & Digital Delivery
│   ├── F01 CAD Source Files
│   ├── F02 Drawing PDFs
│   ├── F03 Drawing Register (DIS_021)
│   ├── F04 NRS Revit BIM Model(s) [often TBC — verify LOD]
│   ├── F05 BIM Execution Plan [MANDATORY per ER §2.3.D — often MISSING]
│   ├── F06 CDE (Aconex) exchange protocols
│   ├── F07 Clash Detection Report [often MISSING]
│   ├── F08 4D Construction Sequencing [often MISSING]
│   ├── F09 50/90/100% Gateway Reviews
│   └── F10 As-Built BIM Model (at Practical Completion)
├── G. Health, Safety & Welfare
│   ├── G01 Pre-Construction Information (H&S)
│   ├── G02 Construction Phase Plan (draft)
│   ├── G03 Health and Safety File (initial)
│   └── G04 Fire Safety Information (for H&S File)

STAGE 5 — MANUFACTURING AND CONSTRUCTION
├── H. Pre-Construction / Mobilisation
│   ├── H01 Construction Programme / Master Programme
│   ├── H02 Site Logistics Plan
│   ├── H03 Construction Phase Plan (final)
│   ├── H04 Quality Management Plan / ITP
│   ├── H05 Subcontractor Procurement Schedule
│   ├── H06 Site Safety & Welfare Setup
│   └── H07 Environmental Management Plan
├── I. Specialist Coordination (post-contract installation)
│   ├── I01 Showcase Installation (Glasbau Hahn — fabrication, site install)
│   ├── I02 Setworks & Scenography Fabrication (Samaya factory)
│   ├── I03 Graphics Production & Installation
│   ├── I04 Models & Replicas Fabrication
│   ├── I05 AV/IT Installation & Integration
│   ├── I06 Exhibition Lighting Installation
│   ├── I07 Rigging & Art Mounting
│   ├── I08 Furniture & FF&E Delivery
│   ├── I09 MEP Installation & Coordination (BCG/ITC)
│   ├── I10 Fire Protection & Life Safety Installation
│   ├── I11 Structural Works
│   ├── I12 Glazing Installation (Obeikan)
│   ├── I13 OTIS Lift Installation
│   ├── I14 Materials Compliance & Oddy Testing (on-site)
├── J. Construction Monitoring & Quality
│   ├── J01 Construction Quality Inspections [FUTURE]
│   ├── J02 Site Query / RFI Log [FUTURE]
│   ├── J03 Weekly Progress Reports [FUTURE]
│   ├── J04 Monthly Cost Reports/Valuations [FUTURE]
│   ├── J05 Design Change/Variation Control [PENDING]
│   └── J06 Defects List (pre-PC) [FUTURE]
├── K. Commissioning, Testing & Certification
│   ├── K01 ITCA Appointment & Plan [MISSING — must appoint]
│   ├── K02 Commissioning Plan (MEP, life safety, AV, lifts)
│   ├── K03 Factory Acceptance Testing (FAT) [NEW]
│   ├── K04 Site Acceptance Testing (SAT) [NEW]
│   ├── K05 OTIS Lift Commissioning
│   ├── K06 Fire & Life Safety Commissioning
│   ├── K07 BMS / Building Controls Commissioning
│   ├── K08 ITCA Test Results & Certificates [NEW — ER §2.7]
│   └── K09 Third-Party Certification (Mostadam, code compliance, fire safety)

STAGE 6 — HANDOVER
├── L. Building Manual & Asset Information
│   ├── L01 Building Manual [PENDING — starts in Stage 4]
│   ├── L02 H&S File (final) [PENDING]
│   ├── L03 Asset Information (schedules, warranties)
│   ├── L04 Fire Safety Information
│   ├── L05 O&M Manuals (from specialists) [FUTURE]
│   ├── L06 As-Built Drawings / VCI [FUTURE]
│   └── L07 Spare Parts Schedule [FUTURE]
├── M. Practical Completion & Handover
│   ├── M01 Practical Completion Inspection [FUTURE]
│   ├── M02 Snagging/Defects List (final) [FUTURE]
│   ├── M03 PC Certificate [FUTURE]
│   ├── M04 Client Training & User Induction [PENDING]
│   ├── M05 FM Handover [PENDING]
│   └── M06 Key Handover [FUTURE]
├── N. Aftercare & Post-Occupancy
│   ├── N01 Aftercare Plan (12 months) [PENDING]
│   ├── N02 Aftercare Meetings [FUTURE]
│   ├── N03 Seasonal Commissioning [FUTURE]
│   ├── N04 Light Touch POE [FUTURE]
│   ├── N05 Defects Liability Management [FUTURE]
│   ├── N06 Final Certificate [FUTURE]
│   ├── N07 Project Performance Review [FUTURE]
│   └── N08 Mostadam Certification (final) [PENDING]
├── O. Contractual & Commercial Close-Out
│   ├── O01 Final Account [FUTURE]
│   ├── O02 Contract Completion Certificate [FUTURE]
│   ├── O03 Bond/Guarantee Releases [FUTURE]
│   └── O04 Subcontractor Final Accounts [FUTURE]
```

### Typical RAG Distribution (Aseer Museum, May 2026 — D&B mid-stage)
From a real session: ~18 OK, ~21 PARTIAL, ~33 PENDING, ~12 MISSING, ~24 FUTURE across 100 items.
- **Stage 4 strength** — NRS stamped drawings (A01-A08) mostly OK/PARTIAL, Specifications received
- **Stage 4 gap** — Statutory approvals (E01-E08) ALL missing, BIM items (F04-F08) mostly MISSING
- **Stage 5 gap** — Pre-construction items (H01-H07) all PENDING — not triggered until site possession
- **Stage 6 gap** — Building Manual (L01) not yet started even though compilation should start in Stage 4

### CRITICAL: Use delegate_task for heavy HTML work
The deliverable tree HTML is ~58KB across 6 sheets. Always use a subagent (not main session) to:
1. Read existing template CSS from the Stage 4 audit file
2. Build the full tree with all 100 items, correct RAG assessments, and category groupings
3. Write the output to the NRS package folder

### Reference File
Full tree structure with assessment notes and example assessments per item:
`references/riba-stage4to6-deliverable-tree.md`

### RIBA Deliverable Tree — Counter Consistency Audit & Cross-Project Data Check

When updating an existing RIBA Stage 4-6 Deliverable Tree HTML document and asked to "update" without specifics:

**⚠️ Pitfall: Cross-project data contamination.** The initial tree template may contain specialist items from other projects (e.g., OCULEAP 5D/Flying Cinema from El-Ghamama leaked into Aseer). Before any audit, cross-check every specialist subcontractor name against the project's actual scope. Memory entries about which specialist belongs to which project are authoritative. If you find wrong-project data, remove the entire items AND all textual references, then renumber all subsequent items and recalculate every counter.

**⚠️ Pitfall: The document has 18 independent counter blocks** (sheet 1 summary, 15 category headers, dashboard overall, 3 stage summaries, 1 category breakdown table, 1 totals row). If one or more drifted from the actual item RAG statuses, the document is internally inconsistent. Do NOT just bump the revision — audit all counters first.

**Protocol:**

1. **Extract every individual item** — Read the full HTML. Parse every `<tr>` row. Record each item's ref (A01..O04), its category, and its RAG badge (`class="rag g/a/r/b/f/n"`).

2. **Build the ground-truth matrix** — Count items per category per RAG status. Verify:
   - Sum per category = category total (header label e.g. "10 items")
   - Grand total = 138 (or whatever the declared total is)

3. **Compare every counter in the document against the truth:**
   - **Sheet 1 summary counters** (6 `.summary-item` tiles)
   - **15 category headers** (each `<tr class="cat-header">` with `<span class="rag ...">` badges)
   - **Dashboard overall** (text + bar widths in the summary section on Sheet 6)
   - **3 stage summaries** (Stage 4/5/6 boxes with text + bar widths)
   - **Category breakdown table** (Sheet 6 — `<table class="tree-table">` with all 15 rows + totals)
   - **Totals row** (last row in category table)

4. **Fix every discrepancy** — For each mismatch:
   - Sheet 1 summary → update `.summary-item .num` text
   - Category header → update the `<span class="rag ...">` badge texts
   - Dashboard text → update percentage text and bar `width:X%` values
   - Stage summary boxes → update item counts, bar widths, and bottom-text percentages
   - Category table → update individual `<td>` cell text for the affected columns
   - Totals row → update all 6 column values

5. **Bump revision** — Replace all `Rev XX` with `Rev XX+1` across all 6 sheets and the meta grid.

6. **QA audit** — Run Codex audit (not Kimi) to verify:
   - All 18 counter blocks match the ground-truth matrix
   - Grand totals reconcile: 14+31+48+16+29 = 138 (Aseer typical spread, verify actual)
   - Bar widths sum to 100% in all chart sections
   - Critical gaps box count matches Missing count

### 🎯 RIBA Stage 4 Technical Design — Checklist Audit

⚠️ **CRITICAL: Read ER & SOW first** — Before any Stage 4 audit, follow the "🔴 CRITICAL: Audit Scope Baseline" workflow above. Locate the ER and SOW, extract what is in scope vs what is excluded ([MoC]). An audit that doesn't account for scope boundaries will include out-of-scope deliverables and miss contractual obligations.

When asked to audit a project's Stage 4 deliverables against the **official RIBA 2020 Stage 4 checklist** (from RIBA Job Book 9th Edition), use this workflow.

### Workflow

1. **Obtain the checklist** — The user may provide a PDF (`4-technical-design-checklist-pdf.pdf`). Extract text via `pdftotext` (macOS: `/opt/homebrew/bin/pdftotext`). The checklist has **6 sections, ~60 items**:
   - 4.1 Client Team (12 items)
   - 4.2 Design Team (11 items)
   - 4.3 Construction Team (11 items)
   - 4.4 Cost (4 items)
   - 4.5 Other Activities (14 items)
   - 4.6 BIM and Digital Technology (8 items)

2. **Extract item structure** — Parse the text to find all numbered checklist items. Each has a reference number (e.g., 4.1.1), a requirement description, and "Enter notes here" / "Completed on" placeholders. Map the hierarchy:
   ```bash
   grep -n "^[0-9]\.[0-9]" /tmp/riba4_checklist.txt  # lists all numbered items
   ```

3. **Assess each item against project reality** — For each of the ~60 items, determine RAG status:
   - **OK (🟢 g)** — Complete: documentation exists, process followed, deliverable signed off
   - **Partial (🟡 a)** — In progress: materials exist but pending review, partial coverage, underway
   - **Missing (🔴 r)** — Not started: no evidence of action, never received from design lead, not yet scoped
   - **N/A (⚪ n)** — Not applicable: tender not yet invited, advance orders not yet placed, etc.

4. **Build RAG-based assessment table** — Structure each item row with:
   - Ref (e.g., 4.1.1)
   - Checklist requirement name (short title)
   - Requirement description (official RIBA wording, condensed)
   - Project status (specific, actionable, with evidence)
   - RAG badge using `<span class="rag g/a/r/n">Label</span>`

5. **Generate HTML audit report** — Use the Samaya corporate template (logo-strip, meta-grid, .audit-table, .rag classes, .summary-row). Key rules:
   - Document number: `ASR-SAM-RIBA4-002` for official-checklist-based audit (002 = aligned to RIBA Job Book structure)
   - Cover sheet with summary counters (OK/Partial/Missing/N/A / Total)
   - 4-5 detail sheets with the item tables grouped by section
   - Section header rows (cat-header) with inline RAG summary spans
   - Final sheet: 4.6 BIM table + summary bar chart + priority recommendations
   - Footer on every sheet with document reference
   - Relative logo paths from the NRS package root: `../Docs/09_Registers/Key_Personnel_Register/CVs/_assets/logos/<logo>.png`

6. **Expected RAG spread** (Aseer Museum, May 2026 — typical for mid-stage D&B museum project):
   - ~17/60 OK (28%) — strongest in Design Team (4.2) and Cost (4.4)
   - ~19/60 Partial (32%) — concentrated in Client Team (4.1) and Other Activities (4.5)
   - ~22/60 Missing (37%) — heavily in Construction Team (4.3) and BIM (4.6)
   - ~2/60 N/A (3%) — items not yet triggered

### Key Assessment Patterns (Aseer Museum context)

| Section | Typical OK rate | Common gaps |
|---------|----------------|-------------|
| 4.1 Client Team | ~5/12 | Clerk of works (4.1.7), contractor interviews (4.1.8) |
| 4.2 Design Team | ~7/11 | Info exchange programme (4.2.5), specialist tenders (4.2.11) |
| 4.3 Construction Team | ~0/11 | All subcontractor/tender items (4.3.1-4.3.11) — not started if D&B |
| 4.4 Cost | ~3/4 | D&B cost check (4.4.4) |
| 4.5 Other Activities | ~4/14 | Supply visits (4.5.2), testing provisions (4.5.4), commissioning (4.5.14) |
| 4.6 BIM & Digital | ~0/8 | All items typically missing if BIM manager not formally appointed |

### Reference File

Full 60-item checklist structure with official RIBA wording and project-specific assessment notes is in:
`references/riba-stage4-checklist-audit.md`

### 📦 Consultant Drawing Package — Receipt Audit & Consolidation

### 📄 Drawing Status Tree — Rescan & Update

See `references/drawing-status-tree-update.md` for the full workflow to rescan the drawing register against the filesystem, determine real status (OK/>>/XX), and update the Aseer_Drawing_Status_Tree.html report.

**CRITICAL:** When updating an existing HTML report, DO NOT regenerate from scratch. Preserve the original design — use targeted `patch()` calls for status markers, counters, and metadata only.

When receiving a **design consultant's tender/construction drawing package** (e.g., NRS A2742 series for Aseer Museum) and asked to make it the single source of truth:

### Audit Workflow

1. **Register the baseline** — Check `01_Registers_and_Logs/` for the Drawing Register (Excel/PDF). The register is the authority: it lists every expected drawing number, revision, title, and status. If multiple versions exist (DIS-014, DIS-018, DIS-021), the **latest date-stamped version** is the authority.

2. **Map the folder** — Produce a complete file listing excluding CAD support noise:
   ```bash
   find "<PACKAGE_ROOT>" -type f -not -name '.DS_Store' \
     -not -path '*/_assets/*' -not -path '*/From_Design_Files/*' | sort
   ```

3. **Detect duplicate drawing filenames** — The most critical finding. Extract basenames, count occurrences:
   ```bash
   find "<PACKAGE_ROOT>" -type f -not -path '*/_assets/*' \
     -not -path '*/From_Design_Files/*' | sed 's|.*/||' | sort | uniq -d
   ```
   Filter results to actual drawing files (A2742-*, .dwg, .pdf) — hundreds of `.pat` and `print sheet.dwg` duplicates are normal CAD artifacts.

4. **Identify where duplicates live** — For each duplicated drawing number, map its locations:
   - `02_Approved_Stamped_Packages/*/02_CAD_Source/` — CAD sources bundled with stamped PDFs
   - `06_Drawing_Source_Folders/` — standalone source copies
   - `05_Correspondence_Archive/Deliverables to NRS/` — submitted copies by date
   - `03_Incoming_For_Review/05_Previous_and_Raw_Packages/` — raw incoming packs (now under 05_Archive)

5. **Generate a status tree** — Extract from the Drawing Register and cross-reference with actual files. Categorize each drawing as:
   - `[OK]` — Stamped PDF present in 02_Approved_Stamped_Packages
   - `[>>]` — Pending — file received but not yet stamped (only in source/archive)
   - `[XX]` — Missing — listed in register but no file found anywhere in package
   - `(!)` — Revision gap — file exists but at a different revision than the register

6. **Audit 06_Source against the register** — Drawings [OK] in the register MUST also exist in 06_Source. If an [OK] drawing is missing from 06_Source, it likely exists in `00_Stamped_CAD_Source/` and needs to be extracted to the proper discipline folder. Use this pattern:

   ```python
   # Extract drawing numbers from status tree, compare against 06_Source folder listing
   import re
   # Tree format: "[OK] A2742-1200  Rev C       Proposed Basement Plan..."
   # Source: find 06_Source -maxdepth 3 -name 'A2742-*' | extract numbers
   ```

7. **Recover missing drawings from archives** — After the initial audit, search these locations for any drawings not yet in 06_Source:
   - `05_Correspondence_Archive/Unstamped_and_Old_Revisions/` — old revision PDFs
   - `05_Correspondence_Archive/Incoming_Drawings_Archive/` — raw incoming drawings by discipline
   - `05_Correspondence_Archive/Deliverables to NRS/` — submitted copies by date
   - `05_Correspondence_Archive/05_Previous_and_Raw_Packages/` — archived raw packs
   - `06_Drawing_Source_Folders/00_Stamped_CAD_Source/` — CAD from approved stamped package

   **Moving found files:** Use `mv` (same-filesystem rename, works with OneDrive cloud files). `cp` will hang on cloud-only files. Always create the target folder first:
   ```bash
   mkdir -p "$DSF/<discipline>/A2742-XXXX"
   mv "$SRC" "$DSF/<discipline>/A2742-XXXX/"
   ```

   **What to look for:** Drawings marked [>>] in the register sometimes exist as un-stamped PDFs in the old revisions folder. These can be moved to 06_Source even though they're not stamped — 06_Source holds ALL drawing files, not just stamped ones.

8. **Final audit report** — After recovery, report:
   - How many drawings recovered (e.g., "66 additional drawings recovered from archives")
   - Which ones were truly not found anywhere (need NRS to provide)
   - Updated coverage: X of Y drawings now in 06_Source

### Common Structural Issues Found in Practice
- **CAD sources in multiple locations** — the same .dwg may appear in 3+ sections (Stamped CAD Source + Drawing Source Folder + Deliverables archive). Consolidate to ONE location.
- **Underscore folder `_/`** in 03_Incoming_For_Review containing ALL actual content while sibling numbered folders are empty. Rename to `01_Raw_Incoming_Drawings` or promote contents.
- **Old revision PDFs** mixed in `Unstamped_and_Old_Revisions/` alongside current revisions in stamped folders. Best practice: archive old revisions to a dated subfolder.
- **Empty placeholder folders** like `00_Tracking_Logs`.
- **Typo folders** (e.g., `1700_Setworks_and_Partitions` vs `1700_Setworks_Partitions`). Move content to correct folder, delete typo.
- **Wrong discipline placement** — e.g., A2742-1230..1233 (floor finishes) found in `1250_Ceiling_Details/` folder. Create `1230_Floor_Finishes/` and move them.
- **Overlapping discipline folders** (e.g., `08_Stairs_Details_Stamped` duplicates content in `01_Architectural_Stamped/1550_Stairs_Details`). Remove the duplicate.
- **1160-series in wrong folder** — demolition ceiling plans (A2742-1160..1164) often end up in `1200_General_Arrangement/`. They belong in `1100_Existing_and_Demolition/`.

### Final Canonical Folder Structure (NRS Tender Package)

The user's preferred structure for a completed tender package is exactly **5 folders** — no `03_Incoming_For_Review`:

```
Completed Tender Package From NRS/
├── 01_Registers_and_Logs/          # Drawing registers, audit reports
├── 02_Approved_Stamped_Packages/   # STAMPED PDFs ONLY (zero CAD files)
├── 04_Specifications_and_BOQ/      # Specs, BOQ, appendix PDFs
├── 05_Correspondence_Archive/      # Original NRS correspondence, raw deliveries, old revisions
└── 06_Drawing_Source_Folders/      # SINGLE source for ALL unique drawing files (CAD + source PDFs)
```

**Key rules:**
- `02_Approved_Stamped_Packages` has **zero CAD files** — stamped PDFs only. All CAD goes in `06_Drawing_Source_Folders/`.
- `05_Correspondence_Archive` holds ALL raw/original/unsorted content: NRS auto-download folders, old revisions, incoming registers, RFIs, REBA remarks, AV/Life Safety packages.
- `06_Drawing_Source_Folders` is the **complete, unique, single source** for all drawing files. No duplicates.
- There is NO `03_Incoming_For_Review` folder — the user found this confusing. Its content is split between 06_Source (drawings), 04_Specs (appendix PDFs), and 05_Archive (correspondence/raw transfers).

### Reorganization Execution Phases (Ordered)

When the user says "ok" to proceed with reorganization, execute in this order:

1. **Phase 1: Move root-level reports** — Audit files (.html/.txt/.md/.pdf) at the package root belong in `01_Registers_and_Logs/`
2. **Phase 2: Remove .bak from stamped packages** — `.bak` files in `02_Approved_Stamped_Packages/*/From_Design_Files/` are stale CAD backups. Delete them.
3. **Phase 3: Remove overlapping discipline folders** — e.g., `08_Stairs_Details_Stamped` if `01/1550_Stairs_Details` already has the same content.
4. **Phase 4: Archive typo folders** — Move typo-variant folder contents into `05_Correspondence_Archive/Unstamped_and_Old_Revisions/_Archive/` or the parent discipline folder.
5. **Phase 5: Fix discipline placements** — Move drawings to their numbered-range folders. See Drawing Number Range Map below.
6. **Phase 6: Move ALL CAD from 02_Stamped into 06_Source** — Stage as `00_Stamped_CAD_Source/` under 06_Source, then merge into proper discipline folders.
7. **Phase 7: Eliminate `03_Incoming_For_Review` entirely** — Distribute its content:
   - Unique drawing files → `06_Drawing_Source_Folders/<discipline>/`
   - Appendix PDFs, specs versions → `04_Specifications_and_BOQ/`
   - REBA remarks, RFIs, incoming registers, raw transfers → `05_Correspondence_Archive/`
   - AV Package, Life Safety (non-drawing consultancy docs) → `05_Correspondence_Archive/Incoming_Specs_and_Reports/`
   - Then delete the empty `03_Incoming_For_Review` folder
8. **Phase 8: Recover missing drawings from archives** — After initial consolidation, search all archive folders for drawings still missing from 06_Source. Move found files using `mv` (not `cp`). Report how many were recovered and which remain truly missing.
9. **Phase 9: Final audit — verify 06_Source against register** — Compare the complete 06_Source listing against the Drawing Register (DIS-021 or latest). Report:
   - Number of register drawings present vs missing
   - Breakdown by status (recovered, still missing from NRS, awaiting stamping)

   **Expected result (confirmed May 2026):** After Phase 8 recovery, ~225 of 243 drawings (92.6%) should be present in 06_Source. The 18 truly missing are: 10 [XX] existing/demolition plans (1100-1154), 2 [XX] sections (1350/1500), 5 [>>] external benches (1570-1574), 1 [>>] counter (1711, stamped PDF exists but no CAD). These require NRS to provide.

10. **Phase 10: Regenerate audit HTML** — After all reorganization is complete and the recovery audit is done, update the tree HTML to reflect the new state. Use the Samaya template. Split into multiple `.sheet` divs if the tree exceeds 80 lines (3 sheets for a 264-line tree).

    📖 **Detailed technique:** See `references/drawing-status-tree-html-generation.md` — covers HTML register parsing, filesystem scanning with drawing number normalization, cross-referencing logic, edge cases (archived-only drawings, newly-discovered files), A4 pagination, and counter consistency rules for section totals across page breaks.

**OneDrive caveat:** If files are cloud-only (not locally synced), `mv`/`cp`/`rm` operations may hang. Use `find` listing + shell metadata only; skip files that don't respond within 5s. The user can force-sync from OneDrive app.

### ⚠️ Raw Transfer / Stage Design-Files Cleanup Workflow

When the user points at a dumping-ground folder (e.g., `04_Stage04_Design_Files`) and asks why files are not distributed:

1. **DO NOT just rename or blindly delete** — the user expects content to be distributed to canonical folders.
2. **First, compare for uniqueness** — check all DWG/PDF files against `06_Drawing_Source_Folders/` (by basename). Also check against `02_Approved_Stamped_Packages/` since stamped CAD may use different revision suffixes.
3. **Distribute unique content** to the correct canonical folders:
   - Consultancy drawings (AV, Life Safety, etc.) → `05_Correspondence_Archive/Incoming_Specs_and_Reports/<descriptive_name>/`
   - Appendix PDFs (K/M series, DIS-003/005/006/012/013) → `04_Specifications_and_BOQ/02_Appendix_PDFs/`
   - Notes, remarks, comments → `05_Correspondence_Archive/REBA_Remarks/`
   - Newer-revision drawings (Rev A/B suffix not in 06_Source) → appropriate `06_Drawing_Source_Folders/<discipline>/` folder
   - Pure duplicates (older CAD dumps, NRS auto-download folders like `nissenrichardsstudio_a2742-*-dwg_*`) → delete
4. **Only then delete** — after all unique content has been placed, remove the empty/duplicate-only source folder.
5. **Tell the user what went where** — so they see the mapping (AV → Incoming, Appendices → Specs, Old CAD → deleted).

**OneDrive caveat:** If files are cloud-only (not locally synced), `mv`/`cp`/`rm` operations may hang. Use `find` listing + shell metadata only; skip files that don't respond within 5s. The user can force-sync from OneDrive app.

### Drawing Number Range Map (NRS A2742 Series for Aseer Museum)

Use this to identify correct discipline folders for drawing numbers. These are the ACTUAL folder names in `06_Drawing_Source_Folders`:

| Number Range | Discipline | 06_Source Folder |
|--------------|------------|------------------|
| 1100..1154 | Existing/Demolition Plans | `1100_Existing_and_Demolition` |
| 1160..1164 | Existing Ceiling Demolition | `1100_Existing_and_Demolition` |
| 1200..1204 | General Arrangement | `1200_General_Arrangement` |
| 1220..1223 | Wall Finishes Plans | `1200_General_Arrangement` (stored here, no separate 1220 folder) |
| 1230..1233 | Floor Finishes Plans | `1230_Floor_Finishes` |
| 1250..1253 | Ceiling Finishes Plans | `1250_Ceiling_Details` |
| 1350..1500 | Longitudinal Sections | `1100_Existing_and_Demolition` (1350) + pending folder |
| 1510..1537 | Internal Elevations | `1510_Internal_Elevations` |
| 1550..1559 | Stairs Details | `1550_Stairs_Details` (separate folder, not under 1200_GA) |
| 1570..1574 | External Details (Benches) | `1570_External_Details` |
| 1600..1601 | Washrooms/VIP WC | `1600_Washrooms_VIP` |
| 1700..1711 | Freestanding Walls/Setworks | `1700_Setworks_Partitions` |
| 1720..1799 | Setworks Details | `1700_Setworks_Partitions` |
| 1800..1820 | Showcases | `1800_Showcases` |
| 1850..1887 | Graphics & Panel Housing | `1850_Graphics_Housing` or `1860_Graphics_Housing` |
| 1890 | Painted Finishes | `1890_Painted_Finishes` |
| 1900..1909 | Floor Type Details | `1900_Finishing_and_Flooring` |
| 1910..1913 | Ceiling Type Details | `1900_Finishing_and_Flooring` |
| 1920..1926 | Wall Type Details | `1920_Wall_Type_Details` |
| 1930..1945 | Doors & Lift Linings | `1930_Doors_Lifts` |
| 1950..1961 | Door Types & Schedules | `1950_Door_Types` |

### Known Truly Missing Drawings (Aseer Museum, May 2026)

These 18 drawings are listed in DIS_021 but have NO files anywhere in the folder. They were never sent by NRS:

**12 [XX] Missing — never received:**
- A2742-1100 to 1104 (Existing Basement through Second Floor Plans — GA)
- A2742-1150 to 1154 (Existing Basement through Second Floor Plans — Demolition)
- A2742-1350 (Existing Longitudinal Section — GA)
- A2742-1500 (Proposed Longitudinal Section — GA)

**5 [>>] Pending — never received final versions:**
- A2742-1570 to 1574 (External Details — Fixed Benches)

**1 [>>] Pending — only stamped PDF exists, no CAD:**
- A2742-1711 (Counter for Manual Interactive, G4)

### Subfolder Convention (06_Drawing_Source_Folders)

Every discipline folder in `06_Drawing_Source_Folders` **must** follow this rule:

```
NNNN_Discipline_Name/
├── A2742-NNNN/              # Drawing subfolder — named by drawing number
│   ├── A2742-NNNN.dwg       # CAD source (if available)
│   └── A2742-NNNN.pdf       # Source PDF (if available)
└── A2742-NNNX/
    ├── A2742-NNNX.dwg
    └── A2742-NNNX.pdf
```

**Conventions (hard rules):**
- **No loose files** at discipline folder root — every DWG/PDF goes in an A2742-NNNN subfolder
- **No `Version N/` folders** inside discipline folders — version archives go to `05_Correspondence_Archive/Incoming_Drawings_Archive/<discipline>/`
- **No `cad/` or `pdf/` subfolders** — drawings go directly in their A2742-NNNN folder
- **Revision suffixes** are part of the folder name: `A2742-1700C`, `A2742-1706A`, etc.
- **Non-A2742 items** (Combined/, Version N/, stray files) are NOT allowed — move them to archive

### Consolidation Rules
| What | Rule |
|------|------|
| CAD sources (.dwg) | Keep in **only one** location. Recommend `06_Drawing_Source_Folders/`. Remove from Stamped Packages and Deliverables archives. |
| Stamped PDFs | Keep in `02_Approved_Stamped_Packages/<discipline>/01_PDF_Stamped/`. Remove duplicates from source folders. |
| Old revisions | Move to `05_Correspondence_Archive/Unstamped_and_Old_Revisions/_Archive/YYYY-MM-DD/` |
| .bak files | Delete — obsolete once final stamped version is confirmed. |
| Support files (.pat, .png) | Leave in `_assets/` within drawing folders — they are CAD dependencies. |
| Audit reports (.md, .html, .txt) | Move to `01_Registers_and_Logs/` — they are register-adjacent. |

### OneDrive Cloud-File Caveat

If the package lives on OneDrive, some files may be cloud-only (not locally synced). Tools like `cat`, `dd`, `cp`, Python `open()` may hang indefinitely. Workaround: work with `find` listing + shell metadata only; avoid reading file contents until confirmed synced.

**Key finding: `mv` works on same filesystem even for cloud-only files, `cp` hangs.**
- `mv` (rename on same filesystem) succeeds because no data is transferred — macOS just updates the directory entry.
- `cp` reads the file content, which triggers OneDrive to download the cloud-only data, causing a hang.
- Strategy: use `mv` to move files within OneDrive. Avoid `cp` on cloud-only files. If a copy is needed, `mv` first then note the original is gone.
- `rm` also works (removes directory entry without reading data). Use with caution.
- `ls`, `find`, `stat`, `wc` work on metadata without triggering downloads.

See `references/onedrive-cloud-file-workaround.md` for full diagnostic and recovery options.

### Existing Audit Trees
If a prior audit already exists (e.g., `Aseer_Drawing_Status_Tree.txt`), do NOT regenerate from scratch. Read it as the baseline, verify its methodology, flag additions if the folder has changed since the audit date, and note the register version it references (e.g., "Register: A2742_5.05_DIS_021 (issued 24 May 2026)").

**After reorganization:** Re-run the audit against the reorganized 06_Source to confirm recovery counts. Save the updated report as `FOLDER_AUDIT_AND_REORG_REPORT.md` at the package root — this documents what was changed and which drawings remain missing.

## 📄 Bilingual Document Standard (Saudi Govt Projects)

For documents submitted to Saudi government clients (Heritage Commission, MoC, NWC, etc.):
- **Arabic is the LEAD language** — right side, RTL. **English follows** — left side, LTR.
- `<html lang="ar" dir="rtl">`.
- **Font stack (standard):** `'Tajawal','Calibri','Carlito',sans-serif`. Google Fonts link for Tajawal.
- **Font stack (trendy/modern):** `'IBM Plex Sans Arabic','Plus Jakarta Sans',-apple-system,sans-serif` for body, `'Plus Jakarta Sans',-apple-system,sans-serif` for `.en`. Always keep Tajawal/Calibri as fallback in case the Google Font CDN is slow: `'IBM Plex Sans Arabic','Tajawal','Plus Jakarta Sans','Calibri',sans-serif`. Import via `<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&display=swap" rel="stylesheet">`.
- Each content section: Arabic first, then English. Inline English: `<span class="en" dir="ltr">text</span>`.

### ⚠️ SVG text — CSS var() does NOT work in presentation attributes

SVG `<text>` elements using `font-family="var(--f)"` will NOT resolve the CSS custom property — SVG presentation attributes are evaluated in SVG scope, not CSS scope. All SVG text falls back to the browser default serif font.

**Fix:** Define a CSS class and apply it via the `class` attribute instead:

```css
.svg-text { font-family: 'Plus Jakarta Sans', -apple-system, sans-serif; }
```

```html
<text x="50" y="18" class="svg-text">Label</text>
```

### ⚠️ Print mode overflow — browsers need `overflow: visible`

The autopaginate script handles on-screen overflow (splits tall content into new pages). But in `@media print`, the old `overflow: hidden !important` clips content. Fix in every report's `<style>`:

```css
@media print {
  .sheet {
    overflow: visible !important;    /* ← NOT hidden */
    page-break-after: always;
    break-after: page;
  }
}
```

Without this, print/PDF output silently truncates overflowing tables and blocks.

### ⚠️ Kimi file audit timeout — pipe content instead of paths

Kimi's `ReadFile` tool times out on files > ~30KB (common for bilingual HTML reports). Kimi reads the file and then the response generation exceeds the session timeout.

**Workaround:** Pipe file content directly via stdin instead of relying on Kimi's file-path tool:

```bash
cat /path/to/file.html | kimi --print 2>&1 | grep -v 'StepBegin\|ThinkPart\|TextPart\|StatusUpdate'
```

For files > 50KB, skip Kimi entirely and use Claude Code for the first audit instead.

### ⚠️ CRITICAL PITFALL — read_file() + execute_code line-number corruption

**NEVER write `read_file()["content"]` back to the same file inside `execute_code`.** The `read_file()` function returns content WITH line-number prefixes (`     N|     N|actual content`). Writing that string back corrupts the file — every line gets prefixed with garbage that renders as visible text in browsers.

**Safe patterns:**

```python
# ✅ SAFE — read raw bytes, strip prefixes, write back
import re
with open(filepath) as f:
    content = f.read()
# Strip read_file line-number prefixes
content = re.sub(r"^\s*\d+\|\s*\d+\|", "", content, flags=re.MULTILINE)
with open(filepath, "w") as f:
    f.write(content)
```

```python
# ✅ SAFE — use patch() for targeted fixes
from hermes_tools import patch
patch(path=filepath, old_string="old", new_string="new")
```

```python
# ✅ SAFE — build from scratch with write_file
from hermes_tools import write_file
html = "<!DOCTYPE html>..."
write_file(path=filepath, content=html)
```

**Symptoms of corruption:** Browser shows `     1|     1|<!DOCTYPE html>` as text at the top of every page. Fix: run a two-pass regex to strip single and double prefixes:

```bash
# Strip all "  N|" and "  N|  N|" line-start prefixes
sed -i '' 's/^[[:space:]]*[0-9]*|[[:space:]]*[0-9]*|//' file.html
sed -i '' 's/^[[:space:]]*[0-9]*|//' file.html
```

In Python:
```python
import re
with open(filepath) as f:
    content = f.read()
content = re.sub(r"^\s*\d+\|\s*\d+\|", "", content, flags=re.MULTILINE)
content = re.sub(r"^\s*\d+\|", "", content, flags=re.MULTILINE)
with open(filepath, "w") as f:
    f.write(content)
```

⚠️ **The corruption can persist across multiple writes.** After stripping, verify with `grep -c '^[[:space:]]*[0-9]*|' file.html`. If any remain, run the sed commands again. The double-prefix pattern (`N| N| content`) is the most common variant and requires the first regex; the single-prefix (`N| content`) requires the second.

## PROJECT_MEMORY.md Update Pattern

When asked to "update the project memory with all info and knowledge":

1. **Read both sources** — root `PROJECT_MEMORY.md` (dashboard/alerts style) and `Scripts/PROJECT_MEMORY.md` (comprehensive context) if both exist
2. **Scan notes/** — read email intel, meetings log, disputes summary for latest activity
3. **Check submittals dashboard** — scan the project's active submittals, RFIs, SIs for status
4. **Merge into one comprehensive file** — combine dashboard alerts with deep context. 18-section template:
   - Project Identity, Org Chain, Critical Issues, Design Workflow, Submittals Dashboard
   - Scope Breakdown, BOQ/Commercial, Exhibition Schedules, Drawing System, Registers
   - MEP/AV/Lighting, Technical Decisions, Meetings Log, Standards, Knowledge Gaps
   - File Index, Staffing Gaps, Dispute Timelines
5. **Date stamp** — `> آخر تحديث: **DD Month YYYY**`
6. **Write to root** `PROJECT_MEMORY.md` (the one humans and agents read first)

Al Faw example: `references/alfaw-pep-pattern.md` covers the report generation workflow.

### 🐍 Preferred: Python execute_code for HTML docs

| | Python execute_code | Claude Code (background) |
|---|---|---|
| Speed | ~3-5s for 80KB | 5-10 min |
| Reliability | Immune to context compaction | Lost on model switch |
| Fidelity | Exact | Needs iteration |

```python
from hermes_tools import write_file
html = """<!DOCTYPE html><html lang="ar" dir="rtl">...</html>"""
write_file(path="/path/to/output.html", content=html)
```
Use Claude Code for: complex VE lifecycle costing, risk heatmaps with P×I scores, PhD-depth analysis, and **engineering enhancement of existing HTML reports** via delegate_task.

### Engineering Enhancement Pattern (via delegate_task)
When a bilingual HTML report needs deep engineering content (structural calcs, material specs, code compliance):
1. Build the base with Python execute_code (fast, exact template)
2. Delegate the engineering pass to Claude Code via delegate_task with toolsets=[terminal, file]
3. Context: full engineering requirements, standards to reference, instruction to preserve CSS/styling
4. Claude Code reads the HTML, patches content sections with engineering depth, verifies well-formed output

### 🎯 Audit Report Pattern (11-Domain Framework)
See `references/audit-report-structure.md` for annotated HTML template. Sections in order:
1. Cover page → 2. TOC + Executive Summary → 3. Design Compliance → 4. Technical Design → 5. Regulatory & Code → 6. Risk Management → 7. Quality Management → 8. Schedule & Progress → 9. Cost & Value → 10. Documentation & Submittal → 11. UNESCO Heritage → 12. HSE & Sustainability → 13. Findings Register → 14. Conclusion.

Severity tags: `tag-fail` (Critical/blocking) · `tag-warn` (Major) · `tag-info` (Minor) · `tag-pass` (Observation)

## 📋 Project Study & Audit Workflow

When asked to study, review, or audit a project folder against requirements:

1. Read PROJECT_MEMORY.md first
2. Explore full directory tree (depth 3-4)
3. Inventory all existing documents by type and location
4. Search the PEP and key docs for the specific requirements
5. Report verdict first → evidence → gap analysis → recommended action
6. **Use clean lists for enumerated items** (objectives, findings, gaps) — not narrative paragraphs (corrected May 2026)

See `references/project-study-audit-workflow.md` for full Phase 1-3 workflow, format preferences, pitfalls, and a real example (Al Faw 12-design-objective audit).

## 👷 Mohamed Essa — Mandatory Workflow & QA Policy

### ⚠️ DO NOT SKIP THE WORKFLOW (User Correction History)

**This workflow is non-negotiable.** The user explicitly corrected the agent for skipping it (May 29, 2026 session). Every task — regardless of how small or obvious it seems — MUST go through the full pipeline below. "I'll just do this one quickly" is the exact pattern that triggers the correction.

### The Chain: User Order → Codex Rewrites → Research Phase → Claude Executes → Codex Audits → Fix → Deliver

This is the DEFAULT for every single task, not optional. Each step:

1. **Codex Rewrites the Order** — Before touching any work, send the user's request to Codex to rewrite it into a structured spec. Codex rephrases, identifies scope boundaries, and flags ambiguities.

2. **Research Phase** — Choose the appropriate depth:
   - Simple fact-check / quick lookup → **Kimi** (fast monkey work)
   - Complex multi-angle research → **delegate_task parallel** (up to 3 subagents)
   - Deep synthesis (DMP governance, ER/SOW analysis, PhD-level) → **Claude Code** (deep mode)

3. **Claude Executes** — Claude Code is the PRIMARY execution labor. All substantive work (HTML generation, deep analysis, code review, document audit, multi-sheet reports, anything requiring reasoning or creativity) goes through Claude Code.

4. **Codex Audits** — Codex audits ALL output before delivery. NOT Kimi. Codex checks:
   - HTML structural integrity (div balance, @page CSS, .sheet overflow, logo paths, no line-number corruption, Samaya template presence)
   - Content accuracy (scope tags, RAG count consistency, no placeholder text)
   - Counter consistency (sum of all statuses == total items across all summary blocks)

5. **Fix → Deliver** — Fix every finding from Codex audit. Only deliver after Codex PASS.

### Labor Assignments (explicit — do not deviate)
- **Codex** = QC rewrites orders + audits ALL output
- **Claude Code** = PRIMARY execution labor (HTML, analysis, document audit, multi-sheet reports, any reasoning/creativity)
- **Kimi** = MONKEY WORK only (quick lookups, simple research, simple/repetitive tasks — NOT QA auditor)

### CRITICAL PITFALLS
- ❌ **Do NOT skip to execution** — "this is simple, I'll just patch it directly" is what triggers the user's correction
- ❌ **Do NOT use Kimi for QA** — Kimi is monkey work. Codex audits everything
- ❌ **Do NOT skip the Research Phase** — even for familiar tasks, check for new evidence first
- ❌ **Do NOT skip Codex Rewrites** — the order must be rephrased through Codex before any execution starts
- ✅ If you are already mid-execution when the correction comes, **stop and restart** from the proper pipeline

## Technical Vendor Meeting Preparation & Attendance

When the user sends a datasheet, spec sheet, or product brochure and asks to join a vendor meeting (Teams, Zoom, etc.), follow this workflow:

### Workflow: Datasheet → Brief → Join → Monitor → Summarize

1. **Extract the datasheet** — Use `pdftotext` (macOS: `/opt/homebrew/bin/pdftotext`) to extract text from the PDF. Capture: key specs, model numbers, performance data, certifications, compatibility info.

2. **Create a meeting brief** — Save to the project's reference folder (e.g. `_References/Equipment_DataSheets/`). Include:
   - Key specifications table (parameter: value format)
   - Relevance to the project or application
   - Pre-prepared discussion points and questions for the vendor
   - Meeting access details (ID, passcode, URL)

3. **Save the datasheet** — Copy the PDF alongside the brief for future reference.

4. **Schedule attendance** — Create a single-shot cron job to join the meeting as a guest:
   - Schedule: 5 minutes before the meeting starts
   - Toolsets: `browser`, `terminal`, `file`, `vision`
   - Deliver: `origin` (back to the user's chat)
   - Prompt includes: meeting URL, passcode, guest display name

5. **Cron job joins and monitors** — The spawned session navigates to the URL, enters passcode, joins as guest, takes browser_snapshot captures, monitors presentation slides, takes notes on discussion.

6. **Deliver summary** — After the meeting (or timeout), the cron job compiles a comprehensive summary of all discussion points, decisions, commitments, and action items.

### Questions Template for Vendor Meetings

Always include these question categories:
- **Performance**: Accuracy, speed, resolution for target application
- **Compatibility**: Integration with existing software (Revit, Recap, Cyclone, etc.)
- **Environment**: How it handles site conditions (glass, reflections, dust, temperature)
- **Cost**: Purchase vs rental vs subscription; local support packages
- **Workflow**: Recommended pipeline from field capture to deliverable
- **Training**: Availability in KSA, certification required
- **Comparison**: Against competing models (which for interior vs exterior use)

### Example: Leica RTC360 Meeting (31 May 2026)
- Point cloud survey for museum as-built documentation (Aseer Museum, Zamzam)
- Focus on scan-to-BIM workflow with Cyclone FIELD 360 to REGISTER 360 to Recap to Revit
- Key question: handling reflective surfaces (glass showcases, polished stone) in museums
- Brief saved at: `_References/Equipment_DataSheets/Leica_RTC360_Meeting_Brief_2026-05-31.md`

### Pitfalls
- Teams guest join: Look for "Join as guest" or "Join anonymously" links. If none visible, the meeting may require authentication.
- Cron job timing: Schedule 5 min before start for Teams loading time.

## HTML Print-Ready Proposal Workflow

See `references/html-proposal-workflow.md` for bilingual A4 proposal building — design system, structure rules, TOC requirements, page ordering, and content specs for Samaya tender proposals.

## Document Audit

## Subcontractor RFP and Evaluation Workflow

For Aseer Museum subcontractor packages (doors, metal, showcases, AV, lighting, etc.), follow this workflow when creating an RFP and evaluating bidders:

### RFP Creation Pattern
1. Create `Subcontractors/<NN>_<Category>/RFP/` directory with `RFP-<CAT>-NNN_Description_RevA.md`
2. Use numbering: `ASM-RFP-<CAT>-NNN` (e.g., DM = Doors & Metal, SC = Showcase)
3. Include 7 standard sections: Project Overview, Scope of Work, Technical Requirements, Submission Requirements, Evaluation Criteria, Timeline, Attachments
4. Create 6 standard attachments in `Attachments/`:
   - **A** — BOQ/Schedule (scope matrix + pricing template)
   - **B** — Technical drawings reference (NRS drawing sheet list)
   - **C** — Hardware/submittal schedule (material specs)
   - **D** — Standards/compliance matrix (fire ratings, testing)
   - **E** — Contract terms & conditions
   - **F** — Performance bond sample

## 📁 Subcontractor Folder Management

Each trade subcontractor has a folder under `Subcontractors/NN_Trade_Name/` with standard subfolder structure (Schedule/BOQ, Drawings, Specs, Imagery, Submittals, RFIs, Approvals). When asked to populate or update one:

1. **Parallel search** — delegate 3 sub-agents to search project folders, email archives, and registers simultaneously
2. **Copy** all relevant files into the correct subfolders, deduplicating across sources
3. **Create STATUS_REGISTER.md** — scope summary, file inventory, open issues (RAG), deliverables progress, emails, contractor status, action items
4. **Update** PROJECT_MEMORY.md, RFI_REGISTER.md, and persistent memory

See `references/subcontractor-folder-population.md` for full step-by-step workflow including entity isolation checks.

### Entity Isolation Rule
**Zero tolerance — CRITICAL.** Samaya folders must NEVER contain Moqtana/Tqanny/Sada_Uhud/Sayyid al-Shuhada files, and vice versa. Kiswa project files belong to Tqanny not Samaya. Reference Tqanny data at OneDrive-Personal/Work/PWork/Tqanny/. SAMAYAINVESTMENT OneDrive may have cross-copied duplicates — always verify ownership before deleting/moving. If you move files wrongly, user will delete and you re-scan. When organising subcontractor files, confirm entity BEFORE any copy/move.
1. Create `SUBCONTRACTOR_EVALUATION.md` in the category folder
2. Assess each bidder on: Docs Quality, Scope Fit, Est. Capability (★ rating)
3. Include: file inventory with page counts, strengths/weaknesses, verdict per bidder
4. Priority shortlist table at top using star ratings

**Evaluation table format (use this structure):**
```
| # | Company | Specialty | Docs Quality | Scope Fit | Est. Capability | Overall |
|---|---------|-----------|:-----------:|:---------:|:---------------:|:-------:|
| 1 | Company Name | Scope | ★★★★ | ★★★★★ | ★★★★ | **Strong** |

## 1. Company Name
**Scope:** Description
**Documents:** N files (X MB total)

| File | Size | Pages | Notes |
|------|------|:-----:|-------|

**Assessment:**
- ✅ Strengths
- ⚠️ Weaknesses

**Verdict:** RECOMMENDED / CONDITIONAL / NOT RECOMMENDED
```

### BOQ quantities in RFP attachments: When the NRS MasterFormat BOQ cannot be read (OneDrive lock, slow sync), DO NOT leave Attachment A quantities as TBD. Provide preliminary estimates based on project scope (floor count, typical specs) and flag them:
```
- Preliminary estimates only — pending audit against NRS MasterFormat BOQ
- NRS BOQ file: path/to/file (mention the accessibility issue)
- Quantities to be confirmed from IFC drawings
```

### ⚠️ CRITICAL: Validate RFP Quantities Against MasterFormat BOQ

**ALWAYS extract actual BOQ quantities before estimating RFP quantities.** The NRS MasterFormat BOQ may have far fewer items than expected — and may omit entire scopes.

**Extraction technique** (OneDrive xlsx → zipfile → shared strings):
```python
import zipfile, re
z = zipfile.ZipFile("MasterFormat_BOQ.xlsx")
content = z.read('xl/sharedStrings.xml').decode('utf-8', errors='ignore')
strings = re.findall(r'<t[^>]*>([^<]+)</t>', content)
for name in z.namelist():
    if 'sheet' in name:
        sheet_content = z.read(name).decode('utf-8', errors='ignore')
```

**What to check:**
- Does the BOQ contain the scope items you're RFQing? (e.g., wood doors vs metal doors)
- What are the ACTUAL quantities? (may be 1-5 items of each type, not hundreds)
- Are there scope items that exist in your RFP but NOT in the BOQ? → scope gap, needs PMO confirmation
- Are fire-rated assemblies in the fit-out package or the base building contract?

**Session example (May 2026):** RFP estimated 235+ doors (85 fire-rated metal, 45 fire-rated wood, 65 non-rated wood, 25 exit, 15 glazed, 8 sliding). Actual NRS BOQ: 15 wood doors total. Fire-rated metal doors = NOT IN BOQ → base building scope. Result: RFP quantities were 15× the BOQ. Flagged as scope gap.

**When OneDrive is slow:** If reading the xlsx times out, tell the user "OneDrive sync required — force download" and retry after they confirm. Use `zipfile.ZipFile` directly on the xlsx path (it opens as a zip) to extract text from `xl/sharedStrings.xml`.

See `references/masterformat-boq-extraction.md` for detailed parsing patterns and column mapping.

### RFP Document Standards
- Bilingual: English primary, Arabic in parentheses for key terms
- Evaluation criteria weighted: Technical Compliance 35%, Experience 20%, Commercial 25%, Capacity 10%, Local Presence 10%
- Two-stage evaluation: Technical minimum 70% to proceed to commercial
- Evaluation automatically considers pre-qualification docs submitted

See `references/subcontractor-rfp-evaluation.md` for full workflow with templates.

## 📁 Register Update Pattern
```
1. Scan project → find ALL .xlsx/.xls files
2. Read headers to identify each file's register type
3. Extract data from project documents
4. Map data to matching columns
5. Append rows to existing files (never create new ones)
```

### 💰 Cost Comparison Workbook Audit Pattern

When auditing a cost comparison/financial workbook (not a register — these are analysis documents that CAN be rebuilt):

1. **Verify currency columns** — SAR columns often left zero while USD has values. Apply rate (USD 1 = SAR 3.75).
2. **Check totals** — Option totals (subtotal + VAT + grand total) are frequently blank or use broken formulas.
3. **Rebase action plan dates** — Timeline anchored to past LOA dates needs rewriting to current date with Week 1–8 windows.
4. **Fill missing specs** — Scanner/equipment tables often have blank resolution/accuracy cells for some models.
5. **Add missing contacts** — Distributor/vendor lists frequently omit email, phone, or website.
6. **Apply VAT** — 15% Saudi VAT warning present but not factored into totals.
7. **Deduplicate vendors** — Same distributor may appear in multiple priority tiers; clarify primary location.
8. **Cross-reference quotes** — Check actual received PDFs/quotes against estimated prices in the workbook.

See `references/aseer-scanner-procurement.md` for a real-world example (3D scanner cost comparison).

## BIM Downloads Watchdog
**Script:** `~/.hermes/scripts/bim_watchdog.py` | **Index:** `~/.hermes/scripts/bim_project_index.json` | **Log:** `~/.hermes/data/bim_watchdog_processed.json`

**2026-05-29 fix:** Added `is_valid_register()` function to handle OneDrive cloud-stub register files. When a register file is a ~6.5 KB cloud-only placeholder (not a real xlsx), the script now logs a WARNING and skips it instead of an ERROR, allowing the rest of the scan to continue.

Workflow: scan Downloads (500MB cap, allowlist) → confidence-score keyword match against 23 BIM projects → low-confidence → `_UNSORTED/` → checksum dedup → move to correct subfolder → unzip archives → dry-run `--plan`. Update project list via `bim_project_index.json` only.

For **batch sorting** (50+ files from a single source, e.g. a messy Downloads folder), use the keyword classifier reference:
`references/batch-downloads-sort-classifiers.md` — contains project-specific keyword tables, subfolder routing rules, duplicate detection logic, and edge case handling patterns.

The classifier reference is designed for Python scripts that classify and move files programmatically. Load it before writing any batch-sort script.

Additional cron: Universal Project Watchdog (proj 121 → Telegram) · BIM Sentry Mirror (OneDrive → `/Volumes/Lexar/Work_Space/Bim_Unit_Local/`)
