---
name: consultant-review-response
description: "Create new revisions of project plan documents in response to Consultant (CG) review comments — analysis, disposition table, structural edits, and resubmission tracking."
version: 1.0.0
author: Hermes Agent
---

# Consultant Review Response

Create new revisions of project management plan documents (CRP, DMP, BEP, Stakeholder Plan, QMP, HSE Plan) when Consultant/Client review returns Code B (Approved with Comments) or Code C (Revise & Resubmit).

## Workflow

### 0. Monitor CG Response Status (Pre-Response Phase)

Before a CG response arrives, when the user asks "check CG response" or "check status":

1. **Read CG_STATUS.md** (per-plan summary in `02_CG_Responses/`)
2. **Cross-reference CG_Response_Register.md** (master register at `Docs/02_Plans_and_Procedures/CG_Response_Register.md`)
3. **CHECK OUTLOOK EMAIL DIRECTLY** — do NOT rely solely on status files. They may be stale (last updated date in file header). Use:
   - **Email archive register** (`Register_ASEER_Professional.csv` in `Docs/Email Archive/مشروع متحف عسير الإقليمي/`) — definitive record of submission/reply emails with doc codes and statuses
   - **Live Outlook scan** via AppleScript or body search for the document code (e.g. `PL-0020`, `Stakeholder Management Plan`)
   - Pattern: Hesham sends submission → CG (Mohammad Elbaz) replies. If no reply email from CG exists, status is genuinely pending.
4. **If no response found**: report as "⏳ Submitted — Awaiting CG Response", note the submission date and conduit (e.g. Hesham Abdelhameed)

The user corrected: *"check outlook mail you will find"* — status files are useful summaries but Outlook email is the authoritative source for whether a CG reply has been received.

### 1. Analyze Review Comments

- Read the CG reply document (PDF/letter) and extract all comments
- Classify each comment:
  - **Structural** — requires changing document content (workflows, sequences, matrices)
  - **Administrative** — requires adding metadata, references, or compliance statements
  - **Clarification** — requires adding explanation or cross-references to existing content
- Identify which comments are already addressed by the current document version

### 2. Create New Revision

- Clone the previous revision file (e.g., `RevC01 → RevC02`)
- Update throughout:
  - Document title and header revision identifiers
  - All page headers (`CRP Rev CXX`, `DMP Rev CXX`, etc.)
  - All page footers (doc number + revision)
  - Cover page title, date, and revision badge
  - Revision history table — add new row, mark previous row with its review outcome (Code B/C)
  - TOC snapshot revision badge and date
  - Disposition chip in section headers

### 3. Add Comment Disposition Table

Insert a new section (typically §1.5 after Related Documents) on Page 03 / Document Control:

```
§1.5 CG Comment Disposition — response to CG review of [Doc Ref] ([Date])

| #  | CG Comment          | Resolution & Section Reference |
|----|---------------------|-------------------------------|
| 1  | Brief comment title | §X.X — how it was addressed   |
```

- Each row maps one CG comment to the specific section(s) that resolve it
- Add a compliance strip stating: the review outcome, date, reviewer, and that this revision addresses all comments for Code A/B resubmission

### 4. Address Structural Comments

For each comment requiring content changes:

| Comment Type | Common Edits |
|-------------|--------------|
| **Workflow sequence** | Reorder flow-row nodes in §7.x submission/submittal workflows |
| **Distribution chain** | Update recipient fields in report/matrix tables to show sequential flow (→ arrows) instead of parallel lists |
| **Missing matrix/table** | Add the required table (escalation ladder, stakeholder register, distribution matrix) |
| **Responsibility clarification** | Update RACI roles, add contractual responsibility statements |
| **Living document mechanism** | Reference existing PDCA/KPI review sections, add phase-transition language |

### 5. Update Status Tracking

- Update `CG_STATUS.md` — mark previous submission as addressed, add new submission row with ⏳ status
- Create `CRP_RevCXX_STATUS.md` (or equivalent) documenting:
  - What changed from previous rev
  - How each CG comment was addressed
  - Date and status of resubmission

### 6. File Naming Convention

```
Rev CXX:  Aseer_[PlanName]_RevCXX_Comprehensive.html
Status:   CRP_RevCXX_STATUS.md (in 03_Supplementary/)
CG Track: CG_STATUS.md (in 02_CG_Responses/)
```

## Pitfalls

- **Don't rely on CG_STATUS.md alone** — the status file may be days old. Always verify submission/reply status by checking Outlook email directly: search the email archive register CSV or run a live Outlook body search for the document code.
- **Don't miss the revision history** — document control audit trail requires every revision to be traceable. Old rows keep their status (Code C, Code B, etc.), new row is always "REVIEW"
- **Don't overflow pages** — adding a disposition table with 8 rows may push content past page bottom. Check rendered page fit; if needed, add page breaks or split into a supplementary page
- **Don't forget to mark previous rev status** — when a plan gets Code C, update the previous revision's status badge from "REVIEW" to "CODE C" so the history is accurate
- **Don't skip the compliance statement** — CG reviewers look for an explicit statement that all comments have been addressed. Add it below the disposition table
- **Preserve original layout** — use targeted patch() edits, never regenerate the full HTML. The user has corrected: "why you change the design/workflow"
- **Cover page "Issued for CG Review" label** — keep this on resubmissions unless explicitly directed otherwise

## Verification

- [ ] All "Rev C01" references replaced with "Rev C02" (or appropriate new revision)
- [ ] Zero stale revision identifiers in headers, footers, cover, TOC
- [ ] Revision history shows new row with accurate description of changes
- [ ] CG Comment Disposition table maps every comment to a specific section
- [ ] Structural changes applied to the referenced sections
- [ ] Status tracking files updated
- [ ] HTML file renders without layout breakage
