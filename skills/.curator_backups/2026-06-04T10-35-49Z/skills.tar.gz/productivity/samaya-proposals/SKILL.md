---
name: samaya-proposals
category: productivity
description: Create bilingual (AR/EN) A4 print-ready HTML tender proposals for Samaya Investment. Covers material specs (Cement Board, Jotun Epoxy, PVC Flex, LED), BOQ Excel, Surge.sh deployment, and iterative refinement via Claude Code.
triggers:
  - User asks to create/propose a tender or quotation
  - User hands you a tender brief / RFP / proposal request
  - User says "make a proposal for ..."
  - Building a print-ready HTML proposal from scratch
---

# Samaya Proposals — HTML Tender Proposal Workflow

## Design System
- **Theme:** Red accent (`#B01E2F`), dark ink (`#1F2430`), white pages
- **Fonts:** IBM Plex Sans Arabic (AR), Inter (EN), JetBrains Mono (code/data)
- **Layout:** A4 portrait (794×1123px), bilingual Arabic/English RTL
- **Print:** `@page{size:A4 portrait;margin:10mm 0}` with page-break-after
- **Screen:** responsive breakpoint at 830px, grids collapse at 600px
- **Footer:** Brand + samaya-factory.com (with QR) + page number

## Standard Proposal Structure (17 pages)
1. **Cover** — client name, location, project stats, 4 scope cards
2. **Table of Contents** — 4 categorized groups with emoji icons + anchor links
3. **Executive Summary** — company profile, key stats row, operating model
4. **Scope of Work** — detailed items table with specs (incl. gates)
5. **Capabilities** — manufacturing capabilities grid
6. **Technical Specifications** — overview table (all materials, dimensions, standards)
7. **Banner & UV Printing TDS** — PVC Flex material data sheet
8. **Cement Board 12mm TDS** — fiber cement data sheet
9. **Jotun Epoxy Mastic TDS** — coating data sheet
10. **LED Flood Light TDS** — lighting data sheet
11. **BOQ Part 1** — Steel Structure + Civil Works + Cladding
12. **BOQ Part 2** — Banner/Printing + Lighting/Electrical + Gates + Additional
13. **Implementation Methodology** — 5-phase execution plan
14. **Project Timeline** — Gantt chart with phases
15. **Company Documents & Certifications**
16. **Payment Schedule + Terms**
17. **Signature Page**

### TOC Category Structure
```
Project Introduction · مقدمة المشروع    📋 Cover, 📊 Executive Summary
Technical Scope · النطاق الفني           🔧 Scope, 📐 Specs, 💡 Lighting, 📦 BOQ
Execution Plan · خطة التنفيذ            📅 Timeline
Company & Commercial · الشركة            🏢 Team, 💰 Payment, ⚖️ Terms, ✍️ Signature
```

### Anchor Links Pattern
- Every `<section class="page">` gets `id="page-N"` (sequential 1-17)
- Cover uses `<section class="page cover" id="page-1">` — note the `cover` class + id together
- TOC items wrap content in `<a href="#page-N" style="text-decoration:none;color:inherit">` — preserves visual style
- Verify no double-quote bugs: `id="page-1""` is WRONG, should be `id="page-1"`
- **After ANY structural change (add/remove/reorder pages), run this verification checklist:**
  - [ ] Page IDs are sequential (1 to total_pages) with no gaps
  - [ ] Footer page numbers match their section's ID number
  - [ ] Footer total "/N" matches the actual total page count
  - [ ] Every TOC `href="#page-N"` points to an existing section
  - [ ] TOC page numbers match actual footer page numbers
  - [ ] Cover's `PAGE 01 / N` matches total page count

### A4 Height Constraint Enforcement
- `.page` has `min-height:1123px` on desktop + `overflow:hidden` — this clips anything exceeding A4
- **Flex blowout prevention:** ALL children with `flex:1` MUST also have `min-height:0` — otherwise flex items can grow past the container
- **Images inside flex containers:** use `height:100%` + `object-fit:contain` (NOT `height:auto`) — this makes the image scale to the container, not its natural dimensions
- When splitting space between elements, use `flex-shrink:0` on header/footer bars so they don't compress, and `flex:1;min-height:0` on content that should fill remaining space

### TOC Update Rule (MANDATORY)
- **Every time ANY page is added, removed, or reordered:** update TOC immediately
- Update: item descriptions, page numbers, href targets, category groupings
- Verify: every TOC page number matches actual footer page number
- Verify: every `href="#page-N"` points to an existing `id="page-N"` on a `<section>`

### Loaded Pricing (OH&P Markup)
The Excel BOQ should have two sheets:
1. **"Option C - BOQ"** — base unit rates (direct cost)
2. **"Option C - BOQ (Loaded)"** — rates with OH&P built in:
   - Supervision / Preliminaries: 8%
   - Overhead (G&A): 10%
   - Profit Margin: 12%
   - **Total Loading Factor: 1.30×**
- The HTML BOQ should use LOADED prices, not base rates
- Add a note below the Grand Summary table showing the loading breakdown

### BOQ Consolidation Pattern
- All BOQ content should fit on pages 12-13 (2 pages max)
- **Must match the Excel exactly** — 8 sections, not 6:
  1. **SECTION 01 — STEEL STRUCTURE · الهيكل المعدني** (Item 01)
  2. **SECTION 02 — CIVIL WORKS · الأعمال المدنية** (Item 02)
  3. **SECTION 03 — CLADDING & FINISH · الكسوة والتشطيب** (Items 03-04)
  4. **SECTION 04 — BANNER & PRINTING · البانر والطباعة** (Item 05)
  5. **SECTION 05 — LIGHTING · الإضاءة** (Item 06)
  6. **SECTION 06 — ELECTRICAL WORKS · أعمال الكهرباء والتمديدات** (Items 07-08)
  7. **SECTION 07 — DOORS & GATES · الأبواب والبوابات** (Items 09-10)
  8. **SECTION 08 — ADDITIONAL & SAFETY · أعمال إضافية وسلامة** (Items 11-12)
- **Item numbering: sequential 01-12 across ALL sections** (not per-section restart)
- **Grand Summary table: 8 rows** matching the sections above, with correct subtotals
- Page 17 = Payment Terms + Terms & Conditions + Signature (NO BOQ on page 17)
- The Excel may have Section 08 items (Mobilization + Safety signage) distributed pro-rata into all other items. When this happens, Section 08 is removed and each item's rate is adjusted upward by a small factor (~0.85%). The unit rates become fractional (e.g., 111.44 instead of 110.50). Update ALL rates from the loaded sheet when this occurs.

### BOQ Data Sync from Excel (openpyxl)
When the user updates the Excel file and says "update from Excel":
1. Read `BOQ_Pricing_Model.xlsx` with `openpyxl` + `data_only=True` from the `Option C - BOQ (Loaded)` sheet
2. Extract every row: item #, description, unit, qty, rate, total
3. Compare each value against the current HTML BOQ tables on pages 12-13
4. Patch every discrepancy individually using `patch()` with the exact `class="price">OLD_RATE</td>` pattern
5. Update the Grand Summary table rows (section subtotals, excl. and incl. VAT per section)
6. Update the grand total, VAT, and total incl. VAT footer rows
7. Check for stale values on earlier pages (cover page scope card shows rate/m², executive summary shows total project value)
8. The user may also restructure sections — if Section 08 items (Mobilization + Safety signage) get distributed pro-rata into all other items, remove Section 08 entirely and adjust each item's rate upward by ~0.85% (distribution factor = 28,480 / 3,338,788.80 ~ 0.00853). Verify the grand total stays the same.
8. The user may also restructure sections — if Section 08 items (Mobilization + Safety signage) get distributed pro-rata into all other items, remove Section 08 entirely and adjust each item's rate upward by ~0.85% (distribution factor = 28,480 / 3,338,788.80 ~ 0.00853). Verify the grand total stays the same.

### Default Quantities (Fence Projects)
- **Fence length:** 1,426 m (perimeter)
- **Height:** 8 m
- **Banner/cladding area:** 11,408 m²
- **Column spacing:** 3 m (NOT 4m — user corrected this)
- **Columns/footings:** floor((length − gate_width) / spacing) + 1 (e.g., (1426−7.2)/3 = 474)
- **Footing spec:** Precast RC isolated footing 2.75×1.50×0.60m, Fcu 300, complete with anchor bolts, reinforcement cage, lifting inserts — delivered & levelled on prepared bed
- **LED lights:** depends on spacing — at 12m: ~118 units; at 2m (Excel): ~711 pcs. **Always check the Excel QUANTITY INPUTS section for Light spacing value.**
- **Gate deductions:** Vehicle gate 6m + Pedestrian gate 1.2m = 7.2m total. Deduct from effective fence length before calculating columns AND lights
- **Distribution panels:** 1 per ~150m = ~10 panels
- **Effective fence length (after gates):** 1,426 − 7.2 = 1,418.8m

### Quantity Recalculation Pattern
When spacing changes (e.g., 4m → 3m), update ALL dependent items:
1. Columns count → footings, base plates, anchor bolts, numbering paint
2. Bolts count → columns × 8 bolts per column
3. LED lights → recalculate from effective length / 12m
4. Update HTML stat boxes, spec tables, BOQ items, methodology/timeline references
5. Update BOQ_Pricing_Model.xlsx formulas automatically
- **Cladding:** Cement Board 12mm (fiber cement, A1 fire rated) as rigid substrate
- **Banner:** PVC Frontlit Flex 440-510 gsm with UV digital printing 1440 dpi
- **Coating:** Jotun Epoxy Mastic (≥200µm DFT) — NO galvanizing unless client demands it
- **Steel:** HSS sections per structural calculation (do NOT specify exact profile in proposal)
- **Lighting:** LED Flood Light 300W IP66 5000K, spaced ~12m, adjust for gates
- **Gates:** Vehicle gate 6m×8m + Pedestrian gate 1.2m×2.1m (deduct from light count)
- **Foundation:** RC footings 1.2×1.2×0.9m K-300, above-ground

## Workflow

### Phase 1 — Research & Reference
1. Read `Obekan.pdf` for banner material TDS if present
2. Read `PROJECT.md`, `BOQ.md`, `Technical_Specification.md` for existing specs
3. Identify client name and location from user input or documents

### Phase 2 — Build HTML Proposal
1. Start from existing Print_Ready template if available, or build new
2. **Delegate visual design to Claude Code** (the user expects this)
3. Use patch() operations — never rewrite entire file
4. Follow the 17-page structure above
5. Add `id="page-N"` to every section for anchor linking
6. TOC must have category groups with emoji icons and clickable `href="#page-N"` links

### Phase 3 — Material Rules
- **Cement Board 12mm** is the default cladding (NOT ACP or bare banner)
- PVC Flex banner is MOUNTED ON the cement board surface
- Jotun Epoxy Mastic is default coating — never mention galvanizing
- Steel profile is "حسب التصميم الإنشائي / per structural calculation" — never specify HSS 200×200×8
- LED count: start at 120, subtract 1 fixture per ~12m of gate openings
- Gates break the fence — no banner/cladding on gates

### Phase 4 — BOQ Excel
1. Create `BOQ_Pricing_Model.xlsx` using Python (openpyxl)
2. 3 sheets: BOQ (with formulas), Pricing Summary, Notes
3. Sections: Steel Structure, Civil Works, Cement Board, Banner & Printing, Lighting & Electrical, Gates, Additional
4. Leave unit rates empty for user to fill
5. Auto-calculating totals with formulas
6. See `references/BOQ-structure.md` for full item list and formula pattern

### Phase 5 — Deploy
1. Copy `index.html` + `proposal_assets/` + `assets/` + `Obekan.pdf` to `/tmp/surge-full/`
2. Deploy: `surge /tmp/surge-full/ <domain>.surge.sh`
3. Domain convention: `<project-name>.surge.sh` (e.g., `al-zaidi-parking.surge.sh`)
4. Always deploy from /tmp, NOT from OneDrive path (OneDrive causes Surge to fail)
5. After deploy, wait **10-30 seconds** for CDN propagation, then verify with `curl -s -o /dev/null -w "%{http_code}" https://<domain>.surge.sh` — expect 200
6. If HTTP 404 or 504 is returned on first check, it's CDN propagation — wait 10s and retry. If it persists, redeploy.
7. Verify assets: `curl -s -o /dev/null -w "%{http_code}" https://<domain>.surge.sh/proposal_assets/logo.png` for each asset type

### Phase 6 — SVG Project Timeline
When creating/redesigning the timeline Gantt chart, use inline SVG:
- **viewBox:** 820×250 (provides enough room for Arabic labels + 12 week columns + legend)
- **Label column:** left panel at x=0 to x=210 with light gray `#F9FAFB` background + separator line
- **Arabic labels:** use `text-anchor="end"` anchored at x=204 with `direction="rtl"` and `unicode-bidi="embed"` — this prevents overflow/hidden text
- **⚠️ Text clipping fix:** WITHOUT `direction="rtl"` + `unicode-bidi="embed"`, Arabic SVG text renders in document-order (left-to-right) and overflows the viewBox boundary on the left side. Adding these two attributes makes Arabic render right-to-left from the anchor point, keeping it fully visible. This was discovered after 3 redesign iterations — do not skip it.
- **Week spacing:** 50px per week (W0 at x=210, W12 at x=810)
- **Bar height:** 20px with `rx="4"` rounded corners + drop shadow filter
- **Gradients:** define `<linearGradient>` for each color category (prep=gray, steel=red, civil=amber, electrical=teal)
- **Legend:** at y=240, compact 4 items with 8px color swatches
- **Height constraint:** 250px total — leaves room for note paragraph + spec boxes below on the same page
- **Bar colors:** prep=`#374151`/gray, exec=`#B01E2F`/red, civ=`#D97706`/amber, elec=`#0D9488`/teal

### Page Overflow & Balancing
When pages overflow A4 or are visually unbalanced:
1. **Measure content lines** per page — find `<!-- PAGE N -->` and `<!-- PAGE N+1 -->` comments, count non-empty, non-comment lines between them
2. **Compact CSS first** — reduce padding, font-size, line-height on the overflowing page's table/card classes before moving content:
   - `.ds-table th/td` → `padding:2px`, `font-size:10px`
   - `.doc-card` → `padding:8px`, `min-height:68px`
   - `.pay` → `padding:5px`, `font-size:10px`
   - `.terms li` → `padding:7px 0`, `font-size:9px`
3. **Move content between pages** as a second resort — shift doc cards, summary bars, or signature blocks to balance line counts (target ~120-150 content lines per page)
4. **Remove Section 08 from BOQ** if items were distributed pro-rata — update Grand Summary to 7 rows
5. **Always update TOC + page numbering** after moving content between pages
- Page 6 table too loose? Target these CSS selectors:
  - `.spec-table td` → `padding:2px 8px` (was 5px 12px)
  - `.ds-table td` → `padding:4px 10px` (was 9px 12px — biggest gain)
  - `.gantt-row` → `padding:6px 14px`, `.gantt-track` → `height:20px`
  - `.pay` → `padding:12px 14px`, `.pay .nm` → `margin-top:6px`
  - `.tds-stat` → `padding:6px 10px`
  - `.phase` → `padding:10px 12px`
  - `.terms li` → `padding:10px 0`
  - `.sign-card` → `padding:16px 18px 20px`
  - `.gantt-legend` → `padding:8px 14px`
  - Reduce `.ds-table .grp td` padding too (3px 10px)

## Structural Reorganization Audit (ADD/REMOVE/MOVE pages)
When you add, remove, or reorder a page, you MUST update ALL of these or navigation breaks:
1. `id="page-N"` attributes on `<section>` tags
2. Footer `Page <b>N</b> / Total` spans  
3. Footer `/Total` denominator (e.g., `/16` → `/17`)
4. TOC `href="#page-N"` targets (every anchor link)
5. TOC page number labels (`toc-page">N</span>`)
6. Section `<!-- PAGE N — TITLE -->` comments
7. Cover `PAGE 01 / N` text
8. `data-screen-label` attributes if page content changed
9. **The easiest mistake is updating 6 out of 9** — always run a verification script:
   ```python
   # Check for gaps/mismatches
   ids = set(re.findall(r'id="page-(\d+)"', content))
   footers = set(re.findall(r'Page <b>(\d+)</b> / (\d+)', content))  
   print(f"IDs: {sorted(ids, key=int)}")
   print(f"Footers: {sorted(footers)}")
   print(f"Total pages: {len(ids)}")
   ```

## CDN Propagation Delay
After `surge` deployment, the CDN edge nodes take **10-30 seconds** to refresh. During this window:
- HTTP 404 = old domain cache cleared, new deploy not propagated yet → wait 10s, retry
- HTTP 504 = CDN timeout → wait 10s, retry  
- After 30s, always 200 if deploy succeeded
- To verify quickly: `curl -s -o /dev/null -w "%{http_code}" https://domain.surge.sh`
- Do NOT redeploy unless 404 persists beyond 60s

## Cover Page in Print
- **Do NOT hide** `.cover-wrap::before` in `@media print` — keep a solid gradient so the cover has full-page background
- Add these in the print block:
  ```css
  .cover-wrap::before{background:linear-gradient(180deg,#F6F8FC,#EDEEF2)!important;display:block!important;content:""!important}
  .page.cover{padding:0!important}
  .cover-wrap{min-height:1123px!important}
  ```
- Regular page decorative gradients SHOULD be hidden: `.page::before{display:none!important}`

## Sign-Off Blocks Layout
- Both signature blocks (Client + Contractor) should display **side-by-side** on the last page
- Wrap both in a flex container: `<div style="display:flex;gap:16px">` — the `.sign` CSS already has `grid-template-columns:1fr 1fr` but the inner content uses `sign-card`, so the outer structure is `flex` with gap
- Remove `margin-top:16px` from `.sign` CSS when using a flex wrapper — the wrapper handles spacing
- Order: Client signature on the left, Contractor signature on the right

## Sign-Off Integrity Audit (pages 16-18)
When splitting content between the last 3 pages, orphaned `<div>` tags cause broken rendering:

### Page 16 orphan pattern
After moving signature blocks off page 16, a fragmented `sign-line` + `sign-fields` block may remain between the doc-sum closing `</div>` and the footer. This causes 2 extra `</div>` closes (opens=116, closes=118). Fix:
```python
# Find the doc-sum end
sr = page16.find('جميع الوثائق الرسمية سارية المفعول')
sr_close = page16.find('</div>', sr)
doc_sum_close = page16.find('</div>', sr_close + 6)
footer = page16.find('footer class="pf"')
new = page16[:doc_sum_close+6] + page16[footer:]
```
Then add the missing deck container close before `</body>`:
```python
body_end = content.rfind('</body>')
content = content[:body_end] + '</div>' + content[body_end:]
```

### Per-page div verification
```python
for pg in range(1, 20):
    m = f'PAGE {pg} —'
    nm = f'PAGE {pg+1} —' if pg < 18 else 'TWEAKS PANEL'
    s = content.find(m)
    if s < 0: continue
    e = content.find(nm, s) if pg < 18 else len(content)
    sec = content[s:e]
    o = len(re.findall(r'<div\\b', sec))
    c = len(re.findall(r'</div>', sec))
    if o != c: print(f'Page {pg}: {o}/{c} diff={o-c}')
```
A single stray `<div class="deck">` at the file start needs `</div>` added before `</body>`. The overall file has `<div class="deck">` before page 1 but the closing is often missing. Always check deck balance.

## openpyxl Excel Reading (data_only=True)
When reading the BOQ_Pricing_Model.xlsx, ALWAYS use `data_only=True` in `load_workbook()` — otherwise cells with formulas return `None` instead of computed values:
```python
wb = load_workbook(path, data_only=True)
ws = wb['Option C - BOQ (Loaded)']
```
Without this flag, `.value` on formula cells returns `None` and all BOQ sync attempts silently produce empty values.

## Content Balancing Between Pages 16-17
When doc cards overflow page 16 or payment/terms overflow page 17:
1. First compact CSS (reduce padding, font-size on `.doc-card`, `.pay`, `.terms`)
2. Move doc cards from page 16 to page 17 (or vice versa) — keep doc-sum + available-on-request card with the doc cards (same topical group)
3. The closing block (وتفضلوا بقبول فائق التحية والاحترام) belongs on the LAST page BEFORE signatures
4. After ANY move, run the div balance verification above

## Pitfalls
- **Do NOT rewrite entire HTML files** — use patch() for targeted edits
- **Do NOT use branch for Surge credentials** — login via `surge login` interactively or use saved token
- **Do NOT specify exact HSS profiles** — leave to structural calculation
- **Do NOT mention galvanizing** — use Jotun Epoxy Mastic
- **Do NOT hardcode "3 مشاريع متزامنة"** — use flexible phrasing like "قدرة تنفيذ مشاريع متزامنة — إدارة مرنة للجداول"
- **Do NOT split Technical Specs from Material Datasheets** in the TOC — they are one section
- **Do NOT put Lighting in Execution Plan TOC category** — it's a technical spec sheet under Technical Scope
- **Do NOT deploy from OneDrive path** — copy to `/tmp/surge-full/` first (OneDrive causes Surge failures)
- **Always fix double-quote bugs** in id attributes: `id="page-1""` → `id="page-1"` (automated scripts often introduce these)
- Cover page uses `<section class="page cover">` — not same pattern as regular pages. When adding id, ensure `class="page cover"` is preserved, not split into `class="page" cover"`
- **Cover background in print:** do NOT hide `.cover-wrap::before` in `@media print` — give it a solid gradient instead (`background:linear-gradient(180deg,#F6F8FC,#EDEEF2)`). Also add `.page.cover{padding:0}` and `.cover-wrap{min-height:1123px}` in the print block so the cover fills the full printed page.
- **After adding/removing/reordering a page, audit ALL of these or navigation breaks:** `id="page-N"` attributes, footer page numbers, footer `/total` denominator, TOC `href="#page-N"` targets, TOC page number labels, section `<!-- PAGE N -->` comments, and the cover `PAGE 01 / N` text. The easiest mistake is updating 5 out of 6 and leaving one stale link.
- **LED count varies hugely by spacing:** 12m spacing = ~118 units, 2m spacing = ~711 units. Always check the Excel QUANTITY INPUTS section for the exact spacing value before assuming. When in doubt, ask the user.
- **Section 08 distribution creates fractional rates:** When Mobilization + Signage (28,480 SAR) is distributed pro-rata, rates become fractional (e.g., 111.44 instead of 110.50). The Grand Summary must be updated to 7 rows (remove Section 08). The grand total stays the same.
- **When moving content between pages 16-17, verify tag integrity:** Orphaned `<div class="sign">` without matching `</div>` causes floating/flush content. After any page remixing, verify: every `<div class="sign">` has a matching `</div>`, every signature card is properly wrapped, and the closing block has its correct ending. Use `grep -n '</div>' | grep 'sign'` to spot-check.
- **`doc-sum` and `Available on Request` cards belong with doc cards:** If doc cards move to page 16, move these too. They are topically related (documentation appendix) and keeping them together avoids contextually orphaned content.

### Sign-Off Verification (Last Page Integrity)

After any split or move involving pages 16-18, run these checks:

```python
# 1. Unique closing block
assert content.count("وتفضلوا بقبول") == 1

# 2. Client + Contractor signatures each exactly once
assert content.count("الطرف الأول") == 1
assert content.count("الطرف الثاني") == 1

# 3. Overall div balance
import re
opens = len(re.findall(r'<div\b', content))
closes = len(re.findall(r'</div>', content))
print(f"{'OK' if opens==closes else 'BROKEN'} - {opens}/{closes}")

# 4. Page-level div balance
for pg in range(1, 20):
    marker = f'PAGE {pg} --'
    start = content.find(marker)
    if start < 0: continue
    next_marker = f'PAGE {pg+1} --'
    end = content.find(next_marker, start)
    if end < 0: end = len(content)
    sec = content[start:end]
    o = len(re.findall(r'<div\b', sec))
    c = len(re.findall(r'</div>', sec))
    if o != c:
        print(f"  Page {pg}: {o}/{c} diff={o-c}")
```

The classic -2 imbalance on page 16 means stray sign-line/sign-fields fragments survived the content move. Fix by finding and removing the orphaned block between the doc-sum closing div and the footer.

### Last Page Structure (after split)

When the last page overflows, split into Payment+Warranty (page 17) and General Conditions+Sign-Off (page 18):

Page 18 order:
1. General Conditions list
2. `<div class="rule">` separator
3. Closing block ("وتفضلوا بقبول فائق التحية والاحترام")
4. `<div class="rule">` separator
5. Client signature card (الطرف الأول)
6. Contractor signature card (الطرف الثاني)

Rules:
- Closing block goes BEFORE signatures (on same page)
- Client signature before Contractor signature
- Each signature is its own `<div class="sign">` - do not nest
- Page 16 must NOT contain any signature or closing content
- Verify: `content.count("الطرف الأول") == 1` and `content.count("وتفضلوا بقبول") == 1`

## CSS Compaction (Targeted Overrides Block)

When the user says "compact all tables and charts" or "fix spacing across all pages":

**DO NOT** modify individual CSS declarations one-by-one — this takes 15+ patch calls and risks missing elements.

**DO** add a single dense CSS overrides block at the end of the `<style>` block, wrapped in `@media screen` with `!important`:

```css
@media screen{
  /* BOQ tables */
  .boq td,.boq th{padding:4px!important;font-size:10px!important}
  .boq tfoot td{padding:5px!important}
  .boq-group{margin-bottom:8px!important}
  /* Spec tables */
  .spec-table td,.spec-table th{padding:1px 8px!important;font-size:11px!important}
  /* Data sheets */
  .ds-table td{padding:2px!important;font-size:10px!important}
  /* Gantt/timeline */
  .gantt-track{height:14px!important}
  .gantt-row{padding:6px!important}
  /* Payment cards */
  .pay{padding:6px!important}
  .pay .pct{font-size:28px!important}
  /* Doc cards */
  .doc-card{padding:6px!important;min-height:70px!important}
  .docs-grid{gap:6px!important}
  /* Stats */
  .stat{padding:8px!important}
  .spec-box{padding:6px!important}
  /* Page gutters */
  .page{padding:40px 48px 56px!important}
  /* Section spacing */
  .sec-kicker{margin-bottom:4px!important}
  .sec-sub{margin-top:10px!important}
  /* Timeline milestones (p15-* classes) */
  .p15-card{padding:6px!important}
  .p15-item{padding-bottom:8px!important;min-height:50px!important}
}
```

**Benefits:** One operation, preserves `@media print` styles entirely, easy to revert, and catches all instances of each class across the entire file.

## Large HTML File Redesign Strategy

Files >150KB or >2500 lines timed out Claude Code delegation (600s limit). Strategy:

### Option A — CSS-only redesign (preferred, ~50% success)
Replace the `<style>` block in the `<head>` with new CSS while keeping all HTML content identical. This is much faster (~150K tokens vs ~400K for full rebuild) and the subagent is more likely to complete.

### Option B — Split into shell + content
1. Create structural shell first: `write_file` with 18 page sections, headers, footers, CSS, and placeholder content
2. Fill content per page group: delegate content-fill in batches of 4-5 pages
3. If content-fill file corruption occurs (0 bytes), revert to the working source file and try Option A instead

### Option C — Phase by page group
Delegate one group of related pages at a time:
- Group 1: Cover + TOC + Executive Summary (pages 1-3)
- Group 2: Scope + Capabilities + Specs (pages 4-6)
- Group 3: Datasheets + Drawings (pages 7-10)
- Group 4: BOQ (pages 11-12)  
- Group 5: Methodology + Timeline (pages 13-14)
- Group 6: Docs + Payment + Terms + Sign-off (pages 15-18)

## Post-Delegation Verification Checklist

After any subagent modifies a multi-page HTML file (even one page), verify ALL of these before reporting done:

```python
# 1. Page count
assert len(re.findall(r'<section class=\"page', content)) == 18  # or expected count
# 2. Section balance
assert content.count('<section') == 18
assert content.count('</section>') == 18
# 3. Style block balance
assert content.count('<style>') == content.count('</style>')
# 4. Footer page numbers (check sample)
# 5. Page heights via browser_console (should not exceed 1123px)
# 6. CSS selector scoping — new styles should not leak into other pages
```

## BOQ Loaded Sheet EXACT Match Rule

When the user says "match Option C - BOQ (Loaded) exact no more no less":

The BOQ must reproduce the Loaded sheet **exactly as-is**, including:
- **Section headers**: SECTION 01 — STEEL STRUCTURE · الهيكل المعدني (which is bold uppercase in Excel)
- **Item descriptions**: Full bilingual text verbatim from Excel (not shortened)
- **Loaded rates**: Use the exact loaded rate values (e.g., 111.44, not 85 base rate)
- **No OH&P lines in grand summary**: The loaded sheet shows only 3 summary rows — Grand Total excl VAT, VAT 15%, Total incl VAT. No separate Supervision/Overhead/Profit rows.
- **OH&P as info note only**: Add a compact note below the grand summary: "OH&P Loading: Supervision 8% + Overhead 10% + Profit 12% = Factor 1.30" — but do NOT include in the pricing table
- **Quantity Inputs**: Add as a compact info table at bottom of BOQ page 13 — 8 rows showing all dimension inputs
- **All 10 items (01-10)**: The loaded sheet has exactly 10 items numbered 01-10 across 7 sections. No additional items.
- **No Section 08**: If the loaded sheet distributes mobilization/signage pro-rata, remove Section 08 entirely and verify grand total unchanged

**Verification commands:**
```bash
python3 -c "
import openpyxl
wb = openpyxl.load_workbook('BOQ_Pricing_Model.xlsx', data_only=True)
ws = wb['Option C - BOQ (Loaded)']
# Check grand total
print(f'Grand Total: {ws[\"F35\"].value}')
print(f'VAT: {ws[\"F37\"].value}')
print(f'Total: {ws[\"F38\"].value}')
"
```

Then compare every item's qty, rate, and total from Excel against the HTML. All must match.
