---
name: project-deliverable-audit
description: "Audit project deliverables (drawings, documents) against filesystem by extracting register entries, scanning files, cross-referencing, and updating HTML status reports with targeted patches — never full regeneration."
version: 2.0.0
author: Hermes Agent
platforms: [macos]
metadata:
  hermes:
    tags: [BIM, Drawing-Register, Audit, HTML-Report, Samaya]
    related_skills: [bim-project-register, project-register-manager]
---

# Project Deliverable Audit — Drawing Status & File Tree

Audit a project's deliverables (drawings, documents) against actual files on disk and update HTML status reports. Used for the Aseer Museum Drawing Status Tree and similar deliverable-tracking HTML reports.

See `references/drawing-scan-methodology.md` for detailed scan methodology, naming conventions, regex patterns, and cross-reference logic.

## 🔴 CARDINAL RULE: NEVER Regenerate — Always Patch

**Do NOT regenerate HTML reports from scratch.** The user's design, layout, and workflow must be preserved. Always:

1. Read the existing HTML file
2. Make **targeted text replacements** via Python `str.replace()` or `patch()` tool
3. Only change status markers, counters, and dates — never restructure

The user's exact words: *"why you change the design/workflow"* — this means preserve every line of the original design.

## Workflow

### Step 1: Read the Existing Report

```python
# Decode HTML entities
html_d = html.replace("&gt;", ">").replace("&lt;", "<")
# Extract all drawing entries
entries = re.findall(
    r'<span class="mk (ok|pn|xx)">\[(OK|>>|XX)\]</span>\s+(A2742[\-A]+\d+)',
    html_d
)
```

### Step 2: Scan Filesystem for Actual Files

Search these locations in priority order:
1. **`02_Approved_Stamped_Packages/`** — NRS-stamped PDFs
2. **`06_Drawing_Source_Folders/`** — active PDF/DWG files per section
3. **`00_Stamped_CAD_Source/`** — DWG files with stamp/approval
4. **`05_Correspondence_Archive/`** — old revisions (only if user directs)

Use `find` or Python `subprocess.run()` for bulk enumeration. **Do not delegate to labor agents** — they timeout on 500+ file scans.

### Step 3: Cross-Reference Register vs Filesystem

Status priority:
- **Stamped PDF** → `[OK]` (approved by NRS)
- **Active PDF/DWG in source folder** → `[>>]` (pending review)
- **DWG in Stamped CAD Source** → `[>>]`
- **Only in Correspondence Archive** → check with user first
- **No file anywhere** → `[XX]`

### Step 4: Apply Targeted Patches

**Option A — Python bulk replace:**
```python
with open(path) as f: html = f.read()
for dn in changed_entries:
    html = html.replace(
        f'<span class="mk xx">[XX]</span> {dn}',
        f'<span class="mk pn">[&gt;&gt;]</span> {dn}',
        1
    )
with open(path, "w") as f: f.write(html)
```

**Option B — `patch()` tool** for unique replacements:
```
patch(path=path, old_string=old, new_string=new)
```

### Step 5: Update All Counters in One Pass

1. **Summary counters** — Stamped [OK], Pending [>>], Missing [XX] totals
2. **Section headers** — per-discipline counts (e.g., `>>:58 XX:20` → `>>:78`)
3. **Revision number** — `Rev N` → `Rev N+1`
4. **Date** — update to today

Critical: the counter row is one continuous HTML line (no line breaks). Match the exact string.

### Step 6: Add Newly Discovered Drawings

If new drawings exist on filesystem but not in the register:
- Add entries at the end of their section using the correct format
- Update the section header count
- Match existing prefix format exactly: `├── <span class="mk pn">[>>]</span>`

### Step 7: Copy Files to Proper Source Folder

When drawings are found in archive/old revisions, copy to the active folder:
```bash
cp OLD_REV_PATH/A2742-XXXX.pdf \
   06_Drawing_Source_Folders/XXXX_Section_Name/
cp -R OLD_REV_PATH/A2742-XXXX/ \
   06_Drawing_Source_Folders/XXXX_Section_Name/A2742-XXXX/
```

## CSS Fix for Tree View (Prevent Title Wrapping)

Long titles wrap in `<pre>` blocks with `white-space: pre-wrap`. Fix:
```
.tree-box{...white-space:pre;overflow-x:hidden;font-size:7pt;...}
```
Change `pre-wrap` → `pre` and reduce font slightly if needed.

## ⚠️ CRITICAL: Verify Design Stage via DMP Before Any Conclusion

**Before making ANY claim about what stage drawings are at (DD, IFC, AFC), ALWAYS read the DMP (Design Management Plan) first.** The DMP defines the stage breakdown the contract omits:

| Stage | What | LOD | Status in Aseer |
|-------|------|-----|-----------------|
| **Stage 4-A** | Design Development (DD) | LOD 300-350 | **DELIVERED** — 251 drawings |
| Stage 4-B | IFC Construction Package | LOD 350-400 | **NOT STARTED** |
| Stage 5 | Off-site Fabrication Review | LOD 400 | Partially started (premature) |
| Stage 5-6 | On-site Review | LOD 400-500 | Future |

**The contract may label deliverables "IFC Package" but the DMP clarifies they are actually DD (Stage 4-A).** The user explicitly corrected this — get it right on the first pass by reading the DMP. DMP path: `Docs/02_Plans_and_Procedures/02.1_DMP/01_Source_Files/HTML/aser_museum_dmp_RevC03_NRS_Lead.html`

## Cross-Document Verification Protocol

**Never trust a single source document.** Before reporting conclusions on scope, payment, or status, cross-reference ALL of these:

1. **NRS Contract DOCX** — fee breakdown, scope, payment terms (Art. 4, 5, 10, 11)
2. **DMP** — design stage definitions, workflow, LOD matrix
3. **Drawing Register** — actual drawings delivered vs expected
4. **SOW Responsibility Matrix PDF** — who creates/reviews what (appendices A-D)
5. **Invoices (PDF)** — what was billed, when, for which stage
6. **Bank Receipts** — what was actually paid vs invoiced

When documents conflict (e.g. contract says "IFC" but DMP says "DD"), the DMP is authoritative for design stage; the contract is authoritative for payment terms.

## Phase 3 — Contract DOCX Extraction & Analysis

### DOCX Table Extraction
```python
from docx import Document
doc = Document(path)
text = "\n".join([p.text for p in doc.paragraphs])
for table in doc.tables:
    for row in table.rows:
        cells = [cell.text.strip() for cell in row.cells]
```
Search for fee/amount: `re.search(r'\d+[,.]?\d*\s*(SAR|EUR|£|\€)', text)`

### Image-Based PDF Fallback
- Try `fitz` → `page.get_text()` → if empty, it's image-based
- Try tesseract OCR; if fails, note as "image-based, manual review"
- Extract images via `page.get_images(full=True)` → `doc.extract_image(xref)` for manual inspection

### Key NRS Contract Data (for reference)
**⚠️ Stage 4 in the contract is labelled "IFC Package" but is actually Stage 4-A DD (LOD 300-350) per the DMP. Stage 4-B IFC (LOD 350-400) has not started.**

| Field | Value |
|-------|-------|
| Total Fee | SAR 1,209,000 |
| Stage 4 (per contract: "IFC Package" — actually **Stage 4-A DD**) | SAR 768,000 (63.5%) — 8 weeks |
| Stage 5 Off-site Review | SAR 270,000 (22.3%) — 3 months |
| Stages 5-6 On-site Review | SAR 171,000 (14.2%) — 4 months |
| Updated Visuals (optional) | SAR 75,000 |
| Resource total | 211 person-days, 7 roles |
| Advance Payment (10%) | SAR 120,900 |
| Payment Terms | 14 days after invoice (Art. 11.3) |
| Review Turnaround | 3 Working Days (Art. 5.5) |
| Penalty Cap | 10% of total fee (Art. 21) |

### NRS Contract Appendices
- **A** — Scope Matrix (responsibility matrix)
- **B** — Resource & Cost Schedule — **prevails for deliverables**
- **C** — Contractor's SoW (back-to-back)
- **D** — Employee requirements

## Phase 4 — Payment vs Deliverable Tracking

When a responsibility matrix or SOW document is available, cross-reference the register against contractual scope:

### NRS Contract Pattern (Parts A-D)

| Part | NRS Obligation | Action |
|------|---------------|--------|
| **A** | NRS Creates (IFC package) | Verify all scope elements have register entries. Flag gaps (e.g. "roof terrace sunshade" with no drawing number) |
| **B** | NRS Reviews/Approves/Stamps (Samaya creates) | List 22+ disciplines needing NRS stamp. Add subcontractor column showing who's responsible (BCG, Glasbau Hahn, ZNA 3297, OfficeDog, Samaya in-house, etc.) |
| **C** | Other Obligations | Meeting attendance, ≤72hr review period, material updates |
| **D** | Exclusions | Items NOT in NRS scope (MEP, structure, BIM, life safety) |

Report each part in a separate table with columns: #, Element, Register Ref, Status, Notes.

## Phase 4 — Payment vs Deliverable Tracking

When invoices/payment data is available, add payment cross-reference:

### Data Sources
- **Annex 4 (Payment Schedule)** — from main contract, lists bundles with % and SAR. May be image-based — use contract reference docs or manual extraction
- **Invoices** — from subcontractor (NRS, etc.). May be scanned PDFs — try OCR, note failures
- **Bank transfer receipts** — confirm actual payment amounts and dates

### Report Structure
1. **Payment schedule table** — Bundle #, Name, Est. %, Est. SAR, Contract Due, Actual Paid, Variance, Status
2. **Invoice tracking** — Invoice ref, Date, Amount, Paid Date, Status (PAID / DUE / FUTURE)
3. **Timeline mismatch analysis** — flag when subcontractor bills next stage before previous stage is complete
4. **Cumulative profile** — contract due vs actual delivery progress (gap %)

### Key columns for payment tracking table
# | Bundle | % | Est. SAR | Contract Due | Actual Paid | Variance | Status | RAG

### Pitfalls — Payment Tracking
- Main contract total (MoC to Samaya) does not equal subcontract total (Samaya to NRS). Keep separate
- Annex 4 percentages are % of Sub-table A (86.96% of total), not % of full contract. Add Sub-table B (13.04%) separately
- Bundle % estimates from reference documents may be approximate — verify against actual signed contract
- Scanned invoices may fail OCR — flag as "image-based, manual review needed"
- 14-day payment terms are common — calculate due dates from invoice date

### Earned Value Management (EVM) S-Curve

After building the payment vs deliverable tables, create an EVM S-curve to visualise schedule and cost performance. See `references/evm-analysis.md` for full methodology.

**Data points needed for each period (month):**
- **PV (Planned Value)** — cumulative planned fee from the fee schedule
- **EV (Earned Value)** — value of deliverables actually completed (% complete × budgeted fee for that stage)
- **AC (Actual Cost)** — cumulative payments made to the subcontractor

**Key metrics at the reporting date:**
| Metric | Formula | Interpretation |
|--------|---------|---------------|
| Schedule Variance (SV) | EV − PV | Negative = behind schedule |
| Cost Variance (CV) | EV − AC | Positive = under budget (paid less than earned) |
| SPI | EV ÷ PV | < 1.0 = behind schedule |
| CPI | EV ÷ AC | > 1.0 = under budget |

**SVG S-curve coordinate math (when embedding in a dark-themed HTML report):**
```
y = max_y - (value_in_K / scale_factor)

Where:
  max_y = 352          # Y-axis baseline at bottom of chart area
  scale_factor = 4     # SAR 1,000 = 1 SVG pixel

Example: EV = 384K → y = 352 − (384 / 4) = 352 − 96 = 256
```

**Critical: Subagent QC catches coordinate errors.** When creating the initial SVG yourself, delegate to Claude Code for verification — subagents recalculate every coordinate and catch mismatches between stated values (e.g. "PV at Jun = 614K") and pixel positions. Do not assume your hand-calculated coordinates are correct.

**S-curve construction rules:**
- All three curves (PV, EV, AC) share the same Y-axis scale
- PV curve follows a logistic/S-shape (slow start → rapid ramp → plateau at contract value)
- EV curve lags PV when behind schedule (vertically below PV at any X)
- Mark TODAY with a vertical dashed line at the current month
- Show SV arrow (from EV to PV) and CV arrow (from EV to AC) at TODAY line

## Phase 5 — HTML Chart Embedding

For charts (payment timeline, progress bars):

### SVGs
- Use inline <svg> directly in HTML — <object> and <img> tags fail with local file paths due to browser security
- Set sheet to landscape: <div class="sheet" style="width:297mm;min-height:210mm;">
- Make SVGs standalone and self-contained (no external CSS/JS dependencies)

### Table column widths
- Set explicit style="width:XX%" on each <th>
- Sum must equal 100% across columns
- Test with longest likely text — adjust if text wraps
- Common layout: #(4%), Discipline(22%), Subcontractor(14%), Element(20%), Action(18%), Status(10%), Notes(12%)

## Aseer Museum Section Mapping

| Drawing Range | Section Header | Source Folder |
|---|---|---|
| 1100-1164 | 00 — Existing & Demolition Plans | 1100_Existing_and_Demolition |
| 1200-1204 | 1200 — General Arrangement | 1200_General_Arrangement |
| 1220-1223 | 1220 — Wall Finishes Plans | — |
| 1230-1233 | 1230 — Floor Finishes Plans | 1230_Floor_Finishes |
| 1250-1253 | 1250 — Ceiling Finishes Plans | 1250_Ceiling_Details |
| 1350-1500 | 1350/1500 — Sections | 1350_Sections |
| 1510-1537 | 1510 — Internal Elevations | 1510_Internal_Elevations |
| 1550-1559 | 1550 — Stairs Details | 1550_Stairs_Details |
| 1570-1578 | 1570 — External Details (Benches) | 1570_External_Details |
| 1600-1601 | 1600 — Washrooms / VIP WC | 1600_Washrooms_VIP |
| 1700-1711 | 1700 — Freestanding Walls | 1700_Setworks_Partitions |
| 1720-1799 | 1720 — Setworks Details | 1700_Setworks_Partitions |
| 1800-1820 | 1800 — Showcases | 1800_Showcases |
| 1850-1887 | 1850 — Graphics & Panel Housing | 1850/1860_Graphics_Housing |
| 1890 | 1890 — Painted Finishes | 1890_Painted_Finishes |
| 1900-1909 | 1900 — Floor Type Details | 1900_Finishing_and_Flooring |
| 1910-1913 | 1910 — Ceiling Type Details | — |
| 1920-1926 | 1920 — Wall Type Details | 1920_Wall_Type_Details |
| 1930-1945 | 1930 — Doors & Lift Linings | 1930_Doors_Lifts |
| 1950-1961 | 1950 — Door Types & Schedules | 1950_Door_Types |

## Pitfalls

### ⚠️ Always Read the DMP Before Claiming a Design Stage
The contract may say "IFC Package" but the DMP defines the real stage split (Stage 4-A DD vs Stage 4-B IFC). Never assume. The user corrected this explicitly: the 251 drawings are DD, not IFC.

### ⚠️ Cross-Reference All 6 Source Documents
Contract DOCX, DMP, drawing register, SOW matrix, invoices, bank receipts — need all six before a reliable conclusion. If one contradicts another, explain the discrepancy.

### ⚠️ Detect Premature Stage Billing
When a subcontractor invoices for the next stage (e.g. Stage 5 Off-site) before the current stage (Stage 4-A DD) is complete and stamped, flag it explicitly. This is a workflow risk the user needs visibility on.

### ⚠️ Don't Regenerate HTML
User explicitly corrected this. Always patch the existing file. Regeneration loses styling, layout, and workflow differences.

### ⚠️ A2742-A-XXXX vs A2742-XXXX
Existing/demolition drawings use `A2742-A-XXXX` naming but the register lists them as `A2742-XXXX`. Scan must account for both.

### ⚠️ Section Counts Must Be Total Across All Sheets
When a section spans multiple tree sheets, show the TOTAL for that section, not the per-sheet subtotal.

### ⚠️ Counter Row Is a Single HTML Line
No line breaks. Must match exact text including whitespace.

### ⚠️ Remove Section Header Suffix When Items Change Status
After moving all entries from [XX] to [>>], remove the `XX:N` suffix entirely. Don't leave `XX:0`.
