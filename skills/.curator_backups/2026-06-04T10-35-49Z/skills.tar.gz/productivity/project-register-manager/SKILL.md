---
name: project-register-manager
description: Manage BIM project Excel registers by appending data to existing files. NEVER create new files — only find existing xlsx files and add rows. Use MD file caching (.pdf.md sidecars) to avoid rescanning.
version: 2.0.0
author: Hermes Agent
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [bim, registers, excel, project-management, document-control, md-cache]
    related_skills: [samaya-technical-office]
---

# Project Register Manager

## 🔴 CARDINAL RULES (NEVER VIOLATE)

1. **NEVER create new Excel files** — only update existing ones by appending rows
2. Always scan the project for existing `.xlsx`/`.xls` files first — all subdirectories
3. Find the best-matching existing file by filename + column headers
4. Append rows at the bottom of the data sheet — **never** overwrite or restructure
5. Preserve ALL existing formatting, formulas, styles, merged cells, and structure
6. Only if absolutely zero Excel files exist for a register type, then ask the user before creating
7. Registers MUST have: Cover page (project info + revision history) + styled data sheet (dark blue headers, alternating rows, auto-filter, frozen panes)
8. Use format: `_Register.xlsx` suffix (not `_Log.xlsx` or bare name)

### Per-Register Column Templates (use exactly)
10. **Scan first, labor second** — use direct Python file-system scanning (`os.walk`) for enumeration tasks; reserve labor agents (Claude/Kimi) only for content analysis and decision-making on register entries
11. **Only update the exact register the user specifies** — do NOT auto-update sibling/related registers. If the user says "update ASM_Master_Material_Submittal_Register with X", only update that one file. Do not also update Material Sample Register, BOQ files, or other registers alongside it unless the user explicitly lists them. The user tracks specific registers only, and updating extra ones wastes their review time.

## Workflow

### Step 0: Plan → Audit → Implement
Before scanning a project or creating registers:
1. Read the project index (`bim_project_index.json`) to understand what exists
2. Audit the project's existing Excel files first
3. Proceed only after understanding the full picture

### Step 1: Find Existing Excel Files
---
file: original_filename.pdf
type: Submittal
date: 2026-05-28
project: Aseer Museum
code: ASR-SAM-KP-CV-PACK-SITE-001
subject: "description"
parties: [Samaya, CG, MoC]
revision: Rev 01
status: Submitted
checksum: md5_first64kb
---
Summary paragraph here...
```

## Workflow

### Step 1: Find Existing Excel Files
Scan ALL subdirectories for `.xlsx`/`.xls`/`.xlsb` files.
Match by filename keywords to determine register type.

**NEVER create new files — only append to existing ones.**

### Step 2: Read Project Files (Use Kimi CLI)
For reading/scanning project files and extracting data for registers, use **Kimi CLI**:
```
kimi -p "Scan all files in [project] and extract [data type] for [register type]" -y --afk --quiet
```
Kimi is faster and cheaper for file scanning than Claude Code.

### Step 3: Append to Existing Registers
For each existing Excel file:
1. Open with openpyxl (read-only mode to check structure)
2. Read headers from the data sheet
3. Map extracted data to matching columns
4. Append rows at the end (after last row with data)
5. Save preserving formatting

### Step 4: MD Sidecar Caching
When a labor analyzes a file:
1. Extract metadata (type, code, date, parties, subject)
2. Compute checksum (MD5 of first 64KB)
3. Write `.pdf.md` sidecar with YAML frontmatter + summary
4. If `.pdf.md` already exists with matching checksum → skip

## Excel Notes
- Use `openpyxl` for .xlsx files
- `.xlsb` files — do NOT modify (openpyxl incompatible)
- Always write to temp file first, then atomic rename
- Check if file is open in Excel before writing
- Preserve ALL existing formatting
- **Append rows only** — never create new sheets or files

## Related Skills
- `samaya-technical-office` — project context, folder structure, document conventions
- `project-initializer` — for greenfield projects needing full folder scaffolding

## Key Lessons

### El-Ghamama Gift Shop 2 (May 2026)
- **Deduplicate immediately** on every append — collect all existing IDs first, skip any new entry whose ID already exists
- **Path prefix consistency** — if existing entries use `04_Design_Files/...`, new entries must match exactly; `Design Files/...` is a different path and creates duplicate entries for the same file
- **Cover sheet + data sheet** — registers have two sheets: `Cover` (project metadata, revision history) and the data sheet
- **Auto-filter** on the data sheet aids usability
- **`Submittal's` vs `Submittals`** — some projects use `Submittal's` (apostrophe). Always use the exact subfolder name found in the project
- **Labor CLIs for file enumeration are slow and timeout** — use direct `os.walk` Python for scanning 500+ files; reserve Claude/Kimi for content analysis and decision-making only
- **openpyxl lives on system Python 3.13** (`python3`), not the venv — use `terminal(python3 -c "...")` not `execute_code` for openpyxl operations

### Aseer Museum — NRS Showcase Routing (May 28, 2026)
- **NRS (Nissen Richards Studio) showcase submittals go to `Subcontractors/01_Showcase_Contractor/`**, NOT `Submittals/Showcases/From NSR/`
- When filing NRS submittals, invoices, and M&E docs: `Subcontractors/01_Showcase_Contractor/Submittal_NN_date/` or `Subcontractors/01_Showcase_Contractor/Lighting_*.pdf`
- Always confirm the correct subfolder with the project's existing folder structure before filing
- After filing: append to `Register_ASEER_Professional.csv` (path: `.../Email Archive/مشروع متحف عسير الإقليمي/`)

### Communication Rule (ALL tasks — no exceptions)
- **ALWAYS report task completion to Mohamed Essa** for every task, including terminal/CLI commands
- Do NOT say "ok done" or bare acknowledgments — state specifically what was done, what changed, and any issues
- This applies to: file copies, moves, conversions, PDF extractions, register updates, email operations, everything

### Mohamed Essa — Register Tracking Preference (June 2026)
- Mohamed ONLY tracks/maintains **ASM_Master_Material_Submittal_Register** for QC/Equipment items
- **Do NOT** update other material/sample registers (Material Sample Register, MSR, BOQ Materials Register, etc.) alongside it unless explicitly asked
- If the user says "i only follow on this :ASM..." — that is a correction. Stop immediately and revert/undo changes to other registers
- For Aseer Museum specifically: the `09_Registers/` copy and the `03_Submittals/03.3_Material_Submittals/` copy of ASM_Master_Material_Submittal_Register have DIFFERENT column structures. Always check which version the user is referring to before updating

## Pitfalls

### openpyxl not available in execute_code sandbox
`execute_code` sandbox does NOT have `openpyxl` — it will raise `ModuleNotFoundError`. Use `terminal(python3 -c "...")` instead, pointing to the system Python 3.13 which has openpyxl installed.

### openpyxl sheet discovery
Many register files have multiple sheets (e.g., `['Cover', 'Drawing']`). The data lives in the **second sheet**, not the first (`Cover`). Always call `wb.sheetnames` first, then pick the right sheet.

### Duplicate IDs on re-run
When re-running register updates, the same entries get appended again with duplicate IDs (e.g., `DWG-005` appearing twice). **Always de-duplicate before appending** — check existing IDs in the sheet and skip entries already present.

### OneDrive sync-lock on .xlsb files
OneDrive's sync engine holds exclusive file locks on `.xlsb` files — direct `dd`/`cp` reads fail with `Resource deadlock avoided`. The file cannot be copied or read directly while open in OneDrive.
- **Workaround**: Ask the user to open the `.xlsb` in Excel and Save As `.xlsx` to Desktop (or a local path), then operate on the copy
- **Alternative**: Ask the user to Share the file via Telegram directly, which bypasses OneDrive's lock

### OneDrive cloud stubs cause "File is not a zip file" on .xlsx registers

OneDrive "Files On-Demand" placeholders (~6.5 KB, `com.apple.FinderInfo` xattr present but `com.apple.provenance` MISSING) are NOT real xlsx files. `openpyxl.load_workbook()` fails with "File is not a zip file" because the local file is just a cloud stub — the actual content was never downloaded.

**Detection** — check if the file is a valid ZIP before opening with openpyxl:
```python
import zipfile
def is_valid_register(path):
    if not os.path.exists(path):
        return False
    try:
        with zipfile.ZipFile(path) as z:
            return len(z.filelist) > 0
    except Exception:
        return False
```

**Symptoms:**
- All register files in a project's `Docs/09_Registers/` are exactly ~6-7 KB
- `xattr` shows `com.apple.FinderInfo` only (no `com.apple.provenance`)
- `file` command reports "Microsoft Excel 2007+" but the file isn't a real ZIP
- Attempting `dd`/`cp`/`cat` on the file gives "Resource deadlock avoided"

**Fix:** Open the register files manually in Excel (triggers OneDrive to download the real content), or mark the `Docs/09_Registers/` folder as "Always keep on this device" in OneDrive settings.

**Script fix:** Add `is_valid_register()` check before every `openpyxl.load_workbook()` call. This is what `bim_watchdog.py` now does — it skips with a WARNING when a stub is detected, so the rest of the scan can continue.

### Labor CLI timeouts
Claude Code and Kimi CLI both timeout on complex file scanning tasks when max-turns is insufficient. For **file enumeration** (listing, counting, scanning), use direct `os.walk` Python instead of delegating to a labor agent. Reserve labor agents for **content analysis and decision-making** only.
