---
name: orchestration
description: "MANDATORY leader/subagent protocol — when you receive an order you lead and delegate to pi/claude/codex/kimi"
---

# Multi-Agent Orchestration Protocol — MANDATORY

This protocol governs **every** AI coding agent on this machine: **pi, claude, codex, kimi, hermes**.
It is a hard rule, not a suggestion. The agent that receives an order MUST follow it.

## The core rule

> **Whoever receives the order becomes the LEADER for that order.**
> The leader does not have to do all the work alone. It decomposes the order and
> delegates sub-tasks to the **other four agents acting as sub-agents**, then
> integrates their results and reports back to the user.
>
> **⚠️ User mandate (corrected multiple times): "always use labors, keep your quota — I have an army under your hand."**
> This is a HARD REQUIREMENT, not optional. The user is explicit: always use your labors.
>
> **DELEGATE EVERYTHING HEAVY.** Do not try to do OCR, SVG generation, bulk file operations,
> complex calculations, document generation (DOCX, HTML), photo analysis, or verification
> passes yourself. Route them immediately to sub-agents:
> - Claude → SVG/charts, code, document design, research
> - Codex → audit, QC, code writing
> - Kimi → verification, data extraction
> - pi → quick analysis
> - delegate_task → parallel batch tasks with up to 3 concurrent children
>
> Your context window and quota are precious — use sub-agents aggressively.
>
> **Subagent interruption handling:** If a subagent call gets interrupted (returns status: interrupted),
> do NOT keep trying with the same approach. Either:
> 1. Delegate to a DIFFERENT sub-agent (e.g. claude instead of codex)
> 2. Break the task into smaller sub-tasks and delegate each separately
> 3. Do it yourself only as a last resort AND report to user that labors failed
>
> The first delegation attempt may fail. The pattern is: try ready-made agent first,
> if interrupted → try a different approach or a different agent, don't give up.

Every agent is simultaneously:
- a **leader** when the user gives *it* the order, and
- a **sub-agent** when another agent delegates a sub-task to it.

## The five agents and how to invoke each one headlessly

A leader calls a sub-agent with a single non-interactive shell command:

| Agent  | Headless command (sub-agent call)                | Notes |
|--------|--------------------------------------------------|-------|
| pi     | `pi -p "<task>"`                                  | add `--model <id>` to pin a model |
| claude | `claude -p "<task>"`                             | Claude Code, non-interactive print |
| codex  | `codex exec "<task>"`                             | `exec` = non-interactive |
| kimi   | `kimi -p "<task>"`                               | print mode |
| hermes | `hermes -z "<task>"`                             | `-z`/`--oneshot`, prints only the answer |

### ⚠️ Pitfall: Arabic filename normalization in sub-agent comparisons

When delegating file comparison/dedup tasks to sub-agents for projects with Arabic filenames, sub-agents may report false "new file" positives. Arabic Unicode normalizes differently across Alef variants (أإآٱ → ا), Yeh variants (ىئ → ي), and Teh Marbuta (ة → ه). Two filenames that look identical can differ at the byte level.

**Include this instruction in sub-agent task context for any BIM/Saudi project file comparison:**

> Normalize Arabic filenames before comparison: `unicodedata.normalize('NFC', name).lower()`, map Alef variants to base `ا`, Yeh variants to base `ي`, strip diacritics (U+064B–U+0652). Use `difflib.SequenceMatcher` with ratio > 0.9 for files with `_1`, `_2` suffixes.

**Confirmed:** 2026-06-10, Codex sub-agent flagged 4 Aseer Museum files as "new" that were already in BIM — all were Arabic Unicode variant mismatches + insufficient BIM tree search scope.

The leader runs these via its own terminal/bash tool, captures stdout, and incorporates it.

## How a leader should decompose an order

1. **Acknowledge as leader.** State: "I received this order, so I am leading it."
2. **Plan.** Break the order into independent sub-tasks.
3. **Delegate by strength** (see capability map below). Prefer running independent
   sub-tasks in parallel (background shell jobs) and collecting results.
4. **Integrate.** Merge sub-agent outputs; resolve conflicts; de-duplicate.
5. **Verify.** Have at least one *other* agent QA the result before delivering
   (cross-agent check — never self-certify a large deliverable).
6. **Report.** Give the user the final result + a one-line note of who did what.

## Per-user fixed assignments (override capability map)

Some users have explicit sub-agent role assignments that must take priority over the
general capability map below. When the user says something like "plan with X, do with Y,
Z is QC", that IS the assignment for the session — follow it literally, do not re-debate.

Known fixed assignments by user:

| User | Planner | Executor | QC / Reviewer |
|------|---------|----------|---------------|
| **Mohamed Essa** (Samaya) | **Codex** (`codex exec`) | **Claude Code** (`claude -p`) | **Kimi** (`kimi -p`) |

Trigger: user says "plan with codex, do with claude, KIMI is QC" or similar fixed-role delegation.
When active: Codex writes a structured plan → Claude reads it and builds → Kimi validates output.

## Capability map — delegate to the strongest agent for the job

| Sub-task type                              | Best sub-agent(s)        |
|--------------------------------------------|--------------------------|
| Odoo / ERP (XML-RPC, POs, invoices)        | any — all share the `odoo` skill; helper at `odoo_connect.py` |
| Heavy code generation / refactor           | claude, codex            |
| HTML/print/A4 deliverables, design         | claude (frontend skills), hermes (`html-print-layout`) |
| **SVG chart creation**                     | **claude** (subagent) — delegate all EVM S-curve, payment chart, and infographic SVG work |
| **OCR / document extraction**              | **codex** or **kimi** — use fitz + tesseract, never do it yourself |
| **Payment reconciliation**                 | **codex** — scan folder → OCR all PDFs → detect duplicates → build ledger |
| **Report rewriting (bulk)**                | **claude** or **codex** — delegate table rewrites, language updates, cross-sheet patching |
| QA / audit / cross-check                   | kimi (`hermes-quality-assurance`), claude |
| BIM / Samaya project-office tasks          | hermes, kimi (BIM skills) |
| Research / web                             | claude, codex            |
| macOS / local automation                   | hermes, kimi             |

## Guardrails (still apply under delegation)

- **No recursion storms.** A sub-agent given a task executes it directly; it does
  NOT re-delegate the same task back out. Delegation is one level deep per order
  unless the leader explicitly splits further distinct sub-tasks.
- **Destructive/outward actions** (writes to Odoo, file deletion, sending mail,
  git push) require the same confirmation rules each agent already follows. The
  leader is responsible for not fanning out an unconfirmed destructive action.
- **Secrets** stay in local env files; never pass credentials in a sub-agent prompt.
- **Timeouts.** If a sub-agent call hangs, the leader proceeds with the others and
  notes the gap rather than blocking forever.
- **Entity isolation** (Samaya ↔ Moqtana/Tqanny/Sada_Uhud) is never crossed without
  explicit user confirmation.

## One-line summary to embed in each agent

> When you receive an order you are the LEADER: decompose it and delegate sub-tasks to
> the other agents (pi `-p`, claude `-p`, codex `exec`, kimi `-p`, hermes `-z`),
> integrate their results, have another agent verify, then report.
