---
name: outlook-email
description: Search Microsoft Outlook emails via SQLite database on macOS and extract attachments using AppleScript.
tags:
  - outlook
  - email
  - sqlite
  - applescript
  - attachments
  - macos
---

# Outlook Email Management on macOS

Search, filter, and extract attachments from Microsoft Outlook on macOS using its local SQLite database and AppleScript automation.

## Trigger

User asks to find emails from a specific sender, search for project-related emails, or extract attachments from Outlook.

## Database Location

```
~/Library/Group Containers/UBF8T346G9.Office/Outlook/Outlook 15 Profiles/Main Profile/Data/Outlook.sqlite
```

Only one account (sultan@samayainvest.com) — no account filtering needed.

## Key Tables & Columns

### Mail table

| Column | Type | Description |
|--------|------|-------------|
| `Record_RecordID` | INTEGER | Unique email ID (use with AppleScript `message id`) |
| `Message_SenderList` | TEXT | Display name of sender |
| `Message_SenderAddressList` | TEXT | Email address of sender |
| `Message_NormalizedSubject` | TEXT | Email subject line |
| `Message_TimeReceived` | INTEGER | Unix timestamp (use `datetime(col, 'unixepoch')`) |
| `Message_HasAttachment` | BOOLEAN | 1 = has attachments, 0 = no attachments |
| `PathToDataFile` | TEXT | Relative path to `.olk15Message` file (proprietary — use AppleScript instead) |

### Useful query patterns

```sql
-- Find by sender
SELECT Record_RecordID, datetime(Message_TimeReceived, 'unixepoch') as received,
       Message_NormalizedSubject, Message_HasAttachment
FROM Mail
WHERE Message_SenderAddressList LIKE '%email@domain.com%'
ORDER BY Message_TimeReceived DESC;

-- Today's emails (local timezone)
SELECT Record_RecordID, datetime(Message_TimeReceived, 'unixepoch') as received,
       Message_NormalizedSubject, Message_HasAttachment
FROM Mail
WHERE date(Message_TimeReceived, 'unixepoch') = date('now', 'localtime')
ORDER BY Message_TimeReceived ASC;

-- Filter by attachment only
... AND Message_HasAttachment = 1

-- Filter by subject keywords (Arabic or English)
... AND Message_NormalizedSubject LIKE '%متجر%' OR Message_NormalizedSubject LIKE '%project%'

-- Combined: project doc codes + attachments
SELECT Record_RecordID, datetime(Message_TimeReceived, 'unixepoch'),
       Message_SenderList, Message_NormalizedSubject
FROM Mail
WHERE Message_NormalizedSubject LIKE '%MOC-MUS-ASE%'
  AND Message_HasAttachment = 1
ORDER BY Message_TimeReceived DESC;

-- Get columns
PRAGMA table_info(Mail);
```

### Workflow: search before concluding

When investigating **why a project folder exists** (e.g. a Plans & Procedures sub-folder like `02.17_Risk_Management_Plan`):
1. First search Outlook by subject keyword (`Risk Management`, `خطة إدارة المخاطر`, doc code, etc.)
2. Then search by sender (e.g. CG consultants: `hmabrouk@cg.com.sa`, `Hesham.a@samayainvest.com`)
3. Only then conclude "no matching attachments exist" — the user created the folder because they received relevant documents on email.

## Extracting Attachments — AppleScript

Outlook stores attachments inside proprietary `.olk15Message` files. The only reliable extraction method is AppleScript.

### Key technique: `touch` before `save`

AppleScript's `POSIX file path as alias` requires the destination file to **already exist**. Create it first with `touch`:

```applescript
set savePath to "/path/to/destination/filename.xlsx"
do shell script "touch " & quoted form of savePath
set saveFile to POSIX file savePath as alias
save att in saveFile
```

### Working with message IDs

The `Record_RecordID` from SQLite maps directly to AppleScript's `message id`:

```applescript
tell application "Microsoft Outlook"
    set theMsg to message id 34500
    set msgSubject to subject of theMsg
    set atts to (every attachment of theMsg)

    repeat with att in atts
        set attName to name of att
        -- save logic here
    end repeat
end tell
```

### Checking attachment types

```applescript
set attName to name of att
set attType to content type of att
set attSize to file size of att
```

### Full extraction script template

```applescript
set baseFolder to "/path/to/output/folder/"
do shell script "mkdir -p " & quoted form of baseFolder

tell application "Microsoft Outlook"
    set emailIds to {34500, 33140}
    set savedCount to 0

    repeat with eid in emailIds
        set eidVal to (eid as integer)
        try
            set theMsg to message id eidVal
            set atts to (every attachment of theMsg)

            repeat with att in atts
                set attName to name of att
                set savePath to baseFolder & eidVal & "_" & attName
                do shell script "touch " & quoted form of savePath
                set saveFile to POSIX file savePath as alias
                save att in saveFile
                set savedCount to savedCount + 1
            end repeat
        end try
    end repeat
    return "Saved: " & savedCount & " files"
end tell
```

### Filtering images vs documents

Most emails include signature images. To extract only non-image attachments:

```applescript
set attType to content type of att
if attType does not start with "image/" then
    -- save document
end if
```

| Content type | Classification |
|---|---|
| `image/jpeg`, `image/png`, `image/gif` | Inline signature/email images — usually skip |
| `application/pdf` | Document — save |
| `application/vnd.ms-excel` | Excel (.xls) — save |
| `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` | Excel (.xlsx) — save |
| `application/vnd.openxmlformats-officedocument.wordprocessingml.document` | Word (.docx) — save |

### Email Reading (no attachments)

For emails without attachments:

```applescript
tell application "Microsoft Outlook"
    set theMsg to message id 12345
    set msgProps to properties of theMsg
    return msgProps  -- gives headers, html, plain text content
end tell
```

## Post-extraction: routing to project folders

After downloading attachments to a staging folder (`/tmp/outlook-attachments/<project>/`), route each file to its correct project path. Use Python (via `execute_code`) to handle Arabic names and special characters in paths — bash quoting of these paths is fragile.

### Route by project mapping

```python
import shutil, os

# Define a mapping: filename → relative-subfolder
map = {
    "MOC-MUS-ASE-1KH-PL-0055.pdf": "Docs/02_Plans_and_Procedures",
    "ZAM-NWC-CTR-CLR-MEP-004_Rev.00.pdf": "Docs",
}

staging = "/tmp/outlook-attachments/aseer"
project_root = "/path/to/Aseer-Museum"

for fname, subdir in map.items():
    src = os.path.join(staging, fname)
    dst = os.path.join(project_root, subdir, fname)
    if os.path.exists(src):
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)
```

### Categorize by doc code prefix

| Prefix | Project |
|--------|---------|
| `MOC-MUS-ASE` | Aseer Museum |
| `ZAM-NWC` or `ZAM-` | Zamzam Visitor Center |
| `AL JALAL`, `JALAL` | Al Galal & Al Gamal (Jabal Omar retail) |
| `MOC-ASEER-SIC` | Aseer Museum (alternate code) |

### BIM dedup with OneDrive EDEADLK

When routing to BIM folders on OneDrive (`~/Library/CloudStorage/OneDrive-*/Bim Unit/`), you **cannot read file contents** to deduplicate (all reads trigger EDEADLK). Use filename-only matching:

1. `find -type f` to list all filenames in target BIM subfolders (never tries to read content)
2. Python with Arabic normalization (`unicodedata.normalize('NFC', ...)`, Alef/Yeh mapping, diacritic stripping) for fuzzy matching
3. `difflib.SequenceMatcher` with ratio > 0.9 for `_1`/`_2` suffix variants

See `references/onedrive-edeadlk.md` → "BIM scanning workaround" for full Python implementation.

### Pitfall: BIM is deep — search ALL subfolders

Don't just check the direct target folder (e.g. `05_Correspondence_Archive/`). The BIM archive is organized into numbered subfolders like `02_Correspondence_MOC/`, `01_Plans_and_Reports/`. Use recursive `find` across the whole tree — a file may already be filed in a deeper subfolder you didn't scan.

### Full dedup + routing reference

See `references/batch-email-routing.md` for complete AppleScript + Python workflow.

## Direct Attachment Extraction (no AppleScript)

For bulk extraction where AppleScript is too slow, you can extract attachments directly from the Outlook attachment cache by querying the Blocks/Mail_OwnedBlocks relationship in the SQLite database.

### Finding attachment file paths

```sql
-- Find attachment file paths for a specific email
SELECT hex(b.BlockID), b.BlockTag, b.PathToDataFile
FROM Blocks b
JOIN Mail_OwnedBlocks m ON m.BlockID = b.BlockID
WHERE m.Record_RecordID = <RECORD_ID>
ORDER BY m.BlockTag;
```

This returns paths like `Message%20Attachments/35/<UUID>.olk15MsgAttachment` relative to the Data/ directory.

### Extracting PDF from .olk15MsgAttachment files

The `.olk15MsgAttachment` files have a proprietary binary header (~285 bytes) followed by base64-encoded PDF content starting with `JVBER`:

```python
import base64, re

with open('file.olk15MsgAttachment', 'rb') as f:
    data = f.read()

# Find base64 PDF start
idx = data.find(b'JVBER')
if idx >= 0:
    b64_text = data[idx:].decode('ascii', errors='ignore')
    b64_clean = re.sub(r'[^A-Za-z0-9+/=]', '', b64_text)
    pdf_data = base64.b64decode(b64_clean)

    with open('output.pdf', 'wb') as out:
        out.write(pdf_data)
```

### Getting attachment metadata (filenames, types)

The file header (first ~285 bytes) contains metadata in plain text:
- `Content-type: application/pdf; name="filename.pdf";`
- `x-mac-creator=`
- `Content-ID:`
- **iCloud + OneDrive EDEADLK on cloud-only files** — macOS cloud storage providers (OneDrive File Provider and iCloud Drive) permanently lock files whose content hasn't been fully downloaded locally. The error `Resource deadlock avoided (EDEADLK)` appears on any read attempt: cp, ditto, rsync, tar, Python open, head, cat, hexdump, file. This affects BOTH:
  - OneDrive at `~/Library/CloudStorage/OneDrive-*/`
  - iCloud Drive at `~/Documents/` (when iCloud sync is active for Documents)
  
  On iCloud, `file` and `stat` commands also fail (unlike OneDrive where `stat` still works). AppleScript returns I/O error -36.
  
  Detect cloud-stub status: `mdls -name com_apple_provenance_isDownloaded <file>` (OneDrive) or check extended attrs.

  **Priority-ordered workarounds:**
  1. `osascript -e 'do shell script "python3 <script.py> 2>&1"'` — even from a fully locked directory, AppleScript's `do shell script` can execute Python scripts when direct shell access fails. Proven to work on both iCloud and OneDrive.
  2. `python3 <script.py>` — can execute cloud-stored `.py` scripts successfully even when `cat`/`head`/`file` commands fail on the same file. `wc -c` reads full size.
  3. `brctl download <path>` — forces the file to sync locally. Wait 1–2s, verify with `stat -f "%Sf" <path>` (output `-` when fully local).
  4. Delete-and-copy — `os.remove(target_path)` then `cp -X /tmp/source target`; deleting the existing stub removes the sync engine lock.
  5. `cat <src> > /tmp/x && mv /tmp/x <dest>` — bypasses `fcopyfile` deadlock in `cp`. ⚠️ Only works for OneDrive files, NOT iCloud Drive dataless files (those silently produce 0-byte output).
  6. **Content-request via time-based detection** — when you cannot read file contents, use `find -ctime -1` (change time), `find -newermt "<date>"` (modification time), or `find -newer <reference_file>` to detect if new/changed files exist. Compare filenames against target BIM folders with `find ... -name "${base}*"` to determine if already filed, without needing to read file bytes.

  Last resort: write companion sidecar files to the same directory (write-to-cloud works when reads fail — write/read asymmetry).
  See `references/onedrive-edeadlk.md` for full diagnostics.
