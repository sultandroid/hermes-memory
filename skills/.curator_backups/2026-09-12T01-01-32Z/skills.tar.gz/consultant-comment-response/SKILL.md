---
name: consultant-comment-response
description: Handling consultant review comments on submittals.
---

# Consultant Comment Response

## Overview
Handling consultant review comments on submittals: extracting comments from PDFs, mapping to responsible parties via RACI, drafting internal action assignment emails and external reply emails to the consultant. Covers the full workflow from PDF extraction to email composition.

## Workflow
1. **Extract comments** from the PDF using `pdftotext -layout`
2. **Read the RACI matrix** (Excel) to understand party responsibilities
3. **Map each comment** to the responsible party and determine status
4. **Draft internal email** assigning actions to each party with deadlines
5. **Draft external reply** to the consultant with a table of responses

## Extended Workflow: CG Schedule/Register Processing

When CG sends an Excel/PDF schedule (object schedule, drawing register, submission plan):

1. **Extract & map** — Use `openpyxl` for Excel, `pdftotext -layout` for PDFs. Build a clean object-to-showcase mapping table
2. **Version comparison** — Compare against the previous version. Identify new, removed, reassigned, split, and unassigned items
3. **Gap analysis** — Check which galleries/areas have complete mapping vs missing. Flag contradictory notes, missing dimensions, color coding violations
4. **Multi-party routing** — Draft ONE email with a responsibility table (NRS / Glasbau Hahn / Structural Engineer)
5. **Decide whether to query CG** — If entire galleries are missing assignments, query CG before routing. If minor TBCs, proceed and flag
6. **Handle designer pushback** — NRS will flag inconsistencies, request curator meetings, and claim additional fees. Forward to CG, support the fee claim

See `references/cg-schedule-processing.md` for the full workflow with templates and pitfalls.

## Key Files
- `templates/internal-action-email.md` — Template for internal action assignment
- `templates/external-reply-email.md` — Template for external reply to consultant
- `references/comment-extraction-technique.md` — Detailed technique for extracting and mapping comments
- `references/cg-schedule-processing.md` — Processing CG Excel/PDF schedules (object schedules, drawing registers): extraction, version comparison, gap analysis, multi-party routing, handling designer pushback
- `references/design-study-handling.md` — Handling NRS Design Study submissions with cost notifications and team assignment templates

## Extended Workflow: CR Sheet (Comment Response Register) Excel

When the task is to produce a structured CR Sheet mapping consultant comments to responses:

1. **Extract CG comments** — `pdftotext` the CG review PDF. Read the full text. Group by discipline (Architecture, Structure, MEP, etc.)
2. **Extract designer input** — Pull from email (Outlook SQLite + AppleScript for full body) or from a response PDF. The designer's email often contains point-by-point responses embedded in the reply chain
3. **Read supporting documents** — Before accepting or rejecting a claim, read the referenced drawings/documents. The designer may claim "already exists at Stage 3" — verify by reading the actual Stage 3 PDFs
4. **Build the CR Sheet** — Use `openpyxl` to create a 2-sheet workbook:
   - **Sheet 1: CR Register** — Columns: CR#, CG Comment, CG Reference, Response, Position, Status, Action Required, Supporting Documents
   - **Sheet 2: Summary** — Status breakdown, key positions, recommended next steps
5. **Status classification** — Use these categories:
   - **Acknowledged** — comment noted, no further action
   - **Already covered by Stage 3** — existing approved documents address the comment
   - **To be included in subsequent stages** — item will be developed from 50% to 90% to IFC
   - **To be provided under relevant scope** — belongs to another discipline/specialist
   - **N/A** — comment belongs to another discipline
6. **Color coding** — Yellow=Partial, Red=Not part of this submission, Blue=Acknowledged, Grey=N/A
7. **Cross-reference verification** — When designer says "already exists at Stage 3", verify by reading the referenced PDFs. Note the drawing numbers and document titles in the Supporting Documents column
8. **Propose next steps** — For each CR, state what needs to happen: confirm with CG, coordinate with specialist, appoint supplier, etc.

### CRITICAL: Response Voice Rules

**The CR Sheet speaks as the contractor (Samaya), not the designer (NRS).** This is the most common mistake. Follow these rules:

- **No sub-consultant scope splits.** Never say "NRS scope" vs "Samaya scope" — everything is under Samaya. The CG does not need to know internal sub-consultant allocations.
- **No "our design scope covers" framing.** The contractor's scope covers everything. Items not yet developed are "to be coordinated and included in subsequent stages" not "outside our scope."
- **Items to be developed later:** Say "will be coordinated and included in subsequent stages from 50% to 90% to IFC. Supplier to be appointed." Do not say "outside NRS scope" or "being sourced by Samaya."
- **Items handled by specialists:** Say "will be provided under the relevant scope, coordinated with the [specialist name] specialist." Do not say "by others" or "outside NRS scope."
- **Items already covered by Stage 3:** Say "was defined and approved at Stage 3. The existing Stage 3 document already addresses this. To be confirmed with CG whether sufficient." Do not say "NRS confirms" or "NRS position."
- **Column header:** Use "Response" not "Designer Response" or "NRS Response."
- **Designer input is raw material only.** Extract the designer's technical position from their email, then rephrase it as the contractor's response. The designer's frustration ("this is pointless", "not what RIBA defines") stays in the source — do not carry it into the CR Sheet.

### CRITICAL: No AI Fingerprints in CR Sheets

The user explicitly rejects any machine-generated formatting. Follow these rules strictly:

- **No emoji anywhere.** Not in status columns, not in summaries, not in legends. Use plain text: CLOSED, OPEN, PARTIAL, REQUESTED.
- **No special/unicode characters.** Replace all:
  - Em-dash (U+2014) -> plain hyphen
  - En-dash (U+2013) -> plain hyphen
  - Arrow (U+2192) -> plain >
  - Bullet (U+2022) -> plain -
  - Section symbol -> remove
  - Smart quotes -> straight quotes
  - Multiplication sign (U+00D7) -> lowercase x
- **No AI-sounding phrasing.** Avoid: "demonstrates full compliance", "globally recognised", "museum-grade", "well-known manufacturer". Use plain engineer language: "meets spec", "datasheet attached", "submitted per schedule".
- **No ALL-CAPS for emphasis.** Dont write SEPARATE, NOW, IN PROGRESS, LOOK AND FEEL. Use normal sentence case.
- **No does NOT depend or is NOT a blocker.** Use lowercase: does not depend, is not a blocker.
- **No spaced hyphens used as em-dash substitutes mid-sentence.** Use commas instead.
- **No dot as bullet separator in summary lines.** Use semicolons or plain commas.
- **Status labels only:** CLOSED, OPEN, PARTIAL, REQUESTED. No emoji prefixes, no colored dots.
- **Verify before delivering.** Run a hex check: scan all cell values for any character with ord(c) > 127. If any found, replace them before saving.

### CR Sheet: Stating Facts vs Claiming Closure

When a CG comment references a related document or instruction (e.g. SI-007, a previous submittal):

- **Do NOT claim the referenced item is closed or resolved** unless CG explicitly stamped it closed. The CR Sheet is not the authority on other documents status.
- **Do state the facts:** what was submitted, when, and what CGs response was (if any).
- **Example (wrong):** "SI-007 was closed at SI level on 27-Apr-2026 (R1)."
- **Example (right):** "3D render (ZD-0033 Rev.01) and material board (ZD-0030 Rev.01) already submitted and approved by CG."
- **The CR Sheet addresses the specific comment only.** Dont expand into other documents lifecycle status. If CG wants to know SI-007 status, they will ask separately.

### CR Sheet: Compact to One Page

- **Row heights:** 50px max per row. No verbose paragraphs.
- **Column widths:** Tight. 35 chars for response column, 18 for status/remarks.
- **Content:** Short sentences. One idea per cell. No multi-paragraph responses.
- **Fit to page:** Set ws.page_setup.fitToWidth = 1 and ws.page_setup.orientation = landscape.
- **Summary line:** One line at bottom, no line breaks. Use semicolons as separators.

### CR Sheet: Email Thread References

- **Do NOT include .txt files** of email threads in the support folder.
- **Reference emails by date and sender only** in the CR Sheet cells. E.g. "Glasbau Hahn reply 29-Apr-2026" or "NRS Jim Richards 19-Jun-2026".
- If the user wants the email content preserved, print the email to PDF from Outlook and include the PDF, not a .txt file.

### Submission Plan vs CR Sheet — Separation of Concerns

**Critical distinction:** The submission plan and the CR sheet serve different purposes and must NOT mix content:

| Document | Purpose | Content |
|----------|---------|---------|
| **Submission Plan** | Forward schedule — what we will submit and when | Deliverable name, brief description, responsibility, planned date, status. No explanations, no Stage 3 references, no commentary. |
| **CR Sheet** | Response to CG comments — positions, explanations, evidence | Full response text, position statement, status, action required, supporting documents. |

**Submission Plan description rules:**
- State only the deliverable: "Scenography drawing showing showcase locations, circulation paths, and key interaction points."
- Do NOT add: "Completed at Stage 3. NRS draft included in submission plan." — that belongs in the CR Sheet
- Do NOT add: "Wayfinding discrepancies flagged by NRS to be resolved." — that belongs in the CR Sheet
- Do NOT add: "FF and E supplier to be appointed. To be included from 50% to 90% to IFC stages." — keep it as "FF and E layout plan."
- Remarks column: use only for scheduling notes (e.g., "FF and E supplier to be appointed"), not for commentary

**CR Sheet description rules:**
- Full response: "This was completed at Stage 3. NRS prepared a draft copy (MOC-...) for reference. Will be included in the submission plan and drawing register."
- Action required: "Include in submission plan and drawing register"
- Supporting documents: List the actual file names

### Staging Pattern for Items Not Yet Developed

When CG asks for items that were not in the original submission plan:

| Item Type | Response Pattern |
|-----------|-----------------|
| FF&E layouts | "Will be coordinated and included in subsequent stages from 50% to 90% to IFC. Supplier to be appointed." |
| Signage/Graphics | "Included in the 50% gate. Will be submitted separately, coordinated with the signage and graphics specialist." |
| Life Safety | "Will be provided under the relevant scope, coordinated with the Life Safety specialist." |
| Structural items | "To be included as part of the structural submission." |
| **Warranties / compliance certs / third-party test reports** | **NOT APPLICABLE AT SPEC STAGE + Open.** Per SoW Sec 6.11-6.17, product data, certificates, and test reports are IFC-package submittals and "shall not be submitted independently." They are **Material Approval (MAR) stage** deliverables, submitted by the approved suppliers, NOT specification-stage deliverables. The spec defines the required criteria; the evidence is submitted at the correct later stage. Reply: "NOT APPLICABLE AT SPEC STAGE. Per SoW Sec 6.11-6.17, product data, certificates, and test reports are IFC-package submittals and shall not be submitted independently. These are Material Approval (MAR) stage deliverables, submitted by the approved suppliers, not specification-stage deliverables. The specification defines the required criteria; the evidence is submitted at the correct later stage." |
| **BIM / clash coordination** | **NOTED (not COMPLIED) + Open.** Cross-discipline clash avoidance is a **90% design stage deliverable** (coordinated drawings + BIM model), NOT a 50% spec deliverable. The specs at 50% define material/system requirements only. Reply: "NOTED. Coordination between disciplines (Architectural, Structural, MEP) to avoid clashes is a 90% design stage deliverable, managed through the coordinated design drawings and the BIM model. The specifications at this 50% stage define material and system requirements only. Clash avoidance will be addressed in the coordination drawings at the 90% stage." Do NOT claim a "coordination matrix has been added" unless such a file actually exists in the package — search first. If CG insists, be ready to cite the submission plan / DMP stage-gate that places coordination at 90%. |
| Simple acceptance | "Noted. [Action] to be prepared." — Status: Accepted |

### Open/Closed/Noted Status Column

After building the CR Sheet, add a status column with three values:

| Status | Meaning | Color |
|--------|---------|-------|
| **Open** | Action pending — supplier to be appointed, specialist to coordinate, information pending | Red (#FCE4EC) |
| **Closed** | Resolved — draft submitted, CG confirmed, item accepted | Green (#E2EFDA) |
| **Noted** | Acknowledged — process requirement, no further action | Blue (#D6E4F0) |

Insert this column between the Status column and Action Required column. Use `ws.insert_cols(7)` to shift existing columns right.

### Supporting Documents Column Rules

- List only file names and paths — no parenthetical internal notes
- Wrong: `Consultant_Comment_Register_Revised.xlsx (Comment 3)`
- Right: `Consultant_Comment_Register_Revised.xlsx`
- If a document reference is internal (e.g., a specific comment number), put it in the Action Required column instead
- Use `N/A` when no supporting document exists

### Cross-Referencing Between Registers

When multiple registers exist for the same project (CR Sheet, Consultant Comment Register, Structural Submittal Register, etc.):

1. **Read all relevant registers** before writing responses. The Consultant Comment Register may contain detailed responses that should inform the CR Sheet.
2. **Reference file names only** in the Supporting Documents column — no parenthetical internal notes (e.g. use `Consultant_Comment_Register_Revised.xlsx` not `Consultant_Comment_Register_Revised.xlsx (Comment 3)`).
3. **Put specific references** (comment numbers, section references) in the Action Required column instead.
4. **Update all registers** when a CR status changes — the CR Sheet, submission plan, and discipline-specific register should all reflect the same status.

### Register Split Pattern (Specialized Scope)

When CG requests a separate register for a specialized scope (e.g., rigging systems):

1. **Create a new register file** — Extract the relevant rows from the main register into a new workbook with its own title and section headers.
2. **Reference in the main register** — Replace the extracted rows with a single reference note: `"[Scope] — See separate [Register Name]"`
3. **Preserve template formatting** — Only clear the specific rows being moved. Do NOT rebuild the entire workbook. Unmerge any merged cells in those rows first, then clear cell values. Leave all other formatting, merged cells, colors, and styles untouched.
4. **Name the new file** consistently — `[Discipline]_Submittal_Register/[Scope]_Submittal_Register.xlsx`

### Template Preservation Rule

When editing an existing Excel register or submission plan:

- **Only modify the specific cells/rows needed.** Do not rebuild the file from scratch.
- **Unmerge merged cells** in the affected rows before clearing values.
- **Preserve all original formatting** — header styles, column widths, merged cells in unaffected rows, section colors, borders.
- **Add reference notes as plain text** in the first column of cleared rows. Do not apply special formatting to these notes.
- **Verify** by re-reading the file after saving to confirm only intended changes were made.

### Closing a CR When Designer Provides Drafts

When the designer initially pushes back on a CG comment but then prepares draft drawings anyway:

- **Update the CR to reflect the actual outcome**, not the initial position.
- Change status from "Partial - needs CG confirmation" to "Closed - draft submitted"
- List the actual drawing numbers in Supporting Documents
- Keep the Action Required focused on what remains (e.g., "Update title sheet and submit final")
- The designer's frustration or pushback language stays in the source email — do not carry it into the CR Sheet

### CRS from the Approved MOC Template (Fresh Code-C Response)

When CG returns Code C and you must produce the CRS that accompanies the Rev 01 resubmission, **copy the latest approved CRS Excel template and refill it** (preserves the exact MOC layout, merges, masthead) rather than building a fresh workbook. See `references/crs-from-template-cell-map.md` for the full verified cell map (header fields + comment data rows), the MergedCell writing rule, and the confidential design-transition note.

### CRS Stale-Template Replacement (header + comments belong to a DIFFERENT document)

When the CRS file's header AND comment rows carry content from a different document (e.g. header says "Interactive Design SOW" but you're responding to "Showcase DD"), you must replace the header, swap the comment rows (possibly a different count), and shift the legend/signature block manually. `ws.insert_rows()` does NOT shift merged ranges. See `references/crs-stale-template-replacement.md` for the full recipe (header field map, manual merged-cell block shift, openpyxl pitfalls: no `styles.Style()`, `MergedCell.value` read-only, `_style` is a StyleArray).

### CRS Revision Update (Existing CRS to Rev 01+)

When CG returns a CRS on a submitted document and you have prepared Rev 01 of the document addressing the comments, update the CRS to Rev 01 with originator replies. See `references/crs-revision-update.md` for the full workflow with openpyxl patterns, reply templates by comment type, formal code mapping, and filing instructions.

Key differences from creating a CR Sheet from scratch:
- The CRS already exists with CG comments, status codes, and possibly partial replies
- You only update revision fields, date, and originator reply cells (no restructuring)
- Column A values are **strings** (`'17'` not `17`)
- J column is merged (`J{row}:O{row}`) — write to the top-left cell only
- Save as "Rev 01" alongside the source document in the same folder

### Simple Acceptance Pattern

When a CG comment is straightforward and accepted without debate:

- Response: `"Noted. [Specific action] to be prepared."`
- Position: `"Accepted"`
- Status: `"Accepted"`
- Open/Closed: `"Closed"` (green)
- Action Required: The specific action to take

Example: CR-07 (Rigging register) → "Noted. Separate submittal register for rigging works to be prepared."

- `references/cr-sheet-workflow.md` — Complete technique with openpyxl patterns and status classification rules for creating CR Sheets from scratch
- `references/cg-warning-letter-reply.md` — Full warning-letter reply workflow: two-letter chain verification, contract-article map (reversed-OCR search method), Outlook-as-authoritative-date-source for direct letters, Aconex last-update timestamps, claim-by-claim evidence table, PM paragraph-review protocol, RTL styling pointers
- `references/crs-revision-update.md` — Updating an existing CRS to Rev 01+: revision fields, originator replies, formal code mapping, filing alongside source document
- `references/oddy-test-material-resubmission-ma0007.md` — Patinated Brass MA-0007 Code C cleared by a passed Oddy test; the split-track (approve now, certs follow as Rev.02) strategy; the full brass-applications list (FI_ME_01/ME_03/GR_11/ST_03); ER §6.11 / SoW §13.29 Oddy clause anchors
- `references/moc-hq-crs-template-cell-map.md` — **USE THE OFFICIAL MOC_HQ CRS TEMPLATE, never build a custom CRS workbook.** Public URL (samaya-factory.com/assets/templates/CRS_Template_MOC_HQ.xlsx), verified cell map (header + comment rows), openpyxl merged-cell notes, and the material-cert compliance analysis (which certs are legit vs CG overreach: Oddy/composition/MSDS legit; fire-rated/off-gassing/2-alternatives overreach; VOC partial — metals don't emit VOC).

## Extended Workflow: MAR Compliance Sheet Resubmission

When the consultant returns a **Code C (Revise and Resubmit)** on a Material Approval Request (MAR) with comments about the compliance sheet:

### The Core Rule: Achieved Values + Test Report References

The most common and critical CG comment on MARs is: **"Compliance sheet shall include the achieved values and the corresponding test report references."**

This means:
- **Status markers are NOT acceptable.** Do not use "Partial", "Gap", "Supported", "Compliant", or any qualitative status in the compliance column.
- **Every row must have an actual number** — density in kg/m³, modulus in MPa/N/mm², thickness in mm, moisture content in %, flame spread index, formaldehyde emission class, etc.
- **Every value must cite a source** — the exact file name and page/section of the datasheet, test report, or certificate that proves it.

### Compliance Sheet Structure

| Column | Content | Example |
|--------|---------|---------|
| Spec Clause | Exact clause reference | 061000 2.1.A |
| Parameter | What is being measured | Density (air-dry) |
| Required Value | From the spec | >= 640 kg/m³ |
| Achieved Value | From the datasheet | 680 kg/m³ |
| Test Standard | ASTM/BS/EN ref | ASTM D2395 |
| Source Reference | File name + page | Garnica_Duraply_TDS.pdf p.3 |
| Compliance | Y or N only | Y |

### Workflow

1. **Extract spec requirements** — `pdftotext` the spec PDFs (e.g., 061000, 064023). List every clause with a numerical requirement: density, modulus, thickness, moisture content, fire rating, formaldehyde emission, screw withdrawal, etc.
2. **Extract achieved values** — `pdftotext` every datasheet PDF in the submission. Build a table of Manufacturer → Product → Parameter → Achieved Value → Test Standard → Source File.
3. **Cross-reference** — For each spec clause, find the matching achieved value from the datasheets. If no datasheet covers a required parameter, that's a real gap to flag.
4. **Build the compliance sheet** — One row per spec clause. Every row has a number in the Achieved Value column and a file reference in the Source column.
5. **Update the MAR checklist** — Items that were "No" or "N/A" should be upgraded to "Yes" once the evidence is in place.

### Common Gaps Found in Practice

| Gap | What's Needed |
|-----|--------------|
| Fire test report | Product TDS is NOT a fire test report. Need a lab report (UL, Intertek, Warringtonfire) explicitly stating Class A flame spread (<= 25) and smoke developed (<= 450) per ASTM E84 or equivalent. |
| Metal component datasheets | Blum hinges/runners alone are not enough. Need datasheets for ALL metal: brackets, anchors, screws, tracks, connectors, fasteners. |
| Adhesive TDS | Brand-family evidence is not enough. Need the exact product TDS showing EN 204 D3 or ASTM D4317 Type II compliance. |
| Hardware schedule | No itemized project hardware schedule = gap. Need a schedule listing every handle, lock, hinge, runner, and fixing with model numbers. |
| Shop drawings | Approved shop drawings showing framing, furring, locations, dimensions, and attachments. |

### Pitfalls (MAR-specific)
- **"Compliant" is not a value.** The engineer will reject any compliance sheet that uses words instead of numbers.
- **Product TDS != test report.** A manufacturer datasheet states design values; a test report from a recognized lab proves actual performance. Fire ratings especially need the latter.
- **Partial compliance = non-compliance.** If even one clause lacks a verified achieved value, the whole submission gets Code C.
- **Metal components are often forgotten.** The spec requires all metal to have datasheets — not just the branded hardware (Blum) but also generic brackets, screws, and anchors.
- **Check the MAR checklist too.** The consultant's checklist items (Testing, Certifications, Method Statement) must all be upgraded to "Yes" with evidence, not left as "No" or "N/A".
- **"Not just noted" — the engineer wants numbers.** When the engineer says "achieved values shall be clearly reflected", they mean actual numerical values in every row. Status markers like "Partial" or "Supported" are not acceptable. Every row must have a number (kg/m³, MPa, mm, %) and a source file reference.
- **EN vs ASTM fire standards need bridging.** Greenlam/Garnica provide EN 13501-1 B-s1,d0 (European Class A equivalent) but the spec calls for ASTM E84. A cross-reference letter or direct ASTM E84 test report from the manufacturer is needed — don't assume the engineer will accept the EN classification without explanation.
- **Blum/Henkel catalogs don't state BHMA/EN grades explicitly.** Blum catalogs show load capacities and cycle durability but not BHMA A156.9 Grade 1. Henkel TDSs show viscosity and lap shear but not EN 204 D3. A manufacturer declaration letter is needed for each — don't assume the catalog data alone satisfies the spec.
- **Consolidate evidence into one folder.** Create `10_Compliance_Evidence/` with subfolders `Datasheets/` (organized by manufacturer) and `Certificates/`. Update all file references in the compliance sheet and MAR checklist to point to this consolidated folder. This makes the resubmission package self-contained and easy for the engineer to audit.

### Subcontractor Compliance Sheet — Fill the Engineer's Form, Do Not Create a New One

When you are a subcontractor responding to a Code C on a MAR, the Engineer wants you to fill their existing compliance template, not create a new one from scratch. The user will correct you if you create a new file: "he said just fill my form only."

#### Workflow

1. **Use the Engineer's own compliance format.** The Engineer provides an Excel template with spec text already written in. It has columns: No., Section, Specifications, Manufacturer/Supplier Statement, Compliance, Remarks. Only fill the last three columns. Do not modify the spec text, section numbering, header rows, signature blocks, or merged cells.

2. **Only fill material data rows, not company data rows.** As a subcontractor, your compliance sheet addresses only material-specific spec clauses:
   - MDF physical properties (density, MOR, MOE, IB, swelling, screw holding)
   - Fire ratings (flame spread, smoke developed)
   - Formaldehyde emissions (NAUF, CARB, E1)
   - Hardware (hinges, slides — BHMA compliance)
   - Adhesives (EN 204 D3, UF-free)
   - Plywood/panel products (BS EN 636, marine grade)
   - Coatings/finishes (fire retardant, VOC)

   Do NOT fill rows for company-level items:
   - Fabricator qualifications (years of experience)
   - Installer qualifications
   - Warranty periods
   - Installation tolerances
   - Product data submittals (1.3.A)
   - Product certificates (1.3.E)
   - Environmental limitations

   These are the main contractor's responsibility. The user will correct you: "only fill the materials data not company data."

3. **Evidence in Remarks column.** Every filled row must have a source reference in the Remarks column — the exact file name of the datasheet, test report, or certificate that supports the achieved value. Do not leave Remarks empty. The user will correct you: "add in Remarks the evidence of the comply, not just tell comply."

4. **No subcontractor datasheets for main contractor items.** The main contractor provides their own company certificates (ISO, CR, VAT, GOSI, Saudization) and general submittal documents. The subcontractor only provides their own material datasheets and test reports. The user will correct you: "no need to add Ola paper because we are subcontractor and the main contractor will add his papers."

5. **Keep the Engineer's original structure intact.** The Engineer's Excel has merged cells, signature rows, and section headers. Only fill the Manufacturer Statement, Compliance, and Remarks columns. Do not modify the spec text, section numbering, header rows, or signature blocks. Preserve all original formatting.

6. **No symbols or AI fingerprints in compliance sheets.** Use plain text status labels: "Compliant", "Partial", "Pending". No emoji, no checkmarks, no unicode symbols. Remarks should reference file names directly — no AI-sounding phrases like "demonstrates full compliance" or "exceeds minimum by 20%". Write like an engineer: "Verdo FR MDF TDS - Density 800.80 kg/m3".

## Forwarding CG Comments to Designers (Pre-CR-Sheet Routing)

Before building the CR Sheet, CG comments often need to be **filtered and forwarded to the designer** (NRS, AD Engineering, etc.) for their input. This is a distinct workflow step.

### Workflow

1. **Read the full CRS** — Extract all comments from the CG's Excel/PDF
2. **Map each comment to a party** — Use the scope split, not assumptions:
   - **Designer scope** (NRS): Drawing content, title blocks, QA notes, sheet layout standards, dimensions, room names, section details, showcase design, finishes schedule format, material specifications
   - **Contractor scope** (Samaya): Cloud survey, demolition methodology, mock-ups, material samples, BIM coordination, subcontractor appointments, site logistics
   - **Specialist scope**: Graphic housing, AV, lighting (ZNA), life safety — route to the relevant specialist
3. **Verify responsibility from past emails** — Before assigning a comment to a party, check Outlook for prior correspondence on the same topic. The designer may have already addressed it or pushed back. Use `Conversation_ConversationID` to find the full thread.
4. **Draft a filtered email** — Only include items that belong to the designer. Do NOT dump the entire CRS on them.

### What Belongs to the Designer

The designer produces the drawings, so these are on them:
- Title block content (dates, revision schedule, drawing numbers, reviewer names)
- QA notes and sheet layout standards compliance
- Missing dimensions, room/space names on sections
- Showcase design details (opening mechanisms, finishes, dimensions)
- Finishes schedule format and content
- Space labeling (FFL, CIL, space codes)

### What Belongs to the Contractor

These are Samaya/contractor responsibilities:
- Cloud survey (pending — note it in the email for context)
- Demolition methodology and ceiling removal clarification
- On-site mock-ups and material samples
- BIM coordination and clash resolution
- Subcontractor appointments (Glasbau Hahn, etc.)
- Site logistics and access

### Email Structure to Designer

```
Subject: NRS Input Required — [SUBMITTAL REF] CRS ([FLOOR] Only)

Dear [Name],

CG returned the CRS for the [Floor] [Discipline] DD submittal (overall C).
We are preparing our response and will address the items on our side
([list contractor-side items]) directly with CG.

The following items need [Designer] design input:

[Section Heading (Reviewer Name)]:
- #[N] — [Brief description of comment]
- #[N] — [Brief description of comment]

Please review and advise so we can prepare the resubmission.

Regards,
[Name]
```

### Key Rules

- **Mention pending contractor items** (cloud survey, etc.) in one line so the designer knows the context — but don't list them as action items for the designer
- **Check past emails** before assigning — the designer may have already responded to a similar comment in a previous round
- **Name the floor** in the subject — CG often reviews one floor at a time
- **Group by reviewer** (Eng. Maged Zamzam, Eng. Islam Mostafa, Eng. Abdrabo) for clarity
- **Keep it short** — the designer doesn't need to see all 89 comments, only their ~15-20

### CRS Item Mapping — Designer vs Contractor

Before forwarding, map each CRS item to the correct party. Do NOT dump the entire CRS on the designer.

**Designer (NRS) scope — send to NRS:**
- Title block content (dates, revision schedule, drawing numbers, reviewer names)
- QA notes and sheet layout standards compliance
- Missing dimensions, room/space names on sections
- Showcase design details (opening mechanisms, finishes, dimensions, perspective views)
- Finishes schedule format and content
- Space labeling (FFL, CIL, space codes)
- Expansion joint detailing in finishes
- Stairs solution and finishes

**Contractor (Samaya) scope — handle internally:**
- Cloud survey (pending — note in email for context only)
- Audit report coordination
- On-site mock-ups and material samples
- BIM coordination and clash resolution
- Demolition methodology and ceiling removal clarification
- Subcontractor appointments (Glasbau Hahn, etc.)
- Site logistics and access
- Shop drawings for doors/stairs (contractor to produce from design intent)

**Specialist scope — route separately:**
- Graphic housing — route to signage/graphics specialist
- AV coordination — route to AV specialist (Rawasin)
- Lighting — route to ZNA
- Life safety — route to life safety specialist

### Floor Verification Step

Before forwarding, verify which floor(s) the CRS covers:

1. Check the document title in the CRS header (row 7-8 of the Excel)
2. Check drawing number prefixes in the Sheet column:
   - `BF` = Basement Floor
   - `LG` = Lower Ground
   - `GF` = Ground Floor
   - `GEN` = General (cross-floor)
3. If all drawing numbers use one prefix, the CRS covers that floor only
4. Name the correct floor in the email subject line

## Plan-Level CG Comment Audit Against Contractual Obligations

When CG returns a management plan (SMP, DMP, HSE Plan, QMP, RMP) with Code C, audit each comment against the actual ER/SoW/SBC text before drafting responses. This determines which comments are valid, which are already addressed, and what specific action is needed.

### RMP-Specific CG Comment Audit (Common Patterns)

Risk Management Plans attract a predictable set of CG comments. When auditing RMP comments, check these 5 patterns:

| Comment Type | What CG Wants | Common Root Cause | Fix |
|-------------|---------------|-------------------|-----|
| **Missing registers** | PRR, DDR, HSE, AV registers attached alongside the methodology | RMP submitted as standalone document without appendices | Attach all 4 registers as appendices to Rev 01 |
| **Scoring scale inconsistency** | Uniform scale (5x5 recommended) across all registers | PRR uses 4x4, HSE uses 5x5, DDR uses unclear pairing | Standardise all registers to 5x5 (P 1-5 x S 1-5, max 25). Update severity bands: Critical 16-25, High 10-15, Medium 5-9, Low 1-4 |
| **Quantitative analysis placeholders** | Defer Section 7, don't fill with "To be calculated" | BOQ not finalised, lump-sum packages, no firm cost inputs | Replace placeholders with deferral statement: quantitative analysis follows when BOQ is finalised; qualitative scoring governs until then |
| **Schedule integration not demonstrated** | Worked example linking PRR entry to P6 Activity ID, WBS, float | RMP mentions schedule risk analysis but no concrete example | Add sample: Risk ID -> P6 Activity ID -> WBS -> Total Float -> Schedule Impact |
| **Missing shipping/logistics risk** | Specific risk for current Middle East shipping disruption | PRR-PRC-06 exists but scores too low; no specific Red Sea risk | Add new risk PRR-PRC-07 (Critical), update Section 2 Project Risk Profile |

### Audit Methodology

1. **Extract CG comments** from the PDF or email
2. **Read the actual plan document** — check if the comment is valid by comparing against the plan's own content, not just ER/SoW
3. **Classify each comment**:
   - **Valid** — plan genuinely missing the item or has a quality issue
   - **Already addressed** — plan covers it but CG missed it (rare)
   - **Scope creep** — not a contractual obligation (push back)
4. **Determine effort** — cost impact, schedule impact, and whether it's a desk exercise or requires external input
5. **Produce CRS Excel** with 2 sheets: (1) CR Register with obligation assessment, (2) Action Tracker with assignments and target dates
6. **Fix the plan document** — apply all changes directly to the plan, not just the CRS

### CRS Excel Structure for Plan-Level Comments

Use a 2-sheet workbook:

**Sheet 1: CR Register** — Columns: CG Comment #, CG Comment (verbatim), ER/SoW Reference, Our Obligation (on our shoulder / push back), Cost Impact, Schedule Impact, Action Required, Proposed Response to CG. Colour-code rows: green (comply), amber (comply limited), red (push back).

**Sheet 2: Action Tracker** — Columns: Item, CG Comment, Action Required, Assigned To, Target Date, Status, Evidence, Remarks. This is the execution plan for the team.

### Fixing the Plan Document

After producing the CRS, apply changes directly to the plan document:

| Change | Where | What |
|--------|-------|------|
| Frontmatter | YAML header | Update revision, date, conflict_resolution |
| Scoring tables | Section 6 | Replace 4x4 with 5x5 probability, severity, matrix, bands |
| Quantitative section | Section 7 | Replace placeholders with deferral statement |
| Schedule integration | Section 5 | Add worked example with P6 Activity ID, WBS, float |
| Risk profile | Section 2 | Add missing risk factors (shipping, etc.) |
| Register summary | Section 13 | Update scoring scale, count, date for all registers |
| Contingency tables | Section 7.2, 8.2 | Update score ranges to match new 5x5 bands |

## CRS Reply Wording Pitfalls (avoid "duplicate row" + open/closed contradiction)

When drafting the Originator Reply cell, three wording traps recur:

0. **HUMANIZE the reply (user preference, mandatory).** The user explicitly asked: "in review you have to humanize our replay." Replies must read like a real senior engineer wrote them, NOT like a filled template. Before finalizing any reply, strip bureaucratic/template phrasing and rewrite in plain, natural engineer voice:

   | Stiff / template | Humanized |
   |---|---|
   | "Per the CG request" | "As requested" |
   | "reviewed for coordination and interface consistency" | "circulated to the discipline leads for their review" |
   | "No conflicts were identified" | "no conflicts were found" |
   | "the architectural content remains as specified" | "incorporated into this resubmission unchanged" |
   | redundant tail "Incorporated into this resubmission." | merge into the sentence, drop the tail |

   Rules: active voice + plain verbs ("circulated", "found", "checked") instead of noun-stacks and passive constructions; drop redundant tails that restate what the sentence already said; keep it professional but natural. When the user asks for humanization, offer a choice of tone (professional-but-natural vs more conversational) and patch the file once they pick.

   **Bullet-point format for multi-item replies (user preference).** When a reply lists several items (applications, samples, options, sources), the user wants **bullet points grouped under bold sub-headers, NOT a paragraph** ("rewrite as points not paragraph humanize also"). Structure: short intro line, then grouped bullets, each one fact, close with the key line. This applies especially to the "2 alternative samples" / supplier-bank replies.

0b. **VERIFY cited sources before pushback (CRITICAL).** When a reply pushes back on a CG comment by citing an approved document (methodology, ER, SoW, previous submittal) — especially citing **specific comment numbers** ("Comment 2", "Comment 3") or a **specific review chain** — you MUST verify the actual cited content is on disk and says what you claim. Discovered pitfall: a reply cited "Per the approved NRS Methodology (ZD-0026, Code B, Comment 2)" and "The review chain (Comment 3) is Supplier/TO > Samaya > NRS > CG" — but the actual comment sheet was NOT on disk (only the single-page DS cover; the repo's own analysis flagged "Responses are attached" but the comment sheet is missing). The specific comment numbers and review chain were therefore unverifiable. CG will check your citation; if Comment 2/3 don't say what you claim, the pushback collapses and you lose credibility on a comment you're trying to reject. Before finalizing a pushback: (1) locate the cited doc — check the git repo `00_Contracts/` mirror if OneDrive is EDEADLK-locked, the repo often holds the analysis/summary files; (2) confirm the specific comment number / review chain / clause text actually exists and supports your claim; (3) if the source content is missing, either pull it from Aconex CDE / from CG, OR soften the reply to avoid citing specific comment numbers you can't prove. Do NOT send a pushback citing unverifiable specifics — that is exactly the "verify refs vs source" trap.

0c. **VERIFY the "revised sections" claim against actual file mtimes (CRITICAL).** Replies that say "their technical opinion is reflected in the revised sections" / "specification revised to require..." assert the spec files were actually changed. Before writing that, check the source files' modification times: `stat -f "%Sm" <spec.docx>` on every cited section. Discovered pitfall: a CRS claimed sustainability/acoustic sections were "revised" but every spec `.docx` was dated **Jul 14** and the NRS-stamped PDFs **Aug 8** — both BEFORE the CG comments (Aug 27). No post-CG revision existed on disk, so the claim was false. Also cross-check the repo's own CRS analysis file (`02_CG_Responses/<ref>_CRS_Rev01.md`) — it may claim "Specification revised to require..." for every S-series item while the Excel CRS says "MOSTLY EXISTS... to be added" / "FULLY EXISTS... no revision required" (an internal contradiction). If the files weren't actually revised, either (a) revise them for real before claiming it, or (b) reword to "reviewed... incorporated into this resubmission" WITHOUT asserting the sections changed. Never claim a revision that the files don't support — CG will open the resubmitted spec and find no changes.

0i. **Material MANUFACTURER vs FABRICATOR — attribute certs to the right party (CRITICAL, recurring).** For a material submittal, the party that makes the MATERIAL is not always the party that fabricates the end product. On MA-0007 the patinated brass material is made by **Eden-Design GmbH** (EDEN BRONZE™, CuZn base chemically bronzed/patinated); **Glasbau Hahn is only the showcase fabricator** (PQ-0063 Code B). Every material-level cert (MSDS, VOC, off-gassing, fire-rated, chemical composition) is issued by the **material manufacturer**, NOT the fabricator. The user corrects this every time it's wrong ("to be issued by Glasbau Hahn" → must be Eden-Design). Before writing "issued by [X]" for any cert, ask: is X the material maker or just the product fabricator? See `references/oddy-test-material-resubmission-ma0007.md` for the full MA-0007 case incl. the control-sample framing and supplier sample bank.

0d. **Use the specialist's ACTUAL role, not an inflated one (CRITICAL).** Before writing "the [specialist] reviewed the spec sections," check what that specialist's approved scope actually is. Discovered pitfall: the reply claimed the Sustainability Manager "reviewed the sustainability-related specification sections" and his opinion was "reflected in the revised sections" — but the approved SMP (Sec 7.2.10) assigns the Sustainability Manager to **DEFINE the sustainability criteria** (VOC limits, EPD, recycled content, Mostadam/SBC 1001) while **NRS (Lead Designer) INCORPORATES those criteria into the design specifications**. Claiming the sustainability manager "reviewed the spec sections" contradicts the approved SMP role split and CG will catch it. Correct framing: "The sustainability criteria for the materials are set by the Sustainability Manager (M. Fida Noon) per the approved SMP Sec 7.2.10 and ER Sec 2.4D, and are applied in the relevant specification sections of this resubmission." General rule: verify the specialist's role from their SOW/plan before asserting they reviewed or changed a document — a criteria-definer is not a document-reviewer.

1. **Do NOT repeat the comment verbatim in the reply preamble.** A reply that opens by restating the CG comment (e.g. "The matter requires a detailed study and review by the project's specialized team...") then adds "COMPLIED" reads as a duplicate row and bloats the cell. The reply should answer the comment, not echo it. If the comment text is long, the reply should NOT re-quote it.

2. **Never pair an open-sounding preamble with a "Closed" status.** A preamble like "The matter requires a detailed study and review... to provide their technical opinion and final feedback" is forward-looking (work still pending), which directly contradicts a "Closed" status. CG will flag it: "if it still requires study, why is it Closed?" Decide the real state first:
   - **Done** → drop the preamble, keep a clean COMPLIED statement, status **Closed**.
   - **Genuinely pending** → keep the review statement, status **Open**.
   You cannot have both.

2b. **Status rule: COMPLIED/NOTED → Closed; NOT APPLICABLE (pushback) → Open.** The status must reflect whether CG has *accepted* the reply, not just whether you wrote it:
   - **COMPLIED / NOTED** → **Closed** (you did what was asked, nothing pending).
   - **NOT APPLICABLE** (you reject the comment) → **Open** — the rejection is not resolved until CG agrees. Marking a pushback Closed presumes CG already accepted your NOT APPLICABLE, which they haven't; if CG disagrees it bounces back as a new comment.
   - **OPEN** (explicitly deferred) → **Open**.
   This pattern holds across a sheet: COMPLIED rows Closed, NOT APPLICABLE rows Open. Keep it consistent.

3b. **Template-similar comments are NOT duplicates.** CG often reuses the same sentence template for multiple comments, changing only the subject — e.g. "The matter requires a detailed review by the project's [specialized team / acoustics specialist / sustainability specialist] to provide their technical opinion and feedback." These look like duplicates but are distinct comments with different scopes and different replies. Do NOT merge or delete them. Check the subject of each: general ("specialized team") vs specific ("acoustics specialist") are different rows. Reply to each on its own merits — one may be Closed (accepted) while another is Open (pushed back).

3. **When CG explicitly requested the multi-discipline feedback, anchor the reply with "Per the CG request".** If CG asked for specialist/discipline input, routing it and rolling it back is correct — but phrase it as *feedback incorporated per CG request*, not *multi-discipline approval*. This prevents the reply from reading as Samaya voluntarily surrendering design authority over the architectural content. Pattern:
   > COMPLIED. Per the CG request, the specifications were reviewed for coordination and interface consistency with the relevant disciplines (Architectural, Structural, MEP, Acoustics, Sustainability). No conflicts were identified; the architectural content remains as specified. Incorporated into this resubmission.
   Key distinction: **coordination/interface review** (feedback, non-binding) ≠ **content authority** (approval rights). The architect/design lead retains content authority; other disciplines provide coordination feedback only.

0e. **Verify the EXACT ER/SoW clause number before citing it (CRITICAL).** A pushback that cites a specific clause must cite the RIGHT one. Discovered pitfall: a mock-up reply cited "ER Section 2.4.F" — but every project register and the DMP cite **ER §2.3.F** (Design Phase Mock-Ups) and **ER §2.5.F** (Construction Phase Benchmark Samples) for mock-ups; **ER §2.4 is the Approval Framework**, not the mock-up clause. CG will open the ER at 2.4.F, find nothing, and the reply loses credibility. Before citing any clause, grep the project's own registers/analysis files for the correct reference (e.g. `specification_list.md`, `deliverables_master_list.md`, DMP design-control files) — they usually carry the authoritative clause mapping. If your own prior audit file repeats the same wrong clause, fix it there too so the error doesn't propagate. Known correct mappings: mock-ups = SoW §13.12 + ER §2.3.F/2.5.F; product data/certs/test reports = SoW §6.11-6.17; Oddy = ER §6.11 (exhibition spaces, non-deleterious to objects) + SoW §13.29 (non-pre-approved materials only).

0f. **Do NOT claim a requirement is "embedded in EACH specification section" — say "where they apply."** When a reply asserts compliance requirements are present in every section, verify that's actually true. Discovered pitfall: a reply said environmental/HSE/sustainability requirements were "embedded in each specification section" — but a keyword scan showed Firestopping has no VOC/Mostadam/environment content (only fire), and Doors & Frames has no VOC/Mostadam/SBC. Not every section needs every requirement; firestopping doesn't need Mostadam, painting needs VOC. Overstating "each section" lets CG open any section, find the keyword missing, and call the reply false. Correct framing: "embedded in the specification sections where they apply." This is both more honest and more defensible — the general compliance obligation (ER §2.1: all materials comply with applicable codes; ER §2.4.E: designer certifies materials comply with all ER requirements) holds for ALL materials, but the SPECIFIC requirement (VOC, fire class, Mostadam) applies only where the material type calls for it. Verify by scanning the actual spec `.docx`/PDFs for the keywords before writing "each section."

3c. **Verify a "no variation to price/schedule" claim against the contract before confirming it.** CG boilerplate comments like "These specifications are reviewed based on the understanding that they introduce no variation to the contract price or project time schedule" are statements of principle, not technical comments — reply **NOTED + Closed** ("Samaya confirms the specifications introduce no variation to the contract price or time schedule. No revision required."). BUT before confirming "no variation," check the contract to be sure the specs genuinely don't change price/schedule. For a lump-sum D&B contract (e.g. Contract 0010003521): the Contractor bears ALL design risk and the prices are deemed sufficient to cover all obligations (Art. 6 "sufficiency of prices"), so routine spec changes within scope are NOT variations — confirming "no variation" is contractually sound. The ONLY variation pathway is Art. 14(5)(e) — errors/omissions in Government-Entity-provided information that change the works. If any spec item actually raises cost or time beyond the BOQ (e.g. a more expensive material), do NOT confirm "no variation" — that would be a false statement CG will hold you to. Check the contract summary (`00_Contracts/00_Contract_Summary.md`) for the variation article and lump-sum risk allocation before confirming.

3d. **Specs are the REFERENCE, not the dependent — push back when CG suspends spec review due to drawing comments.** When CG suspends a *specification* review because of comments on the *drawings* (e.g. display-case specs suspended until the showcase design 1G-0009 resolves), push back: the specifications are the material requirements issued by the Design Lead (NRS) — they are the **reference against which the drawings are reviewed, not a deliverable that depends on the drawings**. Verify the drawing comments are all drawing-level (mechanism operation, access panels, sections, electrical/AV outlets, wall interfaces, structural calcs) and none touch spec content — read the CG response sheet to confirm. Then reply OPEN + ask CG to proceed with the spec review independently. Pattern:
   > OPEN. The [N] CG comments on the [Showcase] design ([ref]) all relate to drawing-level details ([list]). None of them touch the content of the [display case] specifications. The specifications are the material requirements issued by the Design Lead (NRS) and are the reference against which the drawings are reviewed, not a deliverable that depends on the drawings. Samaya asks CG to proceed with the review of the [display case] specifications without further delay.
   Note: check whether the specs were actually attached to the drawing package (the CG sheet may say "Attached: ... + specification + CRS") — if so, the specs were already part of the package and the suspension is even less justified.

0g. **Verify EVERY spec claim against the ACTUAL spec file before writing it (CRITICAL).** For section-level (S-series) replies that cite spec sections, open the real spec `.docx`/PDF and confirm each cited value, section number, AND exact wording. This session caught 4 factual errors by checking the files:

   | Claim in draft | Reality in spec | Fix |
   |---|---|---|
   | "NCR for unapproved rebar cutting (Sec 3.02.B.3)" | Spec says "Do not cut reinforcement without the approval of the structural engineer" — **no NCR word anywhere** | Quote the actual text; don't invent terms |
   | "Only the 50x50 mm mesh size is missing - to be added to Sec 2.03" | Spec already says "mesh size 50 x 50 mm" in Sec 2.03 | Change MOSTLY EXISTS → **FULLY EXISTS**, no revision |
   | "ER Section 2.4.F" for mock-ups | Mock-ups are ER §2.3.F/§2.5.F; §2.4 is Approval Framework | Cite the correct clause (see 0e) |
   | "embedded in each specification section" | Firestopping has no VOC/Mostadam; Doors & Frames has no VOC/SBC | "in the specification sections where they apply" (see 0f) |

   **Method:** `cp` the spec docx to /tmp (OneDrive EDEADLK), unzip `word/document.xml`, strip tags, grep for the cited values (MPa, mm, ASTM refs, section numbers) AND the exact wording. Confirm the section number AND the wording before quoting. A wrong citation — invented term, wrong clause, or claiming something is missing when it's present — destroys the reply's credibility because CG will open the spec and find the discrepancy. When a claimed "missing" item is actually present, the status flips from MOSTLY/PARTIALLY EXISTS to FULLY EXISTS + Closed (no revision).

   **Recurring false-negative bias (watch for it — it is the #1 S-series error):** S-series replies in practice systematically claimed "MOSTLY EXISTS... only [X] is missing - to be added" when [X] was ALREADY in the spec. Across three review passes this caught it **7 times**: the 50x50 mm mesh (present in Sec 2.03), "single facility" + "single batch" (present in Sec 3.04), "no guillotine >10 mm" (present in Sec 2.16), "split-batten system" (present in Sec 2.04), "tight-butted veneers" (present in Sec 2.06), "no artificial heating" (present in Sec 3.03 — "Do not dry or raise the temperature of joints by heating"), and "fire-door ratings 90/30/120 min" (present in Sec 2.04/2.05/2.07 — section titles literally say "ACHIEVING 90 MINUTES" / "30 MINUTES" / "120 MINUTES"). The default assumption when drafting an S-reply should be **the item is probably already there** — verify before writing "missing." If it IS present, the reply becomes FULLY EXISTS + Closed (no revision), not MOSTLY + Open. A draft that says "missing" when it's present is a false negative that both loses credibility AND wrongly leaves the item Open. When the user says "always check" (a standing directive), they mean: open the actual spec file and confirm every cited value and every claimed gap before finalizing. Treat any "only [X] is missing" clause as a red flag to re-verify — it is wrong more often than it is right.

0h. **Verify the EXACT VALUE and the EXACT plan-doc section, not just presence (CRITICAL — the false-POSITIVE bias).** Pitfall 0g covers the false-negative bias (claiming "missing" when present). The mirror-image error is just as common and just as damaging: the reply OVERSTATES a value, cites the WRONG section of a plan document, or claims a requirement is "not a spec-stage item" when the spec actually contains it. All three were caught in one CRS audit pass:

   | Claim in draft | Reality in spec | Fix |
   |---|---|---|
   | "PTV ≥40 (Sec 2.01, 2.06, 3.04)" | Sec 2.01 treads = PTV ≥36; only Sec 2.06 nosings = ≥40; 3.04 is field QC testing, not a value | Quote the per-component value; don't collapse to the highest number |
   | "hangers ≤1200 mm" | "Maximum 1150 mm centres" | Quote the exact number from the spec |
   | "The 2 m2 mock-up is a construction-stage deliverable, not a specification-stage item" | Spec 09 96 00 Sec 1.05 (M22/280) REQUIRES a 2 m² control sample at spec stage | Acknowledge the 2 m² control sample is already in Sec 1.05; only defer the full mock-up |
   | "set by the Sustainability Manager per SMP Sec 7.2.10" | SMP 7.2.10 is "Procurement Records and Documentation"; the criteria role is SMP 7.1.3.1; role title is "Sustainability Specialist" not "Manager" | Cite the correct section AND the correct role title |

   **Method:** (1) For every numeric claim, grep the actual spec `.txt` for the exact value — a value that is "close but not equal" (36 vs 40, 1150 vs 1200) is a factual error CG will catch. (2) For every plan-document citation (SMP, DMP, PEP, HSE), verify the section number maps to the claimed content — section numbers drift between revisions and a wrong one (7.2.10 vs 7.1.3.1) destroys credibility. (3) Before writing "X is not a spec-stage item / belongs to a later stage," grep the spec for X first — if the spec already contains it (e.g. a 2 m² control sample), the pushback contradicts the very document you're defending. (4) Verify role titles from the plan (Sustainability Specialist, not Manager) before naming a person's role. The default assumption when drafting an S-reply should be: the item is probably already there AND the value is probably slightly different from what you wrote — verify both before finalizing.

3e. **Never call a Code C document "approved."** When a reply references a related submittal, do NOT write "aligned with the approved [X] design" if that design is Code C (Revise & Resubmit) — it is NOT approved, and saying so is a factual error CG will catch (it also contradicts the very next sentence noting the Code C status). Drop "approved" and just reference the doc number: "aligned with the Showcase design (1A0-1G-0009)."

## Compiling a Specialist's Delayed-Deliverables List (pressure email / meeting prep)

When the user asks for "what is required from [specialist] and what is late" to draft a reply or prepare a pressure meeting, **verify the OWNER of every item before including it in the list.** The user will correct you if you misattribute scope. Two real misattributions caught in practice:

| Item | Wrongly attributed to | Actually belongs to |
|------|----------------------|---------------------|
| **Dongguan load/log calcs** (lighting fixture load calcs) | AD Engineering (MEP) | **ZNA** (lighting designer) — it's a lighting fixture supplier's load calc, part of ZNA's DD 50% lighting package |
| **BMS Understanding Report ZD-0107** | AD Engineering (MEP) | **GITCO** (BMS specialist) — CG's Code C comment explicitly says "GITCO must update"; BMS was assigned to GITCO from the outset |

**Method to verify ownership before listing:**
1. For each candidate item, check the submittal register's discipline column and the CG comment text — CG often names the responsible party explicitly (e.g. "GITCO must update").
2. Check the specialist's SOW/scope file (`02_Schedule/<Specialist>/`, `00_Project_Charter/<specialist>_scope.md`) — lighting load calcs are in ZNA's scope, not AD's.
3. Check the project discussion/coordination notes (`09_Agent_Workspace/discussions/`) — the 30-Aug AD coordination note explicitly records "only BMS assigned to GITCO from the outset; everything else is fully detailed in the contract."
4. When in doubt, ask the user before finalizing — a wrong attribution in a formal reply to the specialist destroys credibility.

**Reply framing the user prefers (AD pressure email):** focus on **schedule commitment, initiative, and a catch-up plan** — NOT on the communication method. The user's position: "the method of communication is secondary to commitment to the submission schedule." The reply should (a) accept formal/consolidated communication if the specialist asks, (b) state the purpose of close follow-up is to monitor completion, not to stall, (c) require the specialist to take initiative and flag delays BEFORE they occur, and (d) demand a dated catch-up plan for the outstanding deliverables. Propose a single coordination meeting + signed MOM to convert vague delays into binding commitments (this is the user's standing resolution strategy vs blame-shifting specialists).

## Transmittal Emails to Reviewers: Never Assert Unverified Changes

When drafting an email asking a reviewer (NRS, CG, etc.) to **review and stamp** a drawing set, do NOT claim that changes have been made unless you have verified them against the actual drawings. The user will catch you: "from where you got this comment?"

**The trap:** A reviewer's comment sheet (e.g. NAMA ALAMAL Code C) says "fire hose cabinets must be relocated out of the exit stairwells" and "manual call points must be added at exits." You then write in the transmittal email "fire hose cabinets **have been relocated**... please confirm the positions read correctly" — presenting the reviewer's *required* change as a *done* fact. You have not checked the drawings to confirm the cabinets were actually moved.

**Rules:**
1. **A reviewer comment is a requirement, not a change.** "Comment 5 says relocate the cabinets" ≠ "the cabinets have been relocated." Only assert the latter after opening the DWG/PDF and confirming the new positions exist.
2. **Before sending, verify against the drawings** — check the actual drawing (DWG/PDF) for the claimed change. If you can't verify, either (a) drop the claim, or (b) reword to ask the reviewer to check the current state: "worth a quick look to confirm coverage" instead of "has been added."
3. **Distinguish the two framings in the email:**
   - Verified: "Fire hose cabinets have been relocated out of the stairwells to the escape corridors (per SBC 801)."
   - Unverified / asking reviewer to check: "Please confirm the fire hose cabinet positions and manual call point coverage read correctly on the plans."
4. **Check revision currency too.** If the drawings are dated months before the review sheet in the same folder, flag it — the reviewer may be stamping a stale set. Confirm the drawings were actually updated post-comments before sending.
5. **Scope-filter the package.** A submittal folder often mixes multiple disciplines (life safety drawings vs fire alarm vs suppression vs structural sample). Send the reviewer only the sheets in their scope (e.g. NRS = life safety/egress drawings), not the whole folder.

This is the same "verify refs vs source" discipline as pitfalls 0b/0c/0g/0h, applied to **forward-looking transmittal emails** rather than pushback replies: a claim that a change exists must be backed by the file on disk, not by the reviewer's comment that requested it.

## CG Warning Letter Reply (إنذار) — escalation strategy

When CG/PMC issues a warning letter (e.g. LT-08.02 + PMC LT-0010, 09-Sep-2026), the reply is NOT a CR Sheet — it's a strategic escalation document addressed to the **Ministry/Owner** (cc PMC/CG/Authority), requesting government intervention. Full workflow in `references/cg-warning-letter-reply.md`.

Key rules (learned LT-08.02/LT-0010):
- **Posture:** commitment + cooperation + reserved rights. Never defensive/aggressive.
- **No monetary values in the letter** — fact only ("records kept, shown upon request"); value stays in the internal EOT/VO file.
- **Rebut claim-by-claim** with dated evidence (letter/submittal/transmittal refs) — verify every citation in the submission DB before sending.
- **Direct letters (LT-xxx to Ministry) never appear in Aconex** — their send date is proven only via Outlook SQLite (`Mail` table, `Message_TimeSent` = unix epoch). Registers can disagree (letters register 13-Aug vs risk register 11-Aug for LT-0007): the ORIGINAL Outlook email timestamp wins (11-Aug 09:39).
- **Aconex `last update` column = when the CG code response was logged**, not the snapshot date. Sequence claims ("rejected the day before the warning") must use this timestamp (ZD-0120: submitted 01-Sep, Code C logged 05-Sep — warning was 02-Sep, i.e. BEFORE the rejection).
- **Contract.md OCR is REVERSED Arabic** — plain find() fails. Verify articles via the adjacent English clause + OCR-tolerant patterns (املادة/صالحات). Two articles share "18" — cite by title (Partial Withdrawal vs Waiver of Rights).
- **Hijri month: compute it, never copy from a received draft** (draft had 03/1448; Sept 2026 = Rabi' al-Akhir 04/1448). Contract number digit-count matters too (0010003521 = 11 digits; draft had 9).
- **PM reviews paragraph-by-paragraph** — present sub-claim verdicts + evidence + proposed fix, WAIT for approval before merging. Additions to received drafts go in labeled green blocks, never silent rewrites.
- **No blank fields in the published letter** — fill dates; REMOVE `[placeholder]` lines entirely until the value arrives. Verify addressee identity against records before sending.
- **SI-007 sequence-gate irony** is the strongest argument type: when CG mandates a sequence the contractor had already funded and scheduled (and CG's own comment sheet requested it), state that the SI "converted a parallel-track plan into a serial gate."
- **NCR ≠ delay mechanism:** NCRs address non-conforming EXECUTED works (ISO 9000:2015 3.6.9); delayed works have their own track (schedules, letters, recovery plan) — never mix. Challenge only clearly-misclassified NCRs; a valid NCR (e.g., waste violation) is not challenged.
- **"No stage penalties"** must be verified against the contract (Annex 4 milestones) before asserting.
- **Letter in Arabic** if CG letter is Arabic; natural engineer language, no AI fingerprints (same rules as CR sheets); CEO-signed; formal, not a spreadsheet.
- **Repo workflow:** reply MD in `03_Plans/08_Risk/` (AR for submission + EN internal), delay impact annex, discussion file, letters-register row, action items CW-*, GitHub issue, Surge live preview with 30-min cron, cross-link per AGENTS.md Rule 12. RTL styling rules (right-align never justify, IBM Plex Sans Arabic, section-boundary pagination, no cut tables) live in the samaya-docx-template skill's HTML print reference.

## Pitfalls (letter drafting) In `00_Status/action_items.md`-style registers, table rows repeat across sections (the same "Review Stage 4 Showcase Lighting Package" line appears twice), so a `replace_all` find-and-replace duplicates the new block into EVERY occurrence — corrupting the whole file. Restore with `git checkout -- <file>` and redo. The reliable append is: `write_file` a temp file with just the new rows, then `cat tempfile >> register.md` and `rm tempfile` (the terminal `>>` heredoc is blocked by the `&` tool guard). Only `patch` when you can anchor on a genuinely unique line — and even then, prefer appending at EOF.
- PDFs can be very large (>100k lines); use `pdftotext -layout` and read in chunks
- Comments may have inline status markers like "OK", "OK - comply with Ad.", "OK - Update in DL" — these need careful parsing
- The RACI matrix defines who is responsible for what; always consult it before assigning actions
- Some comments are duplicates ("Same comment #N") — handle by referencing the original
- Always include a table in the external reply for clarity
- Deadlines should be realistic (typically 5-7 working days for resubmission)
- **Don't assume scope split** — title blocks, QA notes, and sheet layout standards are on the designer (they produce the drawings), not the contractor. Cloud survey is on the contractor, not the designer. Verify from past emails before assigning.
- **Name the floor** in the subject line — CG often reviews one floor at a time. Check drawing number prefixes (BF, LG, GF) to confirm which floor the CRS covers.

## User Preferences (Mohamed Sultan Abbas)
- **No model/tokens/session footer** after replies — user revoked this standing request on 10-Sep after finding it repetitive. Never append it again.
- **Paragraph-by-paragraph draft review** — never review a received draft as one document; the PM wants each paragraph discussed and approved individually before edits are merged.
- **Received drafts are 1:1 sacred** — convert verbatim; additions in labeled blocks ("إضافة مقترحة:"), never silent rewrites of the received text.
- Formal, professional tone in both internal and external communications
- Arabic/English bilingual headers in submittal documents (preserve original formatting)
- Prefers detailed action tables with clear party assignments
- Wants "In Progress" vs "Closed" status clearly distinguished
- Expects all comments to be addressed even if just "Noted — no further action"
- Uses specific terminology: "CG" for consultant, "AD" for MEP designer, "DL" for drawing list
- Prefers deadlines to be explicit (date-specific, not relative)
- Attachments should be listed at the end of external replies
- **Single consolidated email** — when routing to multiple parties (NRS, GBH, Structural), send ONE email with a responsibility table, not separate emails per party
- **Check SOW yourself** — before asking a subcontractor if something is in their scope, check their SOW/contract first. Only ask them for timeline/dates, not scope confirmation
- **Don't debate scope in the routing email** — when forwarding CG comments, just state the comment and ask for proposed dates. Don't ask "is this in your scope?" — that's your job to determine from the contract
- **Direct action framing** — emails to subs should say "please review and suggest dates" not "please confirm if this is in your scope"
