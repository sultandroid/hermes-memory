---
name: hermes-model-provider-troubleshooting
description: "Diagnose Hermes Agent model/provider routing, context-window mismatches, OAuth/provider-specific caps, and config changes."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, models, providers, context-window, codex, troubleshooting]
    created_by: agent
---

# Hermes Model Provider Troubleshooting

Use this skill when the user asks about Hermes model selection, default model/provider changes, context length, provider caps, OAuth routes, or why the same model slug behaves differently across providers.

## Core rule

Always treat context length as provider-aware, not model-name-only. The same slug can expose different effective windows depending on route, entitlement, and backend metadata.

## Workflow

1. Load the protected `hermes-agent` skill for authoritative Hermes CLI/config commands.
2. Check current config:
   - `hermes config path`
   - read the `model:` section of `~/.hermes/config.yaml`
3. Confirm credentials/status if provider-specific behavior matters:
   - `hermes auth list`
4. Resolve context through Hermes runtime/source instead of guessing:
   - inspect `agent/model_metadata.py` in the Hermes source if available
   - call `get_model_context_length(model, provider=..., base_url=..., api_key=...)` from the Hermes repo when possible
5. Report the effective route clearly:
   - provider
   - model slug
   - resolved effective context
   - whether the cap is model-inherent or provider-route-specific

## Custom provider / API key setup

When a user asks to “add an API key to models/providers” for a non-catalog provider:

1. Do not echo the key. Store secrets in `~/.hermes/.env`, not in `config.yaml`.
2. Use a provider-specific env name when possible, e.g. `FUGU_API_KEY=...`.
3. Preserve the current active model/provider unless the user explicitly asks to switch.
4. Only add a selectable custom provider after you know both:
   - OpenAI-compatible base URL
   - model ID / default model slug
5. Preferred keyed provider shape in `~/.hermes/config.yaml`:

```yaml
providers:
  fugu:
    api: <base_url>
    key_env: FUGU_API_KEY
    default_model: <model_id>
```

6. Verify without exposing the secret:
   - confirm the env key name exists, not the value
   - run `hermes config check`
   - report current model/provider and whether the new provider was fully registered or only the secret was staged

See `references/custom-provider-secret-staging.md` for a safe staging pattern.

## Known provider-specific pitfall

`gpt-5.5` is not a single universal context number in Hermes:

- `gpt-5.5` via `openai-codex` / ChatGPT Codex OAuth resolves to `272,000` tokens.
- `gpt-5.5` via direct OpenAI-style / OpenRouter routes may resolve to about `1,050,000` tokens.

Do not answer “gpt-5.5 is only 272K” without qualifying the provider. Say: “gpt-5.5 through Codex OAuth is capped to 272K; other provider routes may expose the larger window.”

## Recommended phrasing

- “This is the effective cap on your current Hermes provider route, not necessarily the raw model maximum.”
- “Same model slug, different backend/entitlement path.”
- “If you need the full window, use a provider route that exposes it, not the Codex OAuth route.”

## References

- `references/codex-gpt55-context-cap.md` — session-derived detail on the Codex OAuth 272K cap vs 1.05M on other routes.
