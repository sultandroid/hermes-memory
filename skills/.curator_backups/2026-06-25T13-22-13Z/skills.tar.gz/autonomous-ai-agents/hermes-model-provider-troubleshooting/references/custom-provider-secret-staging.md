# Custom provider secret staging

Session-derived pattern for adding an API key before the provider endpoint/model is known.

## When to use

Use when the user provides a provider API key and asks to add it to Hermes models/providers, but has not supplied the provider base URL and model ID.

## Safe workflow

1. Treat the key as a secret:
   - do not repeat it in prompts, logs, summaries, or config output
   - avoid commands that print the full `.env`
2. Stage only the secret in `~/.hermes/.env`:

```env
FUGU_API_KEY=<secret>
```

3. Set `.env` permissions to owner read/write only (`0600`).
4. Do not change `model.provider` / `model.default` unless explicitly asked.
5. Do not create a selectable provider until both values are known:
   - OpenAI-compatible `base_url`
   - provider model slug
6. Once known, add the keyed provider entry:

```yaml
providers:
  fugu:
    api: <base_url>
    key_env: FUGU_API_KEY
    default_model: <model_id>
```

7. Verify safely:
   - confirm `FUGU_API_KEY` exists by name only
   - report prefix/length at most if needed, never full value
   - run `hermes config check`
   - report whether provider registration is complete or only secret staging is complete

## Pitfalls

- Do not put API key literals in `config.yaml` when `key_env` can be used.
- Do not infer a provider base URL from the key prefix alone.
- Do not switch the active Hermes model route during secret staging.
